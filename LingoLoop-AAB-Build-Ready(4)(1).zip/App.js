import React, { useState, useEffect } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Speech from 'expo-speech';
import researchedContent from './researched-content.json';
import appConfig from './app.json';

export default function App() {
  const lessonGroups = {
    a1: [
      {"id": "intro1", "title": "Greetings, How Are You? & Introductions 👋", "description": "Say hello, ask how someone is, and introduce yourself.", "sentences": [{"id": "intro1-1", "en": "Hello! My name is Sara.", "fa": "سلام! اسم من سارا است."}, {"id": "intro1-2", "en": "What is your name?", "fa": "اسم شما چیست؟"}, {"id": "intro1-3", "en": "Nice to meet you.", "fa": "از آشنایی با شما خوشوقتم."}, {"id": "intro1-4", "en": "How are you?", "fa": "حال شما چطور است؟"}, {"id": "intro1-5", "en": "I'm fine, thank you.", "fa": "خوبم، ممنون."}, {"id": "intro1-6", "en": "I'm from Iran.", "fa": "من اهل ایران هستم."}, {"id": "intro1-7", "en": "I live in Tehran.", "fa": "من در تهران زندگی می‌کنم."}, {"id": "intro1-8", "en": "What do you do?", "fa": "شغل شما چیست؟"}, {"id": "intro1-9", "en": "I'm a student.", "fa": "من دانشجو هستم."}, {"id": "intro1-10", "en": "See you later!", "fa": "بعداً می‌بینمت!"}, {"id": "intro1-11", "en": "Good morning!", "fa": "صبح بخیر!"}, {"id": "intro1-12", "en": "Good evening!", "fa": "عصر بخیر!"}, {"id": "intro1-13", "en": "This is my friend, Mina.", "fa": "این دوست من، مینا، است."}, {"id": "intro1-14", "en": "Nice to meet you too.", "fa": "من هم از آشنایی با شما خوشوقتم."}, {"id": "intro1-15", "en": "What is your first name?", "fa": "نام کوچک شما چیست؟"}, {"id": "intro1-16", "en": "My first name is Ali.", "fa": "نام کوچک من علی است."}, {"id": "intro1-17", "en": "How do you spell your name?", "fa": "اسمت را چطور هجی می‌کنی؟"}, {"id": "intro1-18", "en": "Where are you from?", "fa": "اهل کجا هستی؟"}, {"id": "intro1-19", "en": "Are you a student?", "fa": "دانشجو هستی؟"}, {"id": "intro1-20", "en": "Yes, I am.", "fa": "بله، هستم."}, {"id": "intro1-21", "en": "Have a nice day!", "fa": "روز خوبی داشته باشی!"}, {"id": "intro1-22", "en": "Goodbye!", "fa": "خداحافظ!"}]},
      {"id": "b3", "title": "At Home 🏠", "description": "Talk about daily routines.", "sentences": [{"id": "b3-1", "en": "I wake up at seven.", "fa": "من ساعت هفت بیدار می‌شوم."}, {"id": "b3-2", "en": "I make breakfast every morning.", "fa": "من هر صبح صبحانه درست می‌کنم."}, {"id": "b3-3", "en": "I go to bed at eleven.", "fa": "من ساعت یازده می‌خوابم."}, {"id": "b3-4", "en": "I get up at seven thirty.", "fa": "من ساعت هفت و نیم از تخت بلند می‌شوم."}, {"id": "b3-5", "en": "I brush my teeth.", "fa": "من مسواک می‌زنم."}, {"id": "b3-6", "en": "I take a shower in the morning.", "fa": "من صبح دوش می‌گیرم."}, {"id": "b3-7", "en": "I have breakfast at eight.", "fa": "من ساعت هشت صبحانه می‌خورم."}, {"id": "b3-8", "en": "I drink tea with breakfast.", "fa": "من همراه صبحانه چای می‌نوشم."}, {"id": "b3-9", "en": "I leave home at nine.", "fa": "من ساعت نه از خانه بیرون می‌روم."}, {"id": "b3-10", "en": "I go to work by bus.", "fa": "من با اتوبوس به محل کار می‌روم."}, {"id": "b3-11", "en": "I come home at six.", "fa": "من ساعت شش به خانه برمی‌گردم."}, {"id": "b3-12", "en": "I cook dinner at home.", "fa": "من در خانه شام می‌پزم."}, {"id": "b3-13", "en": "I watch TV after dinner.", "fa": "من بعد از شام تلویزیون تماشا می‌کنم."}, {"id": "b3-14", "en": "I read before bed.", "fa": "من پیش از خواب مطالعه می‌کنم."}, {"id": "b3-15", "en": "What time do you go to bed?", "fa": "چه ساعتی می‌خوابی؟"}]},
      {"id": "b1", "title": "At a Coffee Shop ☕", "description": "Order, ask, and enjoy.", "sentences": [{"id": "b1-1", "en": "Can I have a coffee, please?", "fa": "میشه لطفاً یک قهوه داشته باشم؟"}, {"id": "b1-2", "en": "I would like a cappuccino.", "fa": "من یک کاپوچینو می‌خواهم."}, {"id": "b1-3", "en": "Can I pay by card?", "fa": "می‌توانم با کارت پرداخت کنم؟"}, {"id": "b1-4", "en": "Can I see the menu, please?", "fa": "می‌توانم منو را ببینم، لطفاً؟"}, {"id": "b1-5", "en": "Do you have tea?", "fa": "چای دارید؟"}, {"id": "b1-6", "en": "I would like a cup of tea.", "fa": "یک فنجان چای می‌خواهم."}, {"id": "b1-7", "en": "I would like a small coffee.", "fa": "یک قهوهٔ کوچک می‌خواهم."}, {"id": "b1-8", "en": "Do you have iced coffee?", "fa": "قهوهٔ سرد دارید؟"}, {"id": "b1-9", "en": "Is this coffee hot?", "fa": "این قهوه داغ است؟"}, {"id": "b1-10", "en": "Can I have it with milk?", "fa": "می‌توانم آن را با شیر بگیرم؟"}, {"id": "b1-11", "en": "No sugar, please.", "fa": "بدون شکر، لطفاً."}, {"id": "b1-12", "en": "Can I have some water, please?", "fa": "می‌توانم کمی آب بگیرم، لطفاً؟"}, {"id": "b1-13", "en": "For here, please.", "fa": "برای خوردن در همین‌جا، لطفاً."}, {"id": "b1-14", "en": "To go, please.", "fa": "برای بیرون‌بر، لطفاً."}, {"id": "b1-15", "en": "How much is it?", "fa": "قیمتش چقدر است؟"}, {"id": "b1-16", "en": "Here is my card.", "fa": "این هم کارت من."}, {"id": "b1-17", "en": "Thank you. Have a nice day!", "fa": "ممنون. روز خوبی داشته باشید!"}]},
      {"id": "b4", "title": "Shopping 🛍️", "description": "Find what you need.", "sentences": [{"id": "b4-1", "en": "How much is this?", "fa": "این چقدر است؟"}, {"id": "b4-2", "en": "Do you have this in blue?", "fa": "این را به رنگ آبی دارید؟"}, {"id": "b4-3", "en": "Can I try this on?", "fa": "می‌توانم این را پرو کنم؟"}, {"id": "b4-4", "en": "I am looking for a shirt.", "fa": "دنبال یک پیراهن می‌گردم."}, {"id": "b4-5", "en": "Do you have a small size?", "fa": "سایز کوچک دارید؟"}, {"id": "b4-6", "en": "Do you have a larger size?", "fa": "سایز بزرگ‌تری دارید؟"}, {"id": "b4-7", "en": "Where is the fitting room?", "fa": "اتاق پرو کجاست؟"}, {"id": "b4-8", "en": "This is too small.", "fa": "این خیلی کوچک است."}, {"id": "b4-9", "en": "This fits well.", "fa": "این اندازه‌ام است."}, {"id": "b4-10", "en": "I like this color.", "fa": "این رنگ را دوست دارم."}, {"id": "b4-11", "en": "How much are these shoes?", "fa": "این کفش‌ها چقدر هستند؟"}, {"id": "b4-12", "en": "Can I pay by card?", "fa": "می‌توانم با کارت پرداخت کنم؟"}, {"id": "b4-13", "en": "Can I pay in cash?", "fa": "می‌توانم نقد پرداخت کنم؟"}, {"id": "b4-14", "en": "I will take it.", "fa": "این را می‌خرم."}, {"id": "b4-15", "en": "Do you have a bag?", "fa": "کیسه دارید؟"}, {"id": "b4-16", "en": "Can I have a receipt, please?", "fa": "می‌توانم رسید بگیرم، لطفاً؟"}]},
      {
        id: 'b5',
        title: 'At a Restaurant 🍴',
        description: 'Order food and make requests.',
        sentences: [
          {
            id: 'b5-new-1',
            en: 'A table for two, please.',
            fa: 'یک میز برای دو نفر، لطفاً.',
          },
          {
            id: 'b5-new-2',
            en: 'Do you have a table by the window?',
            fa: 'کنار پنجره میز دارید؟',
          },
          {
            id: 'b5-1',
            en: 'Can I see the menu?',
            fa: 'می\u200cتوانم منو را ببینم؟',
          },
          {
            id: 'b5-new-4',
            en: 'What do you recommend?',
            fa: 'چه غذایی پیشنهاد می\u200cکنید؟',
          },
          {
            id: 'b5-2',
            en: 'I would like the chicken, please.',
            fa: 'لطفاً مرغ می\u200cخواهم.',
          },
          {
            id: 'b5-new-6',
            en: "I'd like chicken and rice, please.",
            fa: 'مرغ و برنج می\u200cخواهم، لطفاً.',
          },
          {
            id: 'b5-new-7',
            en: 'Can I have some water, please?',
            fa: 'می\u200cتوانم کمی آب داشته باشم، لطفاً؟',
          },
          {
            id: 'b5-new-8',
            en: 'Is this spicy?',
            fa: 'این تند است؟',
          },
          {
            id: 'b5-new-9',
            en: 'Does this have meat?',
            fa: 'این گوشت دارد؟',
          },
          {
            id: 'b5-new-10',
            en: 'No salad, please.',
            fa: 'سالاد نمی\u200cخواهم، لطفاً.',
          },
          {
            id: 'b5-new-11',
            en: 'The food is delicious.',
            fa: 'غذا خوشمزه است.',
          },
          {
            id: 'b5-new-12',
            en: 'Could we have another plate?',
            fa: 'می\u200cتوانیم یک بشقاب دیگر داشته باشیم؟',
          },
          {
            id: 'b5-3',
            en: 'Can I have the bill, please?',
            fa: 'می\u200cشود لطفاً صورت\u200cحساب را بیاورید؟',
          },
          {
            id: 'b5-new-14',
            en: 'Can I pay by card?',
            fa: 'می\u200cتوانم با کارت پرداخت کنم؟',
          },
          {
            id: 'b5-new-15',
            en: 'Thank you. Have a nice day!',
            fa: 'ممنون. روز خوبی داشته باشید!',
          }
        ],
      },
      {"id": "directions1", "title": "Asking for Directions 📍", "description": "Find places and ask for an address.", "sentences": [{"id": "directions1-1", "en": "Excuse me, where is the pharmacy?", "fa": "ببخشید، داروخانه کجاست؟"}, {"id": "directions1-2", "en": "What is the address?", "fa": "آدرس چیست؟"}, {"id": "directions1-3", "en": "Is it near here?", "fa": "نزدیک اینجاست؟"}, {"id": "directions1-4", "en": "Go straight.", "fa": "مستقیم بروید."}, {"id": "directions1-5", "en": "Turn left at the bank.", "fa": "کنار بانک به چپ بپیچید."}, {"id": "directions1-6", "en": "Turn right at the light.", "fa": "کنار چراغ به راست بپیچید."}, {"id": "directions1-7", "en": "It is next to the hospital.", "fa": "کنار بیمارستان است."}, {"id": "directions1-8", "en": "Thank you for your help.", "fa": "از کمکتان ممنونم."}, {"id": "directions1-9", "en": "Where is the bus stop?", "fa": "ایستگاه اتوبوس کجاست؟"}, {"id": "directions1-10", "en": "How do I get to the station?", "fa": "چطور به ایستگاه بروم؟"}, {"id": "directions1-11", "en": "Is it far from here?", "fa": "از اینجا دور است؟"}, {"id": "directions1-12", "en": "It is on this street.", "fa": "در همین خیابان است."}, {"id": "directions1-13", "en": "It is across from the bank.", "fa": "روبروی بانک است."}, {"id": "directions1-14", "en": "It is between the bank and the cafe.", "fa": "بین بانک و کافه است."}, {"id": "directions1-15", "en": "Go straight for one block.", "fa": "یک بلوک مستقیم بروید."}, {"id": "directions1-16", "en": "Please show me on the map.", "fa": "لطفاً روی نقشه نشانم بدهید."}, {"id": "directions1-17", "en": "Can you say that again, please?", "fa": "می‌توانید دوباره بگویید، لطفاً؟"}, {"id": "directions1-18", "en": "I am lost.", "fa": "گم شده‌ام."}]},
      {"id": "birthday1", "title": "Birthday & Birthplace 🎂", "description": "Talk about birthdays and where you are from.", "sentences": [{"id": "birthday1-1", "en": "When is your birthday?", "fa": "تولدت چه زمانی است؟"}, {"id": "birthday1-2", "en": "My birthday is on May tenth.", "fa": "تولد من دهم ماه مه است."}, {"id": "birthday1-3", "en": "Where were you born?", "fa": "کجا متولد شدی؟"}, {"id": "birthday1-4", "en": "I was born in Tehran.", "fa": "من در تهران متولد شدم."}, {"id": "birthday1-5", "en": "How old are you?", "fa": "چند سالت است؟"}, {"id": "birthday1-6", "en": "I'm twenty years old.", "fa": "من بیست سال دارم."}, {"id": "birthday1-7", "en": "Today is my birthday.", "fa": "امروز تولد من است."}, {"id": "birthday1-8", "en": "Happy birthday!", "fa": "تولدت مبارک!"}, {"id": "birthday1-9", "en": "What month is your birthday?", "fa": "تولدت در چه ماهی است؟"}, {"id": "birthday1-10", "en": "My birthday is in June.", "fa": "تولد من در ماه ژوئن است."}, {"id": "birthday1-11", "en": "What day is your birthday?", "fa": "روز تولدت چه روزی است؟"}, {"id": "birthday1-12", "en": "My birthday is on Friday.", "fa": "تولدم جمعه است."}, {"id": "birthday1-13", "en": "Where are you from?", "fa": "اهل کجایی؟"}, {"id": "birthday1-14", "en": "I am from Iran.", "fa": "اهل ایران هستم."}, {"id": "birthday1-15", "en": "Are you from Tehran?", "fa": "اهل تهران هستی؟"}, {"id": "birthday1-16", "en": "No, I am from Shiraz.", "fa": "نه، اهل شیراز هستم."}, {"id": "birthday1-17", "en": "Are you having a party?", "fa": "جشن می‌گیری؟"}, {"id": "birthday1-18", "en": "Yes, my family is coming.", "fa": "بله، خانواده‌ام می‌آیند."}]},
      {"id": "colors1", "title": "Colors & Clothes 🎨", "description": "Describe colors and everyday clothes.", "sentences": [{"id": "colors1-1", "en": "What color is this?", "fa": "این چه رنگی است؟"}, {"id": "colors1-2", "en": "It is blue.", "fa": "آبی است."}, {"id": "colors1-3", "en": "I like the red shirt.", "fa": "پیراهن قرمز را دوست دارم."}, {"id": "colors1-4", "en": "Do you have this in black?", "fa": "این را به رنگ مشکی دارید؟"}, {"id": "colors1-5", "en": "This jacket is too big.", "fa": "این ژاکت خیلی بزرگ است."}, {"id": "colors1-6", "en": "I need a small size.", "fa": "من سایز کوچک می‌خواهم."}, {"id": "colors1-7", "en": "These shoes are white.", "fa": "این کفش‌ها سفیدند."}, {"id": "colors1-8", "en": "My bag is green.", "fa": "کیف من سبز است."}, {"id": "colors1-9", "en": "Is this shirt blue or green?", "fa": "این پیراهن آبی است یا سبز؟"}, {"id": "colors1-10", "en": "The dress is yellow.", "fa": "پیراهن زنانه زرد است."}, {"id": "colors1-11", "en": "I want a white T-shirt.", "fa": "یک تی‌شرت سفید می‌خواهم."}, {"id": "colors1-12", "en": "Do you have a medium size?", "fa": "سایز متوسط دارید؟"}, {"id": "colors1-13", "en": "These pants are too long.", "fa": "این شلوار خیلی بلند است."}, {"id": "colors1-14", "en": "This hat is brown.", "fa": "این کلاه قهوه‌ای است."}, {"id": "colors1-15", "en": "I like this color.", "fa": "این رنگ را دوست دارم."}, {"id": "colors1-16", "en": "The black shoes are nice.", "fa": "کفش‌های مشکی قشنگ هستند."}, {"id": "colors1-17", "en": "Can I try this on?", "fa": "می‌توانم این را پرو کنم؟"}, {"id": "colors1-18", "en": "This shirt is too small.", "fa": "این پیراهن خیلی کوچک است."}, {"id": "colors1-19", "en": "I need a larger size, please.", "fa": "لطفاً سایز بزرگ‌تری می‌خواهم."}, {"id": "colors1-20", "en": "My socks are gray.", "fa": "جوراب‌های من خاکستری هستند."}]},
      {"id": "school1", "title": "School, Work & Sports 🏫", "description": "Describe your study, work, and hobbies.", "sentences": [{"id": "school1-1", "en": "I study English every day.", "fa": "من هر روز انگلیسی می‌خوانم."}, {"id": "school1-2", "en": "What do you study?", "fa": "چه رشته‌ای می‌خوانی؟"}, {"id": "school1-3", "en": "I work in an office.", "fa": "من در یک دفتر کار می‌کنم."}, {"id": "school1-4", "en": "What is your job?", "fa": "شغلت چیست؟"}, {"id": "school1-5", "en": "I'm a teacher.", "fa": "من معلم هستم."}, {"id": "school1-6", "en": "I play football on Fridays.", "fa": "من جمعه‌ها فوتبال بازی می‌کنم."}, {"id": "school1-7", "en": "I go to the gym twice a week.", "fa": "من هفته‌ای دو بار به باشگاه می‌روم."}, {"id": "school1-8", "en": "Do you like swimming?", "fa": "شنا را دوست داری؟"}, {"id": "school1-9", "en": "I am a student.", "fa": "من دانش‌آموز / دانشجو هستم."}, {"id": "school1-10", "en": "I go to school in the morning.", "fa": "صبح‌ها به مدرسه می‌روم."}, {"id": "school1-11", "en": "I have an English class today.", "fa": "امروز کلاس انگلیسی دارم."}, {"id": "school1-12", "en": "What time is your class?", "fa": "کلاست چه ساعتی است؟"}, {"id": "school1-13", "en": "My class starts at nine.", "fa": "کلاسم ساعت نه شروع می‌شود."}, {"id": "school1-14", "en": "This is my teacher.", "fa": "این معلم من است."}, {"id": "school1-15", "en": "I have homework tonight.", "fa": "امشب تکلیف دارم."}, {"id": "school1-16", "en": "Where do you work?", "fa": "کجا کار می‌کنی؟"}, {"id": "school1-17", "en": "I work at a shop.", "fa": "در یک مغازه کار می‌کنم."}, {"id": "school1-18", "en": "I start work at eight.", "fa": "کارم را ساعت هشت شروع می‌کنم."}, {"id": "school1-19", "en": "My sister is a nurse.", "fa": "خواهرم پرستار است."}, {"id": "school1-20", "en": "I do not work on Sundays.", "fa": "یکشنبه‌ها کار نمی‌کنم."}]},
      {"id": "animals1", "title": "Animals & Pets 🐾", "description": "Talk about common animals and pets.", "sentences": [{"id": "animals1-1", "en": "Do you have a pet?", "fa": "حیوان خانگی داری؟"}, {"id": "animals1-2", "en": "Yes, I have a cat.", "fa": "بله، یک گربه دارم."}, {"id": "animals1-3", "en": "What is its name?", "fa": "اسمش چیست؟"}, {"id": "animals1-4", "en": "Its name is Luna.", "fa": "اسمش لونا است."}, {"id": "animals1-5", "en": "My dog is friendly.", "fa": "سگ من مهربان است."}, {"id": "animals1-6", "en": "I like birds.", "fa": "پرنده‌ها را دوست دارم."}, {"id": "animals1-7", "en": "The fish is small.", "fa": "ماهی کوچک است."}, {"id": "animals1-8", "en": "I do not have a pet.", "fa": "حیوان خانگی ندارم."}, {"id": "animals1-9", "en": "Is your cat at home?", "fa": "گربه‌ات خانه است؟"}, {"id": "animals1-10", "en": "Yes, she is at home.", "fa": "بله، خانه است."}, {"id": "animals1-11", "en": "My dog likes water.", "fa": "سگ من آب را دوست دارد."}, {"id": "animals1-12", "en": "The bird is in the tree.", "fa": "پرنده روی درخت است."}, {"id": "animals1-13", "en": "Can I pet your dog?", "fa": "می‌توانم سگت را نوازش کنم؟"}, {"id": "animals1-14", "en": "This dog is very small.", "fa": "این سگ خیلی کوچک است."}, {"id": "animals1-15", "en": "I see two cats.", "fa": "دو گربه می‌بینم."}, {"id": "animals1-16", "en": "Do you like dogs?", "fa": "سگ‌ها را دوست داری؟"}, {"id": "animals1-17", "en": "The fish is orange.", "fa": "ماهی نارنجی است."}, {"id": "animals1-18", "en": "My cat is hungry.", "fa": "گربه‌ام گرسنه است."}, {"id": "animals1-19", "en": "I give my dog water.", "fa": "به سگم آب می‌دهم."}, {"id": "animals1-20", "en": "That is a big horse.", "fa": "آن یک اسب بزرگ است."}]},
      {"id": "mechanic1", "title": "At the Mechanic 🚗", "description": "Explain a simple car problem.", "sentences": [{"id": "mechanic1-1", "en": "My car will not start.", "fa": "ماشینم روشن نمی‌شود."}, {"id": "mechanic1-2", "en": "I have a problem with my car.", "fa": "ماشینم مشکلی دارد."}, {"id": "mechanic1-3", "en": "The tire is flat.", "fa": "لاستیک پنچر است."}, {"id": "mechanic1-4", "en": "Can you check the car?", "fa": "می‌توانید ماشین را بررسی کنید؟"}, {"id": "mechanic1-5", "en": "How much will it cost?", "fa": "هزینه‌اش چقدر می‌شود؟"}, {"id": "mechanic1-6", "en": "When will it be ready?", "fa": "چه زمانی آماده می‌شود؟"}, {"id": "mechanic1-7", "en": "I need help, please.", "fa": "لطفاً کمک می‌خواهم."}]}
    ],
    a2: [
      {"id": "a2routine", "title": "Daily Plans & Invitations 📅", "description": "Arrange times and talk about plans.", "sentences": [{"id": "a2routine-1", "en": "Are you free on Saturday?", "fa": "شنبه وقت داری؟"}, {"id": "a2routine-2", "en": "I am meeting my friend at six.", "fa": "ساعت شش دوستم را می‌بینم."}, {"id": "a2routine-3", "en": "Would you like to join us?", "fa": "دوست داری به ما ملحق شوی؟"}, {"id": "a2routine-4", "en": "I would love to, but I have class.", "fa": "خیلی دوست دارم، ولی کلاس دارم."}, {"id": "a2routine-5", "en": "Can we meet tomorrow instead?", "fa": "می‌توانیم به‌جایش فردا همدیگر را ببینیم؟"}, {"id": "a2routine-6", "en": "What time works for you?", "fa": "چه ساعتی برایت مناسب است؟"}, {"id": "a2routine-7", "en": "Let us meet at the café.", "fa": "بیا در کافه همدیگر را ببینیم."}]},
      {
        id: 'b2',
        title: 'At the Airport ✈️',
        description: 'Travel with confidence.',
        sentences: [
          {
            id: 'b2-1',
            en: 'Where is the check-in desk?',
            fa: 'کانتر چک‌این کجاست؟',
          },
          {
            id: 'b2-2',
            en: 'What time is boarding?',
            fa: 'سوار شدن چه ساعتی است؟',
          },
          {
            id: 'b2-3',
            en: 'Where is gate twelve?',
            fa: 'گیت دوازده کجاست؟',
          },
        ],
      }
    ],
    b1: [
      {"id": "b1problem", "title": "Solving a Travel Problem 🧳", "description": "Explain a problem and ask for a solution.", "sentences": [{"id": "b1problem-1", "en": "My flight has been delayed.", "fa": "پروازم تأخیر داشته است."}, {"id": "b1problem-2", "en": "I booked a room for two nights.", "fa": "اتاقی برای دو شب رزرو کردم."}, {"id": "b1problem-3", "en": "The booking confirmation is on my phone.", "fa": "تأیید رزرو در گوشی‌ام است."}, {"id": "b1problem-4", "en": "Could you check my reservation?", "fa": "می‌توانید رزروم را بررسی کنید؟"}, {"id": "b1problem-5", "en": "Is there another room available?", "fa": "اتاق دیگری موجود است؟"}, {"id": "b1problem-6", "en": "I would appreciate your help.", "fa": "از کمک شما سپاسگزار می‌شوم."}, {"id": "b1problem-7", "en": "What are my options?", "fa": "چه گزینه‌هایی دارم؟"}]},
      {
        id: 'i1',
        title: 'At Work 💼',
        description: 'Build confidence at work.',
        sentences: [
          {
            id: 'i1-1',
            en: 'Could we schedule a meeting for tomorrow?',
            fa: 'می‌توانیم برای فردا یک جلسه تنظیم کنیم؟',
          },
          {
            id: 'i1-2',
            en: 'I will send you the report this afternoon.',
            fa: 'امروز بعدازظهر گزارش را برایتان می‌فرستم.',
          },
          {
            id: 'i1-3',
            en: 'Could you explain that again, please?',
            fa: 'می‌توانید لطفاً دوباره آن را توضیح دهید؟',
          },
        ],
      },
      {
        id: 'i2',
        title: 'Making Plans 📅',
        description: 'Talk about future activities.',
        sentences: [
          {
            id: 'i2-1',
            en: 'Are you free this weekend?',
            fa: 'این آخر هفته وقت داری؟',
          },
          {
            id: 'i2-2',
            en: 'Why don’t we meet around six?',
            fa: 'چرا حدود ساعت شش همدیگر را نبینیم؟',
          },
          {
            id: 'i2-3',
            en: 'Let me check my schedule.',
            fa: 'بگذار برنامه‌ام را بررسی کنم.',
          },
        ],
      }
    ],
    b2: [
      {"id": "b2mechanic", "title": "Comparing Repair Options 🔧", "description": "Discuss costs and alternatives.", "sentences": [{"id": "b2mechanic-1", "en": "The engine makes a strange noise when I accelerate.", "fa": "وقتی گاز می‌دهم موتور صدای عجیبی می‌دهد."}, {"id": "b2mechanic-2", "en": "Could you explain what needs to be replaced?", "fa": "می‌توانید توضیح دهید چه چیزی باید تعویض شود؟"}, {"id": "b2mechanic-3", "en": "Is there a cheaper alternative?", "fa": "گزینهٔ ارزان‌تری وجود دارد؟"}, {"id": "b2mechanic-4", "en": "How long will the repair take?", "fa": "تعمیر چقدر طول می‌کشد؟"}, {"id": "b2mechanic-5", "en": "I would like an estimate before you start.", "fa": "پیش از شروع، برآورد هزینه می‌خواهم."}, {"id": "b2mechanic-6", "en": "What is covered by the warranty?", "fa": "چه مواردی تحت پوشش ضمانت است؟"}]},
      {
        id: 'i3',
        title: 'Doctor Visit 🩺',
        description: 'Explain everyday problems.',
        sentences: [
          {
            id: 'i3-1',
            en: 'I have been feeling tired lately.',
            fa: 'اخیراً احساس خستگی می‌کنم.',
          },
          {
            id: 'i3-2',
            en: 'How long have you had this problem?',
            fa: 'چه مدت است این مشکل را دارید؟',
          },
          {
            id: 'i3-3',
            en: 'Do I need to take any medicine?',
            fa: 'آیا لازم است دارویی مصرف کنم؟',
          },
        ],
      }
    ],
    c1: [
      {"id": "c1presentation", "title": "Presenting a Proposal 📊", "description": "Present evidence and respond to questions.", "sentences": [{"id": "c1presentation-1", "en": "Our proposal addresses the most urgent customer needs.", "fa": "پیشنهاد ما به فوری‌ترین نیازهای مشتریان می‌پردازد."}, {"id": "c1presentation-2", "en": "The available evidence suggests a steady rise in demand.", "fa": "شواهد موجود از رشد پیوستهٔ تقاضا حکایت دارد."}, {"id": "c1presentation-3", "en": "We should also acknowledge the limitations of this estimate.", "fa": "باید محدودیت‌های این برآورد را نیز بپذیریم."}, {"id": "c1presentation-4", "en": "Let me clarify the assumption behind that figure.", "fa": "اجازه دهید فرض پشت آن عدد را روشن کنم."}, {"id": "c1presentation-5", "en": "A phased approach would reduce the initial risk.", "fa": "رویکرد مرحله‌ای ریسک اولیه را کاهش می‌دهد."}, {"id": "c1presentation-6", "en": "I welcome questions about the proposed timeline.", "fa": "از پرسش‌ها دربارهٔ زمان‌بندی پیشنهادی استقبال می‌کنم."}]},
      {
        id: 'a1',
        title: 'Giving Opinions 💬',
        description: 'Express complex ideas clearly.',
        sentences: [
          {
            id: 'a1-1',
            en: 'From my perspective, the benefits outweigh the risks.',
            fa: 'از دیدگاه من، مزایا از خطرات بیشتر است.',
          },
          {
            id: 'a1-2',
            en: 'I understand your point, but I see it differently.',
            fa: 'دیدگاهت را درک می‌کنم، اما من متفاوت به آن نگاه می‌کنم.',
          },
          {
            id: 'a1-3',
            en: 'There are several factors we should consider.',
            fa: 'چند عامل وجود دارد که باید در نظر بگیریم.',
          },
        ],
      },
      {
        id: 'a2',
        title: 'Professional English 🎯',
        description: 'Communicate with precision.',
        sentences: [
          {
            id: 'a2-1',
            en: 'We need to evaluate the long-term impact of this decision.',
            fa: 'باید تأثیر بلندمدت این تصمیم را ارزیابی کنیم.',
          },
          {
            id: 'a2-2',
            en: 'I would appreciate your feedback on the proposal.',
            fa: 'از بازخورد شما درباره این پیشنهاد استقبال می‌کنم.',
          },
          {
            id: 'a2-3',
            en: 'Let us focus on the most practical solution.',
            fa: 'بیایید روی عملی‌ترین راه‌حل تمرکز کنیم.',
          },
        ],
      }
    ],
    c2: [
      {"id": "c2debate", "title": "Nuanced Debate 🧠", "description": "Evaluate assumptions and subtle implications.", "sentences": [{"id": "c2debate-1", "en": "That conclusion rests on an assumption we have not tested.", "fa": "آن نتیجه بر فرضی تکیه دارد که هنوز آزمایش نکرده‌ایم."}, {"id": "c2debate-2", "en": "The evidence is persuasive, but it does not settle the question.", "fa": "شواهد قانع‌کننده‌اند، اما مسئله را قطعی حل نمی‌کنند."}, {"id": "c2debate-3", "en": "We may be conflating a short-term trend with a structural change.", "fa": "شاید روندی کوتاه‌مدت را با تغییری ساختاری یکی می‌گیریم."}, {"id": "c2debate-4", "en": "I agree in principle, though the practical implications are less clear.", "fa": "در اصل موافقم، هرچند پیامدهای عملی کمتر روشن‌اند."}, {"id": "c2debate-5", "en": "The apparent disagreement may come down to how we define success.", "fa": "اختلاف ظاهری شاید به تعریف ما از موفقیت برگردد."}, {"id": "c2debate-6", "en": "Let us separate what we know from what we infer.", "fa": "بیایید دانسته‌ها را از استنباط‌ها جدا کنیم."}]},
      {
        id: 'a3',
        title: 'Discussion & Debate 🧠',
        description: 'Challenge yourself with complex topics.',
        sentences: [
          {
            id: 'a3-1',
            en: 'The issue is more nuanced than it initially appears.',
            fa: 'این موضوع پیچیده‌تر از چیزی است که در ابتدا به نظر می‌رسد.',
          },
          {
            id: 'a3-2',
            en: 'That argument is compelling, although it has limitations.',
            fa: 'آن استدلال قانع‌کننده است، هرچند محدودیت‌هایی دارد.',
          },
          {
            id: 'a3-3',
            en: 'We should distinguish between correlation and causation.',
            fa: 'باید بین همبستگی و رابطه علّی تفاوت قائل شویم.',
          },
        ],
      }
    ]
  };

  // Additional A1 and A2 lessons; existing IDs and saved progress remain stable.
  // B1/B2 use one curriculum source for list order, numbering and all four parts.
  const upperLevelTopics = {
    b1: [
      ['b1work', 'Workplace Communication 💼', 'ارتباط در محیط کار', 'workplace', 'محیط کار'],
      ['b1meetings', 'Meetings & Decisions 📋', 'جلسه‌ها و تصمیم‌گیری', 'meetings', 'جلسه‌ها'],
      ['b1jobs', 'Jobs & Career Plans 🎯', 'شغل و برنامه‌های حرفه‌ای', 'career plans', 'برنامه‌های شغلی'],
      ['b1education', 'Education & Study Skills 📚', 'تحصیل و مهارت‌های مطالعه', 'education', 'آموزش'],
      ['b1travel', 'Travel Problems & Solutions 🧳', 'مشکلات سفر و راه‌حل‌ها', 'travel', 'سفر'],
      ['b1hotel', 'Hotel Requests & Complaints 🏨', 'درخواست و شکایت در هتل', 'hotel services', 'خدمات هتل'],
      ['b1health', 'Health Advice & Recovery 🩺', 'توصیه‌های سلامتی و بهبود', 'health', 'سلامتی'],
      ['b1shopping', 'Shopping & Consumer Rights 🛍️', 'خرید و حقوق مصرف‌کننده', 'shopping', 'خرید'],
      ['b1technology', 'Technology & Online Services 💻', 'فناوری و خدمات آنلاین', 'technology', 'فناوری'],
      ['b1environment', 'Environment & Everyday Choices 🌱', 'محیط‌زیست و انتخاب‌های روزمره', 'the environment', 'محیط‌زیست'],
      ['b1news', 'News & Current Events 📰', 'اخبار و رویدادهای روز', 'current events', 'رویدادهای روز'],
      ['b1relationships', 'Relationships & Social Situations 🤝', 'روابط و موقعیت‌های اجتماعی', 'relationships', 'روابط'],
      ['b1housing', 'Housing & Neighborhoods 🏠', 'مسکن و محله', 'housing', 'مسکن'],
      ['b1money', 'Money & Personal Finance 💳', 'پول و امور مالی شخصی', 'personal finance', 'امور مالی شخصی'],
      ['b1culture', 'Culture & Traditions 🎭', 'فرهنگ و سنت‌ها', 'culture', 'فرهنگ'],
      ['b1entertainment', 'Films, Books & Reviews 🎬', 'فیلم، کتاب و نقد', 'entertainment', 'سرگرمی'],
      ['b1transport', 'Transport & City Life 🚇', 'حمل‌ونقل و زندگی شهری', 'city transport', 'حمل‌ونقل شهری'],
      ['b1emergencies', 'Emergencies & Safety 🚨', 'شرایط اضطراری و ایمنی', 'safety', 'ایمنی'],
      ['b1services', 'Public Services & Appointments 🏛️', 'خدمات عمومی و وقت ملاقات', 'public services', 'خدمات عمومی'],
      ['b1presentations', 'Presentations, Goals & Progress 🎤', 'ارائه، هدف‌ها و پیشرفت', 'progress', 'پیشرفت'],
    ],
    b2: [
      ['b2leadership', 'Leadership & Team Management 👥', 'رهبری و مدیریت تیم', 'leadership', 'رهبری'],
      ['b2negotiation', 'Negotiation & Compromise 🤝', 'مذاکره و مصالحه', 'negotiation', 'مذاکره'],
      ['b2projects', 'Project Planning & Risk 📊', 'برنامه‌ریزی پروژه و ریسک', 'project risk', 'ریسک پروژه'],
      ['b2research', 'Research & Evidence 🔬', 'پژوهش و شواهد', 'research', 'پژوهش'],
      ['b2media', 'Media, Bias & Information 📰', 'رسانه، سوگیری و اطلاعات', 'media bias', 'سوگیری رسانه‌ای'],
      ['b2environment', 'Climate & Sustainability 🌍', 'اقلیم و پایداری', 'climate policy', 'سیاست اقلیمی'],
      ['b2economy', 'Economy & Cost of Living 📈', 'اقتصاد و هزینهٔ زندگی', 'the economy', 'اقتصاد'],
      ['b2society', 'Society & Social Change 🏙️', 'جامعه و تغییر اجتماعی', 'social change', 'تغییر اجتماعی'],
      ['b2education', 'Education Policy & Learning 🎓', 'سیاست آموزشی و یادگیری', 'education policy', 'سیاست آموزشی'],
      ['b2technology', 'Technology, Privacy & AI 🤖', 'فناوری، حریم خصوصی و هوش مصنوعی', 'digital privacy', 'حریم خصوصی دیجیتال'],
      ['b2healthcare', 'Healthcare & Public Policy 🏥', 'بهداشت و سیاست عمومی', 'healthcare policy', 'سیاست سلامت'],
      ['b2law', 'Law, Rules & Responsibility ⚖️', 'قانون و مسئولیت', 'the law', 'قانون'],
      ['b2culture', 'Culture, Identity & Language 🌐', 'فرهنگ، هویت و زبان', 'cultural identity', 'هویت فرهنگی'],
      ['b2science', 'Science & Ethical Questions 🧬', 'علم و پرسش‌های اخلاقی', 'scientific ethics', 'اخلاق علمی'],
      ['b2global', 'Global Issues & Cooperation 🌎', 'مسائل جهانی و همکاری', 'global cooperation', 'همکاری جهانی'],
      ['b2conflict', 'Conflict Resolution 🕊️', 'حل تعارض', 'conflict resolution', 'حل تعارض'],
      ['b2innovation', 'Innovation & Entrepreneurship 💡', 'نوآوری و کارآفرینی', 'innovation', 'نوآوری'],
      ['b2communication', 'Persuasion & Formal Communication ✉️', 'اقناع و ارتباط رسمی', 'persuasion', 'اقناع'],
      ['b2analysis', 'Problem Analysis & Solutions 🧩', 'تحلیل مسئله و راه‌حل', 'problem analysis', 'تحلیل مسئله'],
      ['b2debate', 'Debate, Viewpoints & Conclusions 🗣️', 'مناظره، دیدگاه‌ها و نتیجه‌گیری', 'different viewpoints', 'دیدگاه‌های گوناگون'],
    ],
    c1: [
      ['c1strategy', 'Strategic Planning & Foresight 🔭', 'برنامه‌ریزی راهبردی و آینده‌نگری', 'strategic foresight', 'آینده‌نگری راهبردی'],
      ['c1leadership', 'Executive Leadership & Governance 🏛️', 'رهبری اجرایی و حکمرانی', 'governance', 'حکمرانی'],
      ['c1diplomacy', 'Diplomacy & International Relations 🌐', 'دیپلماسی و روابط بین‌الملل', 'diplomacy', 'دیپلماسی'],
      ['c1economics', 'Economic Policy & Markets 📉', 'سیاست اقتصادی و بازارها', 'economic policy', 'سیاست اقتصادی'],
      ['c1law', 'Legal Reasoning & Justice ⚖️', 'استدلال حقوقی و عدالت', 'legal reasoning', 'استدلال حقوقی'],
      ['c1ethics', 'Ethics & Moral Dilemmas 🧭', 'اخلاق و دوراهی‌های اخلاقی', 'ethical dilemmas', 'دوراهی‌های اخلاقی'],
      ['c1science', 'Scientific Argument & Discovery 🔬', 'استدلال علمی و کشف', 'scientific inquiry', 'پژوهش علمی'],
      ['c1climate', 'Climate Policy & Resilience 🌍', 'سیاست اقلیمی و تاب‌آوری', 'climate resilience', 'تاب‌آوری اقلیمی'],
      ['c1technology', 'Emerging Technology & Society 🤖', 'فناوری نوظهور و جامعه', 'emerging technology', 'فناوری نوظهور'],
      ['c1media', 'Media Literacy & Public Discourse 📡', 'سواد رسانه‌ای و گفتمان عمومی', 'public discourse', 'گفتمان عمومی'],
      ['c1culture', 'Culture, Heritage & Identity 🏺', 'فرهنگ، میراث و هویت', 'cultural heritage', 'میراث فرهنگی'],
      ['c1psychology', 'Psychology & Human Behaviour 🧠', 'روان‌شناسی و رفتار انسان', 'human behaviour', 'رفتار انسان'],
      ['c1education', 'Education Reform & Pedagogy 🎓', 'اصلاح آموزش و روش تدریس', 'education reform', 'اصلاح آموزش'],
      ['c1health', 'Public Health & Medical Ethics 🏥', 'بهداشت عمومی و اخلاق پزشکی', 'public health', 'بهداشت عمومی'],
      ['c1business', 'Business Transformation & Innovation 💼', 'تحول کسب‌وکار و نوآوری', 'business transformation', 'تحول کسب‌وکار'],
      ['c1research', 'Academic Research & Methodology 📚', 'پژوهش دانشگاهی و روش‌شناسی', 'research methodology', 'روش‌شناسی پژوهش'],
      ['c1negotiation', 'Advanced Negotiation & Mediation 🤝', 'مذاکره و میانجی‌گری پیشرفته', 'mediation', 'میانجی‌گری'],
      ['c1rhetoric', 'Rhetoric & Persuasive Speaking 🎤', 'بلاغت و سخنرانی اقناعی', 'rhetoric', 'بلاغت'],
      ['c1urban', 'Urban Development & Public Space 🏙️', 'توسعهٔ شهری و فضای عمومی', 'urban development', 'توسعهٔ شهری'],
      ['c1analysis', 'Critical Analysis & Synthesis 🧩', 'تحلیل انتقادی و تلفیق', 'critical analysis', 'تحلیل انتقادی'],
    ],
    c2: [
      ['c2epistemology', 'Knowledge, Truth & Epistemology 🧠', 'دانش، حقیقت و معرفت‌شناسی', 'epistemology', 'معرفت‌شناسی'],
      ['c2philosophy', 'Political Philosophy & Power 🏛️', 'فلسفهٔ سیاسی و قدرت', 'political philosophy', 'فلسفهٔ سیاسی'],
      ['c2geopolitics', 'Geopolitics & Global Order 🌐', 'ژئوپلیتیک و نظم جهانی', 'geopolitics', 'ژئوپلیتیک'],
      ['c2macroeconomics', 'Macroeconomics & Systemic Risk 📊', 'اقتصاد کلان و ریسک سیستمی', 'macroeconomics', 'اقتصاد کلان'],
      ['c2jurisprudence', 'Jurisprudence & Constitutional Debate ⚖️', 'فلسفهٔ حقوق و مناظرهٔ قانون اساسی', 'jurisprudence', 'فلسفهٔ حقوق'],
      ['c2bioethics', 'Bioethics & Human Enhancement 🧬', 'اخلاق زیستی و ارتقای انسان', 'bioethics', 'اخلاق زیستی'],
      ['c2complexity', 'Complex Systems & Uncertainty 🕸️', 'سامانه‌های پیچیده و عدم قطعیت', 'complex systems', 'سامانه‌های پیچیده'],
      ['c2ecology', 'Ecological Limits & Adaptation 🌱', 'محدودیت‌های بوم‌شناختی و سازگاری', 'ecological adaptation', 'سازگاری بوم‌شناختی'],
      ['c2ai', 'Artificial Intelligence & Agency 🤖', 'هوش مصنوعی و عاملیت', 'artificial agency', 'عاملیت مصنوعی'],
      ['c2narrative', 'Narrative, Ideology & Representation 🎭', 'روایت، ایدئولوژی و بازنمایی', 'representation', 'بازنمایی'],
      ['c2aesthetics', 'Aesthetics & Cultural Criticism 🎨', 'زیبایی‌شناسی و نقد فرهنگی', 'aesthetics', 'زیبایی‌شناسی'],
      ['c2cognition', 'Cognition, Language & Consciousness 💭', 'شناخت، زبان و آگاهی', 'consciousness', 'آگاهی'],
      ['c2pedagogy', 'Advanced Pedagogy & Knowledge Transfer 📖', 'آموزش پیشرفته و انتقال دانش', 'knowledge transfer', 'انتقال دانش'],
      ['c2medicine', 'Medical Systems & Scarce Resources 🏥', 'نظام پزشکی و منابع محدود', 'medical allocation', 'تخصیص منابع پزشکی'],
      ['c2organization', 'Institutions, Incentives & Organisational Power 🏢', 'نهادها، مشوق‌ها و قدرت سازمانی', 'institutional power', 'قدرت نهادی'],
      ['c2methodology', 'Methodological Critique & Causality 🔎', 'نقد روش‌شناختی و علیت', 'causal inference', 'استنباط علّی'],
      ['c2peace', 'Peacebuilding & Transitional Justice 🕊️', 'صلح‌سازی و عدالت انتقالی', 'peacebuilding', 'صلح‌سازی'],
      ['c2discourse', 'Discourse, Framing & Persuasion 🗣️', 'گفتمان، چارچوب‌بندی و اقناع', 'discursive framing', 'چارچوب‌بندی گفتمانی'],
      ['c2future', 'Futures, Scenarios & Civilisation 🚀', 'آینده‌ها، سناریوها و تمدن', 'civilisational futures', 'آینده‌های تمدنی'],
      ['c2synthesis', 'Interdisciplinary Synthesis & Original Argument ✨', 'تلفیق میان‌رشته‌ای و استدلال اصیل', 'interdisciplinary synthesis', 'تلفیق میان‌رشته‌ای'],
    ],
  };

  const upperSentenceTemplates = {
    b1: [
      (en, fa) => [`I'd like to talk about ${en}.`, `می‌خواهم دربارهٔ ${fa} صحبت کنم.`],
      (en, fa) => [`Could you explain the main issue with ${en}?`, `می‌توانید مسئلهٔ اصلی مربوط به ${fa} را توضیح دهید؟`],
      () => ['In my experience, the situation has changed considerably.', 'طبق تجربهٔ من، شرایط تغییر زیادی کرده است.'],
      () => ['We should consider several options before deciding.', 'پیش از تصمیم‌گیری باید چند گزینه را بررسی کنیم.'],
      () => ['If we plan carefully, the situation will improve.', 'اگر با دقت برنامه‌ریزی کنیم، شرایط بهتر می‌شود.'],
      () => ['One advantage is that it saves time.', 'یک مزیت این است که در زمان صرفه‌جویی می‌کند.'],
      () => ['However, there may be some practical difficulties.', 'بااین‌حال، ممکن است دشواری‌های عملی وجود داشته باشد.'],
      () => ['I agree with the general idea, but I have one concern.', 'با ایدهٔ کلی موافقم، اما یک نگرانی دارم.'],
      () => ['What solution would you recommend?', 'چه راه‌حلی را پیشنهاد می‌کنید؟'],
      () => ['That sounds like a reasonable way forward.', 'این راهی منطقی برای ادامه به نظر می‌رسد.'],
    ],
    b2: [
      (en, fa) => [`We need to examine ${en} from several perspectives.`, `لازم است ${fa} را از چند دیدگاه بررسی کنیم.`],
      () => ['The evidence suggests that the current approach is incomplete.', 'شواهد نشان می‌دهد رویکرد کنونی کامل نیست.'],
      () => ['Although there are clear benefits, the risks should not be ignored.', 'با اینکه مزایای روشنی وجود دارد، نباید خطرها را نادیده گرفت.'],
      () => ['The outcome largely depends on how the issue is addressed.', 'نتیجه تا حد زیادی به شیوهٔ رسیدگی به موضوع بستگی دارد.'],
      () => ['A more balanced policy would take different needs into account.', 'سیاستی متعادل‌تر نیازهای گوناگون را در نظر می‌گیرد.'],
      () => ['Could you clarify the reasoning behind that conclusion?', 'می‌توانید استدلال پشت آن نتیجه‌گیری را روشن‌تر کنید؟'],
      () => ['The proposal is likely to have long-term consequences.', 'این پیشنهاد احتمالاً پیامدهای بلندمدتی خواهد داشت.'],
      () => ['On the one hand it is efficient; on the other hand it is costly.', 'از یک سو کارآمد است؛ از سوی دیگر پرهزینه است.'],
      () => ['Further research may reveal factors we have overlooked.', 'پژوهش بیشتر ممکن است عواملی را آشکار کند که نادیده گرفته‌ایم.'],
      () => ['Taking all factors into account, this seems the best option.', 'با درنظرگرفتن همهٔ عوامل، این بهترین گزینه به نظر می‌رسد.'],
    ],
    c1: [
      (en, fa) => [`A rigorous account of ${en} must distinguish evidence from assumption.`, `بررسی دقیق ${fa} باید شواهد را از پیش‌فرض جدا کند.`],
      () => ['The prevailing interpretation is persuasive, albeit not entirely conclusive.', 'تفسیر رایج قانع‌کننده است، هرچند کاملاً قطعی نیست.'],
      () => ['What appears straightforward is, on closer inspection, deeply contested.', 'آنچه ساده به نظر می‌رسد، با بررسی دقیق‌تر به‌شدت محل اختلاف است.'],
      () => ['The argument rests on premises that have yet to be adequately justified.', 'این استدلال بر مقدماتی استوار است که هنوز به‌اندازهٔ کافی توجیه نشده‌اند.'],
      () => ['Were the underlying conditions to change, the outcome might be radically different.', 'اگر شرایط زیربنایی تغییر کند، نتیجه ممکن است کاملاً متفاوت باشد.'],
      () => ['This perspective sheds light on dimensions that conventional accounts overlook.', 'این دیدگاه ابعادی را روشن می‌کند که روایت‌های متعارف نادیده می‌گیرند.'],
      () => ['It would be misleading to infer causation from correlation alone.', 'نتیجه‌گیری رابطهٔ علّی صرفاً از همبستگی گمراه‌کننده است.'],
      () => ['The proposal merits consideration, notwithstanding its practical limitations.', 'این پیشنهاد با وجود محدودیت‌های عملی شایستهٔ بررسی است.'],
      () => ['A more nuanced analysis would acknowledge both structural and individual factors.', 'تحلیلی دقیق‌تر هم عوامل ساختاری و هم عوامل فردی را به رسمیت می‌شناسد.'],
      () => ['The extent to which this principle applies remains open to debate.', 'میزان کاربرد این اصل همچنان محل بحث است.'],
      () => ['By reframing the question, we can identify previously invisible alternatives.', 'با بازتعریف پرسش می‌توانیم گزینه‌هایی را ببینیم که پیش‌تر پنهان بودند.'],
      () => ['The long-term implications are likely to outweigh the immediate benefits.', 'احتمالاً پیامدهای بلندمدت از مزایای فوری مهم‌تر خواهند بود.'],
      () => ['No single explanation can fully account for such a complex development.', 'هیچ توضیح واحدی نمی‌تواند چنین تحول پیچیده‌ای را کاملاً تبیین کند.'],
      () => ['The findings should be interpreted in light of the study’s methodological constraints.', 'یافته‌ها باید با توجه به محدودیت‌های روش‌شناختی پژوهش تفسیر شوند.'],
      () => ['There is a compelling case for revising the existing framework.', 'دلایل قانع‌کننده‌ای برای بازنگری چارچوب موجود وجود دارد.'],
      () => ['Even if the objective is desirable, the means require ethical scrutiny.', 'حتی اگر هدف مطلوب باشد، ابزار رسیدن به آن نیازمند بررسی اخلاقی است.'],
      () => ['The apparent consensus conceals significant differences in interpretation.', 'اجماع ظاهری تفاوت‌های مهم تفسیری را پنهان می‌کند.'],
      () => ['This conclusion follows only if we accept the initial premise.', 'این نتیجه فقط زمانی به دست می‌آید که فرض اولیه را بپذیریم.'],
      () => ['A sustainable response must reconcile competing priorities.', 'پاسخی پایدار باید اولویت‌های رقیب را با یکدیگر سازگار کند.'],
      () => ['On balance, the evidence supports a cautious rather than categorical conclusion.', 'در مجموع، شواهد از نتیجه‌گیری محتاطانه حمایت می‌کنند، نه قطعی.'],
    ],
    c2: [
      (en, fa) => [`Any definitive claim about ${en} risks obscuring its conceptual ambiguity.`, `هر ادعای قطعی دربارهٔ ${fa} ممکن است ابهام مفهومی آن را پنهان کند.`],
      () => ['The distinction is analytically useful, though ontologically unstable.', 'این تمایز از نظر تحلیلی مفید است، هرچند از نظر هستی‌شناختی ناپایدار است.'],
      () => ['The thesis derives its force less from proof than from rhetorical coherence.', 'قدرت این تز کمتر از اثبات و بیشتر از انسجام بلاغی آن ناشی می‌شود.'],
      () => ['Counterfactual reasoning exposes assumptions embedded in the dominant narrative.', 'استدلال خلاف‌واقع پیش‌فرض‌های نهفته در روایت غالب را آشکار می‌کند.'],
      () => ['What is presented as neutral may reproduce historically contingent hierarchies.', 'آنچه خنثی معرفی می‌شود ممکن است سلسله‌مراتب تاریخی و موقعیتی را بازتولید کند.'],
      () => ['The proposition is neither self-evident nor immune to conceptual revision.', 'این گزاره نه بدیهی است و نه از بازنگری مفهومی مصون.'],
      () => ['A dialectical reading reveals how opposing positions mutually constitute one another.', 'خوانش دیالکتیکی نشان می‌دهد مواضع مخالف چگونه یکدیگر را شکل می‌دهند.'],
      () => ['The explanatory framework conflates descriptive accuracy with normative legitimacy.', 'چارچوب تبیینی، دقت توصیفی را با مشروعیت هنجاری خلط می‌کند.'],
      () => ['Its apparent universality depends on excluding experiences that resist classification.', 'جهان‌شمولی ظاهری آن به حذف تجربه‌هایی وابسته است که در برابر طبقه‌بندی مقاومت می‌کنند.'],
      () => ['Epistemic humility is warranted where evidence remains radically underdetermined.', 'آنجا که شواهد به‌شدت نامتعین‌اند، فروتنی معرفتی ضروری است.'],
      () => ['The mechanism operates recursively, altering the conditions that produced it.', 'این سازوکار بازگشتی عمل می‌کند و شرایطی را که آن را پدید آورده تغییر می‌دهد.'],
      () => ['A genealogical approach would trace how the category acquired its authority.', 'رویکرد تبارشناختی بررسی می‌کند این مقوله چگونه اقتدار یافته است.'],
      () => ['The disagreement concerns the criteria of judgment, not merely their application.', 'اختلاف بر سر معیارهای داوری است، نه فقط کاربرد آن‌ها.'],
      () => ['Conceptual precision should not come at the expense of empirical complexity.', 'دقت مفهومی نباید به بهای نادیده‌گرفتن پیچیدگی تجربی تمام شود.'],
      () => ['The scenario remains plausible, albeit contingent on several unstable variables.', 'این سناریو محتمل است، هرچند به چند متغیر ناپایدار وابسته است.'],
      () => ['Its normative appeal does not resolve the problem of institutional implementation.', 'جذابیت هنجاری آن مشکل اجرای نهادی را حل نمی‌کند.'],
      () => ['The critique is strongest where it interrogates the terms of the debate itself.', 'این نقد زمانی نیرومندتر است که خودِ مفاهیم مناظره را به پرسش می‌گیرد.'],
      () => ['Multiple causal pathways may generate outcomes that appear superficially identical.', 'مسیرهای علّی متعدد ممکن است نتایجی ایجاد کنند که ظاهراً یکسان‌اند.'],
      () => ['The synthesis preserves productive tension rather than forcing artificial consensus.', 'این تلفیق به‌جای تحمیل اجماع مصنوعی، تنش سازنده را حفظ می‌کند.'],
      () => ['Ultimately, the question demands a reformulation rather than a definitive answer.', 'در نهایت، این پرسش بیش از پاسخ قطعی به بازصورت‌بندی نیاز دارد.'],
    ],
  };

  // C levels focus on fluent real-life speaking rather than academic prose.
  upperLevelTopics.c1 = [
    ['c1difficult', 'Handling a Difficult Conversation 🗣️', 'مدیریت یک گفت‌وگوی دشوار', 'difficult conversations', 'گفت‌وگوهای دشوار'],
    ['c1work', 'Speaking Up at Work 💼', 'بیان نظر در محیط کار', 'speaking up at work', 'بیان نظر در محل کار'],
    ['c1meeting', 'Leading a Meeting 📋', 'اداره‌کردن جلسه', 'leading meetings', 'ادارهٔ جلسه'],
    ['c1negotiation', 'Negotiating Pay & Conditions 🤝', 'مذاکره دربارهٔ حقوق و شرایط', 'work negotiations', 'مذاکرهٔ کاری'],
    ['c1complaint', 'Making a Strong but Polite Complaint 📞', 'شکایت جدی اما مؤدبانه', 'formal complaints', 'شکایت رسمی'],
    ['c1conflict', 'Resolving Conflict with Friends 🕊️', 'حل اختلاف با دوستان', 'personal conflict', 'اختلاف شخصی'],
    ['c1relationship', 'Talking About Relationships ❤️', 'صحبت دربارهٔ روابط', 'relationships', 'روابط'],
    ['c1boundaries', 'Setting Healthy Boundaries 🚧', 'تعیین مرزهای سالم', 'personal boundaries', 'مرزهای شخصی'],
    ['c1plans', 'Changing Plans Gracefully 📅', 'تغییر محترمانهٔ برنامه‌ها', 'changing plans', 'تغییر برنامه‌ها'],
    ['c1travel', 'Dealing with Travel Disruptions ✈️', 'مدیریت مشکلات سفر', 'travel disruptions', 'اختلال‌های سفر'],
    ['c1housing', 'Rent, Neighbours & Landlords 🏠', 'اجاره، همسایه و صاحب‌خانه', 'housing problems', 'مشکلات مسکن'],
    ['c1money', 'Money, Debt & Difficult Choices 💳', 'پول، بدهی و انتخاب‌های دشوار', 'money decisions', 'تصمیم‌های مالی'],
    ['c1health', 'Discussing Health in Detail 🩺', 'توضیح دقیق وضعیت سلامتی', 'health concerns', 'نگرانی‌های سلامتی'],
    ['c1support', 'Giving Emotional Support 🌷', 'حمایت عاطفی', 'emotional support', 'حمایت عاطفی'],
    ['c1news', 'Discussing News Without Arguing 📰', 'گفت‌وگو دربارهٔ اخبار بدون دعوا', 'news discussions', 'گفت‌وگوی خبری'],
    ['c1persuasion', 'Persuading Without Pressure 🎯', 'متقاعدکردن بدون فشار', 'persuasion', 'متقاعدسازی'],
    ['c1story', 'Telling an Engaging Story 🎬', 'تعریف داستانی جذاب', 'storytelling', 'داستان‌گویی'],
    ['c1humour', 'Humour, Sarcasm & Tone 😄', 'شوخی، طعنه و لحن', 'humour and tone', 'شوخی و لحن'],
    ['c1networking', 'Networking & Making Connections 🤝', 'شبکه‌سازی و ایجاد ارتباط', 'networking', 'شبکه‌سازی'],
    ['c1interview', 'Advanced Job Interviews 🎤', 'مصاحبهٔ شغلی پیشرفته', 'job interviews', 'مصاحبهٔ شغلی'],
  ];
  upperLevelTopics.c2 = [
    ['c2disagreement', 'Disagreeing Tactfully 🗣️', 'مخالفت سنجیده و محترمانه', 'tactful disagreement', 'مخالفت محترمانه'],
    ['c2crisis', 'Staying Calm in a Crisis 🚨', 'حفظ آرامش در بحران', 'crisis communication', 'ارتباط در بحران'],
    ['c2leadership', 'High-Stakes Leadership 👥', 'رهبری در موقعیت حساس', 'high-stakes leadership', 'رهبری در شرایط حساس'],
    ['c2negotiation', 'Breaking a Negotiation Deadlock 🤝', 'شکستن بن‌بست مذاکره', 'negotiation deadlocks', 'بن‌بست مذاکره'],
    ['c2apology', 'Apologies, Regret & Repair 🌿', 'عذرخواهی، پشیمانی و جبران', 'meaningful apologies', 'عذرخواهی مؤثر'],
    ['c2feedback', 'Giving Sensitive Feedback 💬', 'ارائهٔ بازخورد حساس', 'sensitive feedback', 'بازخورد حساس'],
    ['c2influence', 'Influence, Trust & Credibility 🎯', 'نفوذ، اعتماد و اعتبار', 'trust and credibility', 'اعتماد و اعتبار'],
    ['c2crossculture', 'Cross-Cultural Communication 🌍', 'ارتباط میان‌فرهنگی', 'cross-cultural communication', 'ارتباط میان‌فرهنگی'],
    ['c2subtext', 'Reading Between the Lines 🔎', 'درک منظور پنهان', 'hidden meaning', 'معنای پنهان'],
    ['c2emotion', 'Expressing Complex Emotions ❤️', 'بیان احساسات پیچیده', 'complex emotions', 'احساسات پیچیده'],
    ['c2change', 'Managing Major Life Changes 🧭', 'مدیریت تغییرهای بزرگ زندگی', 'major life changes', 'تغییرهای بزرگ زندگی'],
    ['c2privacy', 'Privacy & Personal Questions 🔐', 'حریم خصوصی و پرسش‌های شخصی', 'personal privacy', 'حریم خصوصی'],
    ['c2media', 'Challenging Misleading Information 📱', 'به‌چالش‌کشیدن اطلاعات گمراه‌کننده', 'misleading information', 'اطلاعات گمراه‌کننده'],
    ['c2ethics', 'Everyday Ethical Dilemmas ⚖️', 'دوراهی‌های اخلاقی روزمره', 'ethical choices', 'انتخاب‌های اخلاقی'],
    ['c2speech', 'Speaking to an Audience 🎤', 'سخنرانی برای جمع', 'public speaking', 'سخنرانی عمومی'],
    ['c2debate', 'Debating Without Sounding Aggressive 🧠', 'مناظره بدون لحن تهاجمی', 'respectful debate', 'مناظرهٔ محترمانه'],
    ['c2story', 'Nuanced Storytelling & Anecdotes 🎭', 'داستان‌گویی ظریف و خاطره', 'nuanced storytelling', 'داستان‌گویی ظریف'],
    ['c2career', 'Career Change & Reinvention 🚀', 'تغییر مسیر شغلی و شروع دوباره', 'career change', 'تغییر شغل'],
    ['c2community', 'Community Problems & Solutions 🏙️', 'مشکلات جامعه و راه‌حل‌ها', 'community solutions', 'راه‌حل‌های اجتماعی'],
    ['c2conversation', 'Sounding Natural & Fluent ✨', 'طبیعی و روان صحبت‌کردن', 'natural fluency', 'روانی طبیعی'],
  ];

  const naturalAdvancedTemplates = [
    (en, fa) => [`I've been meaning to talk to you about ${en}.`, `مدتی است می‌خواهم دربارهٔ ${fa} با تو صحبت کنم.`],
    () => ['I can see where you’re coming from, but I don’t entirely agree.', 'متوجه دیدگاهت هستم، اما کاملاً موافق نیستم.'],
    () => ['Could we take a step back and look at the bigger picture?', 'می‌توانیم کمی عقب‌تر برویم و تصویر کلی را ببینیم؟'],
    () => ['I may have misunderstood you, so let me check.', 'شاید منظورت را اشتباه فهمیده باشم، پس اجازه بده مطمئن شوم.'],
    () => ['That’s a fair point, although there’s another side to it.', 'نکتهٔ منصفانه‌ای است، هرچند جنبهٔ دیگری هم دارد.'],
    () => ['I’d rather be honest than pretend everything is fine.', 'ترجیح می‌دهم صادق باشم تا اینکه وانمود کنم همه‌چیز خوب است.'],
    () => ['Let’s not jump to conclusions before we know the facts.', 'قبل از دانستن واقعیت‌ها زود نتیجه‌گیری نکنیم.'],
    (en, fa) => [`What bothers me most about ${en} is the way it was handled.`, `چیزی که دربارهٔ ${fa} بیشتر آزارم می‌دهد، نحوهٔ مدیریت آن است.`],
    () => ['I’m open to changing my mind if you can show me another perspective.', 'اگر دیدگاه دیگری نشانم بدهی، آماده‌ام نظرم را تغییر دهم.'],
    () => ['We seem to be going in circles, so let’s focus on a solution.', 'به نظر می‌رسد دور خودمان می‌چرخیم؛ پس روی راه‌حل تمرکز کنیم.'],
    (en, fa) => [`To be completely honest, the situation with ${en} wasn’t what I expected.`, `کاملاً صادقانه بگویم، وضعیت ${fa} چیزی نبود که انتظار داشتم.`],
    (en, fa) => [`I didn’t bring up ${en} earlier because I needed time to think.`, `موضوع ${fa} را زودتر مطرح نکردم چون برای فکرکردن به زمان نیاز داشتم.`],
    () => ['As far as I’m concerned, respect has to go both ways.', 'از نظر من احترام باید دوطرفه باشد.'],
    () => ['Would you mind telling me what actually happened?', 'ممکن است بگویی واقعاً چه اتفاقی افتاد؟'],
    () => ['I appreciate your honesty, even though it’s difficult to hear.', 'از صداقتت قدردانی می‌کنم، حتی اگر شنیدنش دشوار باشد.'],
    (en, fa) => [`If I were in your position, I’d ask for more time to deal with ${en}.`, `اگر جای تو بودم، برای رسیدگی به ${fa} زمان بیشتری درخواست می‌کردم.`],
    () => ['There’s no point in blaming each other at this stage.', 'در این مرحله سرزنش‌کردن یکدیگر فایده‌ای ندارد.'],
    () => ['Let me put it another way so there’s no confusion.', 'اجازه بده طور دیگری بیانش کنم تا ابهامی نماند.'],
    () => ['We may not agree, but I think we understand each other better now.', 'شاید موافق نباشیم، اما فکر می‌کنم حالا همدیگر را بهتر درک می‌کنیم.'],
    () => ['Why don’t we sleep on it and talk again tomorrow?', 'چرا یک شب درباره‌اش فکر نکنیم و فردا دوباره صحبت نکنیم؟'],
  ];
  upperSentenceTemplates.c1 = naturalAdvancedTemplates;
  upperSentenceTemplates.c2 = naturalAdvancedTemplates;

  const naturalAdvancedVocabulary = {
    c1: [
      [(en) => `bring up ${en}`, (fa) => `موضوع ${fa} را مطرح کردن`],
      [(en) => `talk ${en} through`, (fa) => `${fa} را با گفت‌وگو بررسی کردن`],
      [(en) => `deal with ${en}`, (fa) => `به ${fa} رسیدگی کردن`],
      [(en) => `sort out ${en}`, (fa) => `مسئلهٔ ${fa} را حل‌وفصل کردن`],
      [(en) => `get your point across about ${en}`, (fa) => `منظور خود را دربارهٔ ${fa} روشن بیان کردن`],
      [(en) => `hear someone out on ${en}`, (fa) => `حرف کسی را دربارهٔ ${fa} کامل شنیدن`],
      [(en) => `clear up a misunderstanding about ${en}`, (fa) => `سوءتفاهم دربارهٔ ${fa} را برطرف کردن`],
      [(en) => `find common ground on ${en}`, (fa) => `دربارهٔ ${fa} به نقطهٔ مشترک رسیدن`],
      [(en) => `set the record straight about ${en}`, (fa) => `واقعیت مربوط به ${fa} را روشن کردن`],
      [(en) => `draw the line at ${en}`, (fa) => `برای ${fa} حد و مرز تعیین کردن`],
      [(en) => `meet someone halfway on ${en}`, (fa) => `دربارهٔ ${fa} با کسی مصالحه کردن`],
      [(en) => `keep someone in the loop about ${en}`, (fa) => `کسی را در جریان ${fa} نگه داشتن`],
      [(en) => `come to terms with ${en}`, (fa) => `با واقعیت ${fa} کنار آمدن`],
      [(en) => `look into ${en}`, (fa) => `${fa} را دقیق بررسی کردن`],
      [(en) => `follow up on ${en}`, (fa) => `موضوع ${fa} را پیگیری کردن`],
      [(en) => `weigh up options around ${en}`, (fa) => `گزینه‌های مربوط به ${fa} را سنجیدن`],
      [(en) => `take responsibility for ${en}`, (fa) => `مسئولیت ${fa} را پذیرفتن`],
      [(en) => `handle ${en} tactfully`, (fa) => `${fa} را با تدبیر مدیریت کردن`],
      [(en) => `reach an agreement on ${en}`, (fa) => `دربارهٔ ${fa} به توافق رسیدن`],
      [(en) => `move forward with ${en}`, (fa) => `موضوع ${fa} را رو به جلو بردن`],
    ],
    c2: [
      [(en) => `read between the lines about ${en}`, (fa) => `منظور پنهان در ${fa} را فهمیدن`],
      [(en) => `put ${en} into perspective`, (fa) => `${fa} را در چشم‌انداز درست دیدن`],
      [(en) => `reframe the conversation about ${en}`, (fa) => `گفت‌وگو دربارهٔ ${fa} را از زاویه‌ای تازه مطرح کردن`],
      [(en) => `pick up on a concern about ${en}`, (fa) => `متوجه نگرانی دربارهٔ ${fa} شدن`],
      [(en) => `acknowledge the nuance in ${en}`, (fa) => `ظرافت و پیچیدگی ${fa} را پذیرفتن`],
      [(en) => `challenge an assumption about ${en}`, (fa) => `یک پیش‌فرض دربارهٔ ${fa} را به چالش کشیدن`],
      [(en) => `defuse tension around ${en}`, (fa) => `تنش پیرامون ${fa} را کاهش دادن`],
      [(en) => `strike the right tone on ${en}`, (fa) => `برای صحبت دربارهٔ ${fa} لحن مناسبی انتخاب کردن`],
      [(en) => `make a compelling case for ${en}`, (fa) => `برای ${fa} استدلالی قانع‌کننده ارائه کردن`],
      [(en) => `push back politely on ${en}`, (fa) => `محترمانه با ${fa} مخالفت کردن`],
      [(en) => `address the elephant in the room about ${en}`, (fa) => `مشکل آشکار اما ناگفتهٔ ${fa} را مطرح کردن`],
      [(en) => `leave room for doubt about ${en}`, (fa) => `دربارهٔ ${fa} جایی برای تردید باقی گذاشتن`],
      [(en) => `take ${en} at face value`, (fa) => `${fa} را بر اساس ظاهر آن پذیرفتن`],
      [(en) => `get to the heart of ${en}`, (fa) => `به اصل موضوع ${fa} رسیدن`],
      [(en) => `draw a subtle distinction in ${en}`, (fa) => `در ${fa} تمایزی ظریف ایجاد کردن`],
      [(en) => `navigate ${en} with sensitivity`, (fa) => `${fa} را با ملاحظه و حساسیت مدیریت کردن`],
      [(en) => `build trust around ${en}`, (fa) => `دربارهٔ ${fa} اعتماد ایجاد کردن`],
      [(en) => `find a way out of ${en}`, (fa) => `برای ${fa} راه برون‌رفت پیدا کردن`],
      [(en) => `keep an open mind about ${en}`, (fa) => `دربارهٔ ${fa} ذهنی باز داشتن`],
      [(en) => `reach a well-considered decision on ${en}`, (fa) => `دربارهٔ ${fa} تصمیمی سنجیده گرفتن`],
    ],
  };

  Object.entries(upperLevelTopics).forEach(([level, topics]) => {
    lessonGroups[level] = topics.map(([id, title, titleFa, keyword, keywordFa]) => ({
      id, title, titleFa, keyword, keywordFa,
      description: level === 'b1' ? `Discuss ${keyword} clearly and confidently.` : level === 'b2' ? `Analyze and debate ${keyword} in depth.` : `Speak naturally and confidently about ${keyword}.`,
      sentences: upperSentenceTemplates[level].map((makeSentence, index) => {
        const [en, fa] = makeSentence(keyword, keywordFa);
        return { id: `${id}-${index + 1}`, en, fa };
      }),
    }));
  });
  lessonGroups.a1.push(...[{"id": "a1numbers", "title": "Birthdays, Numbers & Time", "description": "Say dates and tell the time.", "sentences": [{"id": "a1numbers-1", "en": "What time is it?", "fa": "ساعت چند است؟"}, {"id": "a1numbers-2", "en": "It is nine o’clock.", "fa": "ساعت نه است."}, {"id": "a1numbers-3", "en": "My birthday is on June fifth.", "fa": "تولدم پنجم ژوئن است."}, {"id": "a1numbers-4", "en": "I am twenty years old.", "fa": "من بیست سال دارم."}, {"id": "a1numbers-5", "en": "The class starts at ten.", "fa": "کلاس ساعت ده شروع می‌شود."}, {"id": "a1numbers-6", "en": "Today is Monday.", "fa": "امروز دوشنبه است."}, {"id": "a1numbers-7", "en": "My appointment is at half past two.", "fa": "قرار من ساعت دو و نیم است."}, {"id": "a1numbers-8", "en": "What is today’s date?", "fa": "امروز چندم است؟"}]}, {"id": "a1family", "title": "Family & Friends", "description": "Talk about family and friends.", "sentences": [{"id": "a1family-1", "en": "This is my mother.", "fa": "این مادر من است."}, {"id": "a1family-2", "en": "I have one brother and two sisters.", "fa": "من یک برادر و دو خواهر دارم."}, {"id": "a1family-3", "en": "My father is a teacher.", "fa": "پدرم معلم است."}, {"id": "a1family-4", "en": "Do you have any siblings?", "fa": "خواهر یا برادر داری؟"}, {"id": "a1family-5", "en": "My friend lives near me.", "fa": "دوستم نزدیک من زندگی می‌کند."}, {"id": "a1family-6", "en": "Her name is Maryam.", "fa": "اسم او مریم است."}, {"id": "a1family-7", "en": "We visit our grandparents on Fridays.", "fa": "جمعه‌ها به دیدن پدربزرگ و مادربزرگمان می‌رویم."}, {"id": "a1family-8", "en": "Is this your family?", "fa": "این خانوادهٔ تو است؟"}]}, {"id": "a1house", "title": "Home & Household Items", "description": "Describe rooms and everyday items.", "sentences": [{"id": "a1house-1", "en": "There is a table in the kitchen.", "fa": "یک میز در آشپزخانه هست."}, {"id": "a1house-2", "en": "The sofa is in the living room.", "fa": "مبل در اتاق نشیمن است."}, {"id": "a1house-3", "en": "Where is my phone?", "fa": "گوشی من کجاست؟"}, {"id": "a1house-4", "en": "It is on the desk.", "fa": "روی میز است."}, {"id": "a1house-5", "en": "There are two chairs in my room.", "fa": "دو صندلی در اتاقم هست."}, {"id": "a1house-6", "en": "The bathroom is next to the bedroom.", "fa": "حمام کنار اتاق خواب است."}, {"id": "a1house-7", "en": "Please close the door.", "fa": "لطفاً در را ببند."}, {"id": "a1house-8", "en": "I need a clean towel.", "fa": "من یک حولهٔ تمیز لازم دارم."}]}, {"id": "a1transport", "title": "Transportation", "description": "Ask about buses, trains, and tickets.", "sentences": [{"id": "a1transport-1", "en": "Where is the bus stop?", "fa": "ایستگاه اتوبوس کجاست؟"}, {"id": "a1transport-2", "en": "I go to work by bus.", "fa": "من با اتوبوس به محل کار می‌روم."}, {"id": "a1transport-3", "en": "How much is a ticket?", "fa": "قیمت بلیت چقدر است؟"}, {"id": "a1transport-4", "en": "One ticket, please.", "fa": "یک بلیت لطفاً."}, {"id": "a1transport-5", "en": "Does this train go to the city center?", "fa": "این قطار به مرکز شهر می‌رود؟"}, {"id": "a1transport-6", "en": "The next bus leaves at eight.", "fa": "اتوبوس بعدی ساعت هشت حرکت می‌کند."}, {"id": "a1transport-7", "en": "I need a taxi.", "fa": "من به تاکسی نیاز دارم."}, {"id": "a1transport-8", "en": "Please stop here.", "fa": "لطفاً همین‌جا توقف کنید."}]}, {"id": "a1weather", "title": "Weather", "description": "Describe the weather and seasons.", "sentences": [{"id": "a1weather-1", "en": "What is the weather like today?", "fa": "امروز هوا چطور است؟"}, {"id": "a1weather-2", "en": "It is sunny and warm.", "fa": "هوا آفتابی و گرم است."}, {"id": "a1weather-3", "en": "It is raining now.", "fa": "الان باران می‌بارد."}, {"id": "a1weather-4", "en": "Take your umbrella.", "fa": "چترت را بردار."}, {"id": "a1weather-5", "en": "It is cold in winter.", "fa": "در زمستان هوا سرد است."}, {"id": "a1weather-6", "en": "I like spring.", "fa": "من بهار را دوست دارم."}, {"id": "a1weather-7", "en": "Is it windy outside?", "fa": "بیرون باد می‌آید؟"}, {"id": "a1weather-8", "en": "Tomorrow will be hot.", "fa": "فردا هوا گرم خواهد بود."}]}, {"id": "a1hobbies", "title": "Sports & Hobbies", "description": "Talk about activities you enjoy.", "sentences": [{"id": "a1hobbies-1", "en": "What do you do for fun?", "fa": "برای تفریح چه کار می‌کنی؟"}, {"id": "a1hobbies-2", "en": "I like reading books.", "fa": "من کتاب خواندن را دوست دارم."}, {"id": "a1hobbies-3", "en": "I play football on Fridays.", "fa": "جمعه‌ها فوتبال بازی می‌کنم."}, {"id": "a1hobbies-4", "en": "Do you like music?", "fa": "موسیقی را دوست داری؟"}, {"id": "a1hobbies-5", "en": "My hobby is drawing.", "fa": "سرگرمی من نقاشی کشیدن است."}, {"id": "a1hobbies-6", "en": "We go swimming in summer.", "fa": "تابستان‌ها به شنا می‌رویم."}, {"id": "a1hobbies-7", "en": "I watch movies with my friends.", "fa": "با دوستانم فیلم تماشا می‌کنم."}, {"id": "a1hobbies-8", "en": "She plays tennis twice a week.", "fa": "او هفته‌ای دو بار تنیس بازی می‌کند."}]}, {"id": "a1health", "title": "Health & Asking for Help", "description": "Explain simple symptoms and ask for help.", "sentences": [{"id": "a1health-1", "en": "I do not feel well.", "fa": "حالم خوب نیست."}, {"id": "a1health-2", "en": "I have a headache.", "fa": "سردرد دارم."}, {"id": "a1health-3", "en": "Can you help me, please?", "fa": "می‌توانید لطفاً به من کمک کنید؟"}, {"id": "a1health-4", "en": "Where is the pharmacy?", "fa": "داروخانه کجاست؟"}, {"id": "a1health-5", "en": "I need a doctor.", "fa": "به پزشک نیاز دارم."}, {"id": "a1health-6", "en": "My stomach hurts.", "fa": "شکمم درد می‌کند."}, {"id": "a1health-7", "en": "Please call an ambulance.", "fa": "لطفاً آمبولانس خبر کنید."}, {"id": "a1health-8", "en": "I feel better now.", "fa": "الان حالم بهتر است."}]}, {"id": "a1phone", "title": "Phone & Messages", "description": "Make simple calls and send messages.", "sentences": [{"id": "a1phone-1", "en": "Can I call you later?", "fa": "می‌توانم بعداً به تو زنگ بزنم؟"}, {"id": "a1phone-2", "en": "What is your phone number?", "fa": "شمارهٔ تلفنت چیست؟"}, {"id": "a1phone-3", "en": "I will send you a message.", "fa": "برایت پیام می‌فرستم."}, {"id": "a1phone-4", "en": "Please call me back.", "fa": "لطفاً دوباره به من زنگ بزن."}, {"id": "a1phone-5", "en": "Can I speak to Sara?", "fa": "می‌توانم با سارا صحبت کنم؟"}, {"id": "a1phone-6", "en": "Sorry, she is not here.", "fa": "ببخشید، او اینجا نیست."}, {"id": "a1phone-7", "en": "I cannot hear you well.", "fa": "صدایت را خوب نمی‌شنوم."}, {"id": "a1phone-8", "en": "Did you get my message?", "fa": "پیام مرا دریافت کردی؟"}]}, {"id": "a1travel", "title": "Airport & Hotel", "description": "Ask for travel and hotel information.", "sentences": [{"id": "a1travel-1", "en": "Where is the check-in desk?", "fa": "کانتر پذیرش پرواز کجاست؟"}, {"id": "a1travel-2", "en": "Here is my passport.", "fa": "این هم گذرنامهٔ من."}, {"id": "a1travel-3", "en": "What time does the flight leave?", "fa": "پرواز چه ساعتی حرکت می‌کند؟"}, {"id": "a1travel-4", "en": "Where is gate five?", "fa": "گیت پنج کجاست؟"}, {"id": "a1travel-5", "en": "I have a hotel reservation.", "fa": "من در هتل اتاق رزرو کرده‌ام."}, {"id": "a1travel-6", "en": "Can I check in now?", "fa": "می‌توانم الان اتاقم را تحویل بگیرم؟"}, {"id": "a1travel-7", "en": "What is my room number?", "fa": "شمارهٔ اتاق من چیست؟"}, {"id": "a1travel-8", "en": "Is breakfast included?", "fa": "صبحانه شامل رزرو می‌شود؟"}]}]);
  lessonGroups.a2.push(...[{"id": "a2past", "title": "Last Weekend & Past Events", "description": "Talk about things that happened.", "sentences": [{"id": "a2past-1", "en": "What did you do last weekend?", "fa": "آخر هفتهٔ گذشته چه کار کردی؟"}, {"id": "a2past-2", "en": "I visited my aunt on Saturday.", "fa": "شنبه به دیدن خاله‌ام رفتم."}, {"id": "a2past-3", "en": "We watched a movie together.", "fa": "با هم فیلم تماشا کردیم."}, {"id": "a2past-4", "en": "Did you enjoy the trip?", "fa": "از سفر لذت بردی؟"}, {"id": "a2past-5", "en": "Yes, it was wonderful.", "fa": "بله، فوق‌العاده بود."}, {"id": "a2past-6", "en": "I stayed at home yesterday.", "fa": "دیروز در خانه ماندم."}, {"id": "a2past-7", "en": "The train arrived late.", "fa": "قطار دیر رسید."}, {"id": "a2past-8", "en": "When did you get back?", "fa": "چه زمانی برگشتی؟"}]}, {"id": "a2future", "title": "Future Plans & Goals", "description": "Discuss plans for the future.", "sentences": [{"id": "a2future-1", "en": "What are you going to do tomorrow?", "fa": "فردا قرار است چه کار کنی؟"}, {"id": "a2future-2", "en": "I am going to study English.", "fa": "قرار است انگلیسی بخوانم."}, {"id": "a2future-3", "en": "We are visiting my cousin next week.", "fa": "هفتهٔ آینده به دیدن پسرعمویم می‌رویم."}, {"id": "a2future-4", "en": "I hope to find a new job.", "fa": "امیدوارم شغل جدیدی پیدا کنم."}, {"id": "a2future-5", "en": "Are you free on Friday?", "fa": "جمعه وقت داری؟"}, {"id": "a2future-6", "en": "Let us meet after lunch.", "fa": "بیا بعد از ناهار همدیگر را ببینیم."}, {"id": "a2future-7", "en": "I will call you tonight.", "fa": "امشب به تو زنگ می‌زنم."}, {"id": "a2future-8", "en": "I want to learn to drive.", "fa": "می‌خواهم رانندگی یاد بگیرم."}]}, {"id": "a2preferences", "title": "Likes, Dislikes & Preferences", "description": "Express preferences and reasons.", "sentences": [{"id": "a2preferences-1", "en": "Do you prefer tea or coffee?", "fa": "چای را ترجیح می‌دهی یا قهوه؟"}, {"id": "a2preferences-2", "en": "I prefer tea to coffee.", "fa": "چای را به قهوه ترجیح می‌دهم."}, {"id": "a2preferences-3", "en": "I enjoy cooking at home.", "fa": "از آشپزی در خانه لذت می‌برم."}, {"id": "a2preferences-4", "en": "I do not like crowded places.", "fa": "جاهای شلوغ را دوست ندارم."}, {"id": "a2preferences-5", "en": "Why do you like this film?", "fa": "چرا این فیلم را دوست داری؟"}, {"id": "a2preferences-6", "en": "Because the story is interesting.", "fa": "چون داستانش جالب است."}, {"id": "a2preferences-7", "en": "Would you rather walk or take a taxi?", "fa": "ترجیح می‌دهی پیاده برویم یا تاکسی بگیریم؟"}, {"id": "a2preferences-8", "en": "I would rather walk.", "fa": "ترجیح می‌دهم پیاده بروم."}]}, {"id": "a2comparison", "title": "Comparing People & Places", "description": "Compare places and everyday things.", "sentences": [{"id": "a2comparison-1", "en": "This room is bigger than mine.", "fa": "این اتاق از اتاق من بزرگ‌تر است."}, {"id": "a2comparison-2", "en": "The bus is cheaper than a taxi.", "fa": "اتوبوس از تاکسی ارزان‌تر است."}, {"id": "a2comparison-3", "en": "Which city is more crowded?", "fa": "کدام شهر شلوغ‌تر است؟"}, {"id": "a2comparison-4", "en": "My sister is younger than me.", "fa": "خواهرم از من کوچک‌تر است."}, {"id": "a2comparison-5", "en": "This restaurant is better than the other one.", "fa": "این رستوران از آن یکی بهتر است."}, {"id": "a2comparison-6", "en": "The red shirt is the most expensive.", "fa": "پیراهن قرمز از همه گران‌تر است."}, {"id": "a2comparison-7", "en": "It is warmer today than yesterday.", "fa": "امروز از دیروز گرم‌تر است."}, {"id": "a2comparison-8", "en": "Which option do you prefer?", "fa": "کدام گزینه را ترجیح می‌دهی؟"}]}, {"id": "a2home", "title": "Renting a Room", "description": "Ask about a room and its conditions.", "sentences": [{"id": "a2home-1", "en": "Is this room still available?", "fa": "این اتاق هنوز خالی است؟"}, {"id": "a2home-2", "en": "How much is the rent each month?", "fa": "اجارهٔ ماهانه چقدر است؟"}, {"id": "a2home-3", "en": "Are bills included?", "fa": "هزینهٔ قبض‌ها شامل اجاره می‌شود؟"}, {"id": "a2home-4", "en": "Does the room have a window?", "fa": "اتاق پنجره دارد؟"}, {"id": "a2home-5", "en": "I would like to see the kitchen.", "fa": "می‌خواهم آشپزخانه را ببینم."}, {"id": "a2home-6", "en": "When can I move in?", "fa": "چه زمانی می‌توانم ساکن شوم؟"}, {"id": "a2home-7", "en": "The apartment is close to the station.", "fa": "آپارتمان به ایستگاه نزدیک است."}, {"id": "a2home-8", "en": "Can you send me the address?", "fa": "می‌توانید آدرس را برایم بفرستید؟"}]}, {"id": "a2shopping", "title": "Returns & Exchanges", "description": "Explain a problem with a purchase.", "sentences": [{"id": "a2shopping-1", "en": "I bought this yesterday.", "fa": "این را دیروز خریدم."}, {"id": "a2shopping-2", "en": "I would like to return it.", "fa": "می‌خواهم آن را پس بدهم."}, {"id": "a2shopping-3", "en": "Do you have the receipt?", "fa": "رسید را دارید؟"}, {"id": "a2shopping-4", "en": "It does not fit me.", "fa": "اندازه‌ام نیست."}, {"id": "a2shopping-5", "en": "Can I exchange it for a larger size?", "fa": "می‌توانم آن را با سایز بزرگ‌تر عوض کنم؟"}, {"id": "a2shopping-6", "en": "This item is damaged.", "fa": "این کالا آسیب دیده است."}, {"id": "a2shopping-7", "en": "How long does a refund take?", "fa": "بازپرداخت پول چقدر طول می‌کشد؟"}, {"id": "a2shopping-8", "en": "Thank you for your help.", "fa": "از کمکتان ممنونم."}]}, {"id": "a2restaurant", "title": "Restaurant Requests & Problems", "description": "Make requests and resolve a problem.", "sentences": [{"id": "a2restaurant-1", "en": "Could we have a table for three?", "fa": "می‌شود یک میز برای سه نفر داشته باشیم؟"}, {"id": "a2restaurant-2", "en": "I have a reservation under Azizi.", "fa": "به نام عزیزی رزرو دارم."}, {"id": "a2restaurant-3", "en": "Does this dish contain nuts?", "fa": "این غذا آجیل دارد؟"}, {"id": "a2restaurant-4", "en": "Could you make it less spicy?", "fa": "می‌توانید آن را کمتر تند درست کنید؟"}, {"id": "a2restaurant-5", "en": "I ordered soup, not salad.", "fa": "من سوپ سفارش دادم، نه سالاد."}, {"id": "a2restaurant-6", "en": "The food is cold.", "fa": "غذا سرد است."}, {"id": "a2restaurant-7", "en": "Could we have the bill, please?", "fa": "می‌شود لطفاً صورت‌حساب را بیاورید؟"}, {"id": "a2restaurant-8", "en": "Can we pay separately?", "fa": "می‌توانیم جداگانه حساب کنیم؟"}]}, {"id": "a2health", "title": "Symptoms & Doctor Appointments", "description": "Describe symptoms and arrange a visit.", "sentences": [{"id": "a2health-1", "en": "I would like to make an appointment.", "fa": "می‌خواهم وقت پزشک بگیرم."}, {"id": "a2health-2", "en": "I have had a cough for three days.", "fa": "سه روز است سرفه دارم."}, {"id": "a2health-3", "en": "Do you have a fever?", "fa": "تب دارید؟"}, {"id": "a2health-4", "en": "I feel dizzy in the morning.", "fa": "صبح‌ها سرگیجه دارم."}, {"id": "a2health-5", "en": "When did the pain start?", "fa": "درد از چه زمانی شروع شد؟"}, {"id": "a2health-6", "en": "It started on Monday.", "fa": "از دوشنبه شروع شد."}, {"id": "a2health-7", "en": "How often should I take this medicine?", "fa": "هر چند وقت یک‌بار باید این دارو را مصرف کنم؟"}, {"id": "a2health-8", "en": "Should I come back next week?", "fa": "باید هفتهٔ آینده دوباره مراجعه کنم؟"}]}, {"id": "a2work", "title": "Job Interviews & Experience", "description": "Describe your experience and ask questions.", "sentences": [{"id": "a2work-1", "en": "Tell me about your work experience.", "fa": "دربارهٔ سابقهٔ کارت بگو."}, {"id": "a2work-2", "en": "I worked in a shop for two years.", "fa": "دو سال در مغازه کار کردم."}, {"id": "a2work-3", "en": "What are your main skills?", "fa": "مهارت‌های اصلی‌ات چیست؟"}, {"id": "a2work-4", "en": "I can speak English and Persian.", "fa": "می‌توانم انگلیسی و فارسی صحبت کنم."}, {"id": "a2work-5", "en": "Why do you want this job?", "fa": "چرا این شغل را می‌خواهی؟"}, {"id": "a2work-6", "en": "I enjoy helping customers.", "fa": "از کمک به مشتریان لذت می‌برم."}, {"id": "a2work-7", "en": "When can you start?", "fa": "چه زمانی می‌توانی شروع کنی؟"}, {"id": "a2work-8", "en": "Could you explain the working hours?", "fa": "می‌توانید ساعت‌های کاری را توضیح دهید؟"}]}, {"id": "a2studies", "title": "Classes & Learning Goals", "description": "Discuss studies and progress.", "sentences": [{"id": "a2studies-1", "en": "What are you studying now?", "fa": "الان چه چیزی می‌خوانی؟"}, {"id": "a2studies-2", "en": "I am taking an English course.", "fa": "در یک دورهٔ انگلیسی شرکت می‌کنم."}, {"id": "a2studies-3", "en": "The lessons are getting harder.", "fa": "درس‌ها دارند سخت‌تر می‌شوند."}, {"id": "a2studies-4", "en": "I need to practice speaking more.", "fa": "باید صحبت‌کردن را بیشتر تمرین کنم."}, {"id": "a2studies-5", "en": "Could you explain this word?", "fa": "می‌توانید این کلمه را توضیح دهید؟"}, {"id": "a2studies-6", "en": "I have already finished my homework.", "fa": "تکلیفم را قبلاً تمام کرده‌ام."}, {"id": "a2studies-7", "en": "What do you want to learn next?", "fa": "بعد از این می‌خواهی چه یاد بگیری؟"}, {"id": "a2studies-8", "en": "I want to speak more confidently.", "fa": "می‌خواهم با اعتمادبه‌نفس بیشتری صحبت کنم."}]}, {"id": "a2travel", "title": "Travel Arrangements & Delays", "description": "Handle changes in travel plans.", "sentences": [{"id": "a2travel-1", "en": "I booked a ticket for Tuesday.", "fa": "برای سه‌شنبه بلیت رزرو کردم."}, {"id": "a2travel-2", "en": "Can I change my travel date?", "fa": "می‌توانم تاریخ سفرم را عوض کنم؟"}, {"id": "a2travel-3", "en": "My flight has been delayed.", "fa": "پروازم تأخیر داشته است."}, {"id": "a2travel-4", "en": "What time will we arrive?", "fa": "چه ساعتی می‌رسیم؟"}, {"id": "a2travel-5", "en": "Is there another train today?", "fa": "امروز قطار دیگری هست؟"}, {"id": "a2travel-6", "en": "I missed the bus because of traffic.", "fa": "به خاطر ترافیک از اتوبوس جا ماندم."}, {"id": "a2travel-7", "en": "Where can I get a refund?", "fa": "از کجا می‌توانم پولم را پس بگیرم؟"}, {"id": "a2travel-8", "en": "Please let me know about any changes.", "fa": "لطفاً هر تغییری را به من اطلاع دهید."}]}, {"id": "a2hotel", "title": "Hotel Check-in & Requests", "description": "Ask for help during a hotel stay.", "sentences": [{"id": "a2hotel-1", "en": "I have a reservation for two nights.", "fa": "برای دو شب اتاق رزرو کرده‌ام."}, {"id": "a2hotel-2", "en": "May I see your passport?", "fa": "ممکن است گذرنامه‌تان را ببینم؟"}, {"id": "a2hotel-3", "en": "Could I have a quiet room?", "fa": "می‌توانم یک اتاق ساکت داشته باشم؟"}, {"id": "a2hotel-4", "en": "The air conditioner is not working.", "fa": "دستگاه تهویه کار نمی‌کند."}, {"id": "a2hotel-5", "en": "Could someone check it, please?", "fa": "می‌شود لطفاً کسی آن را بررسی کند؟"}, {"id": "a2hotel-6", "en": "What time is check-out?", "fa": "ساعت تحویل اتاق چه زمانی است؟"}, {"id": "a2hotel-7", "en": "Is breakfast served here?", "fa": "صبحانه اینجا سرو می‌شود؟"}, {"id": "a2hotel-8", "en": "Can you call a taxi for me?", "fa": "می‌توانید برایم تاکسی بگیرید؟"}]}, {"id": "a2directions", "title": "Giving Detailed Directions", "description": "Explain routes and landmarks.", "sentences": [{"id": "a2directions-1", "en": "Go straight until you reach the square.", "fa": "مستقیم برو تا به میدان برسی."}, {"id": "a2directions-2", "en": "Turn left after the pharmacy.", "fa": "بعد از داروخانه به چپ بپیچ."}, {"id": "a2directions-3", "en": "The museum is across from the park.", "fa": "موزه روبه‌روی پارک است."}, {"id": "a2directions-4", "en": "It is about ten minutes on foot.", "fa": "پیاده حدود ده دقیقه راه است."}, {"id": "a2directions-5", "en": "Take the second street on the right.", "fa": "دومین خیابان سمت راست را بپیچ."}, {"id": "a2directions-6", "en": "You will see a bank on the corner.", "fa": "یک بانک سر نبش می‌بینی."}, {"id": "a2directions-7", "en": "Is there a shorter way?", "fa": "راه کوتاه‌تری هست؟"}, {"id": "a2directions-8", "en": "You can take the bus instead.", "fa": "به‌جایش می‌توانی اتوبوس بگیری."}]}, {"id": "a2messages", "title": "Emails & Phone Conversations", "description": "Send updates and request information.", "sentences": [{"id": "a2messages-1", "en": "I am writing to ask about the course.", "fa": "برای پرسیدن دربارهٔ دوره ایمیل می‌نویسم."}, {"id": "a2messages-2", "en": "Could you send me the details?", "fa": "می‌توانید جزئیات را برایم بفرستید؟"}, {"id": "a2messages-3", "en": "I will reply by tomorrow.", "fa": "تا فردا پاسخ می‌دهم."}, {"id": "a2messages-4", "en": "Can you hold for a moment?", "fa": "می‌توانید یک لحظه پشت خط بمانید؟"}, {"id": "a2messages-5", "en": "The line is breaking up.", "fa": "صدا مدام قطع و وصل می‌شود."}, {"id": "a2messages-6", "en": "Could you repeat the last part?", "fa": "می‌توانید بخش آخر را تکرار کنید؟"}, {"id": "a2messages-7", "en": "I left you a voicemail.", "fa": "برایت پیام صوتی گذاشتم."}, {"id": "a2messages-8", "en": "Please confirm that you received my email.", "fa": "لطفاً تأیید کنید که ایمیلم را دریافت کرده‌اید."}]}, {"id": "a2weather", "title": "Weather & Changing Plans", "description": "Change a plan because of the weather.", "sentences": [{"id": "a2weather-1", "en": "It looks like it will rain.", "fa": "به نظر می‌رسد باران می‌بارد."}, {"id": "a2weather-2", "en": "If it rains, we will stay inside.", "fa": "اگر باران ببارد، داخل می‌مانیم."}, {"id": "a2weather-3", "en": "The forecast says it will be windy.", "fa": "پیش‌بینی هوا می‌گوید باد می‌آید."}, {"id": "a2weather-4", "en": "Should we change our plans?", "fa": "باید برنامه‌مان را عوض کنیم؟"}, {"id": "a2weather-5", "en": "We can go tomorrow instead.", "fa": "می‌توانیم به‌جایش فردا برویم."}, {"id": "a2weather-6", "en": "It is too cold for a picnic.", "fa": "برای پیک‌نیک خیلی سرد است."}, {"id": "a2weather-7", "en": "Take a jacket with you.", "fa": "یک ژاکت با خودت ببر."}, {"id": "a2weather-8", "en": "Let us check the weather again tonight.", "fa": "بیا امشب دوباره هوا را بررسی کنیم."}]}, {"id": "a2hobbies", "title": "Hobbies & Recent Experiences", "description": "Describe recent activities and interests.", "sentences": [{"id": "a2hobbies-1", "en": "Have you tried painting before?", "fa": "قبلاً نقاشی را امتحان کرده‌ای؟"}, {"id": "a2hobbies-2", "en": "I started learning the guitar last month.", "fa": "ماه گذشته یادگیری گیتار را شروع کردم."}, {"id": "a2hobbies-3", "en": "I have recently joined a sports club.", "fa": "اخیراً عضو یک باشگاه ورزشی شده‌ام."}, {"id": "a2hobbies-4", "en": "How often do you practice?", "fa": "هر چند وقت یک‌بار تمرین می‌کنی؟"}, {"id": "a2hobbies-5", "en": "I usually practice twice a week.", "fa": "معمولاً هفته‌ای دو بار تمرین می‌کنم."}, {"id": "a2hobbies-6", "en": "It is more fun with friends.", "fa": "با دوستان سرگرم‌کننده‌تر است."}, {"id": "a2hobbies-7", "en": "I would like to try something new.", "fa": "دوست دارم چیز جدیدی را امتحان کنم."}, {"id": "a2hobbies-8", "en": "What hobby would you recommend?", "fa": "چه سرگرمی‌ای پیشنهاد می‌کنی؟"}]}, {"id": "a2repair", "title": "Repairs & Services", "description": "Explain a fault and request repair.", "sentences": [{"id": "a2repair-1", "en": "My phone is not working properly.", "fa": "گوشی‌ام درست کار نمی‌کند."}, {"id": "a2repair-2", "en": "The screen stopped working yesterday.", "fa": "صفحه‌نمایش دیروز از کار افتاد."}, {"id": "a2repair-3", "en": "Could you take a look at it?", "fa": "می‌توانید نگاهی به آن بیندازید؟"}, {"id": "a2repair-4", "en": "How much will the repair cost?", "fa": "تعمیر چقدر هزینه دارد؟"}, {"id": "a2repair-5", "en": "Is the repair covered by the warranty?", "fa": "تعمیر شامل ضمانت می‌شود؟"}, {"id": "a2repair-6", "en": "When can I pick it up?", "fa": "چه زمانی می‌توانم آن را تحویل بگیرم؟"}, {"id": "a2repair-7", "en": "Please call me before replacing any parts.", "fa": "لطفاً پیش از تعویض هر قطعه‌ای به من زنگ بزنید."}, {"id": "a2repair-8", "en": "I would like an estimate first.", "fa": "اول برآورد هزینه می‌خواهم."}]}, {"id": "a2opinions", "title": "Opinions & Reasons", "description": "Give opinions and simple reasons.", "sentences": [{"id": "a2opinions-1", "en": "What do you think about this idea?", "fa": "دربارهٔ این ایده چه فکر می‌کنی؟"}, {"id": "a2opinions-2", "en": "I think it is useful because it saves time.", "fa": "فکر می‌کنم مفید است چون در وقت صرفه‌جویی می‌کند."}, {"id": "a2opinions-3", "en": "I agree with you.", "fa": "با تو موافقم."}, {"id": "a2opinions-4", "en": "I am not sure I agree.", "fa": "مطمئن نیستم موافق باشم."}, {"id": "a2opinions-5", "en": "In my opinion, the second option is better.", "fa": "به نظر من گزینهٔ دوم بهتر است."}, {"id": "a2opinions-6", "en": "Why do you prefer it?", "fa": "چرا آن را ترجیح می‌دهی؟"}, {"id": "a2opinions-7", "en": "It is easier and cheaper.", "fa": "آسان‌تر و ارزان‌تر است."}, {"id": "a2opinions-8", "en": "Let us decide together.", "fa": "بیا با هم تصمیم بگیریم."}]}, {"id": "a2stories", "title": "Telling a Short Story", "description": "Tell events in a clear order.", "sentences": [{"id": "a2stories-1", "en": "Yesterday I went to the market.", "fa": "دیروز به بازار رفتم."}, {"id": "a2stories-2", "en": "First, I bought some fruit.", "fa": "اول کمی میوه خریدم."}, {"id": "a2stories-3", "en": "Then I met an old friend.", "fa": "بعد یکی از دوستان قدیمی‌ام را دیدم."}, {"id": "a2stories-4", "en": "We had coffee at a small café.", "fa": "در یک کافهٔ کوچک قهوه خوردیم."}, {"id": "a2stories-5", "en": "While we were talking, it started to rain.", "fa": "وقتی داشتیم صحبت می‌کردیم، باران شروع شد."}, {"id": "a2stories-6", "en": "We waited until the rain stopped.", "fa": "صبر کردیم تا باران بند آمد."}, {"id": "a2stories-7", "en": "Finally, I took a taxi home.", "fa": "آخر سر با تاکسی به خانه رفتم."}, {"id": "a2stories-8", "en": "It was a lovely afternoon.", "fa": "بعدازظهر خیلی خوبی بود."}]}]);

  // Complete every A2 lesson with ten translated practice sentences.
  const expandedA2Sentences = {
    a2routine: [['Shall we meet outside the library?', 'جلوی کتابخانه همدیگر را ببینیم؟'], ['I am busy in the morning, but I am free after lunch.', 'صبح سرم شلوغ است، اما بعد از ناهار وقت دارم.'], ['Please let me know if your plans change.', 'اگر برنامه‌ات تغییر کرد، لطفاً به من خبر بده.']],
    a2past: [['We walked around the old part of the city.', 'در بخش قدیمی شهر قدم زدیم.'], ['I forgot to take my camera with me.', 'فراموش کردم دوربینم را با خودم ببرم.']],
    a2future: [['I am saving money for a long trip.', 'برای یک سفر طولانی پول پس‌انداز می‌کنم.'], ['She plans to start a new course next month.', 'او قصد دارد ماه آینده یک دورهٔ جدید را شروع کند.']],
    a2preferences: [['I prefer quiet cafés because I can read there.', 'کافه‌های آرام را ترجیح می‌دهم چون می‌توانم آنجا مطالعه کنم.'], ['He is interested in music, but he dislikes dancing.', 'او به موسیقی علاقه دارد، اما رقصیدن را دوست ندارد.']],
    a2comparison: [['This route is safer but a little longer.', 'این مسیر امن‌تر است، اما کمی طولانی‌تر است.'], ['My new phone is much faster than my old one.', 'گوشی جدیدم خیلی سریع‌تر از گوشی قدیمی‌ام است.']],
    a2home: [['The landlord asked for one month’s deposit.', 'صاحب‌خانه یک ماه ودیعه خواست.'], ['The neighborhood is quiet and convenient.', 'محله آرام و مناسب است.']],
    a2shopping: [['The assistant offered me a full refund.', 'فروشنده بازپرداخت کامل پول را به من پیشنهاد داد.'], ['This jacket has a small mark on the sleeve.', 'این کت روی آستینش یک لکهٔ کوچک دارد.']],
    a2restaurant: [['Excuse me, we have been waiting for twenty minutes.', 'ببخشید، بیست دقیقه است که منتظریم.'], ['Could you bring us some more water?', 'می‌توانید کمی آب بیشتر برایمان بیاورید؟']],
    a2health: [['The doctor advised me to rest for two days.', 'پزشک به من توصیه کرد دو روز استراحت کنم.'], ['I am feeling better, but my throat still hurts.', 'حالم بهتر است، اما گلویم هنوز درد می‌کند.']],
    a2work: [['I am responsible for answering customer emails.', 'من مسئول پاسخ‌دادن به ایمیل‌های مشتریان هستم.'], ['I learned how to work well in a team.', 'یاد گرفتم چگونه در یک تیم خوب کار کنم.']],
    a2studies: [['I take notes while the teacher is speaking.', 'وقتی معلم صحبت می‌کند یادداشت برمی‌دارم.'], ['Practicing every day has improved my pronunciation.', 'تمرین روزانه تلفظم را بهتر کرده است.']],
    a2travel: [['The airline changed the departure gate.', 'شرکت هواپیمایی گیت خروج را تغییر داد.'], ['We arrived at the station just in time.', 'درست به‌موقع به ایستگاه رسیدیم.']],
    a2hotel: [['Could you send some clean towels to my room?', 'می‌توانید چند حولهٔ تمیز به اتاقم بفرستید؟'], ['The receptionist offered us a different room.', 'مسئول پذیرش اتاق دیگری به ما پیشنهاد داد.']],
    a2directions: [['Walk past the post office and cross the bridge.', 'از ادارهٔ پست رد شو و از پل عبور کن.'], ['If you reach the hospital, you have gone too far.', 'اگر به بیمارستان رسیدی، یعنی بیش از حد جلو رفته‌ای.']],
    a2messages: [['I am calling to confirm tomorrow’s appointment.', 'تماس گرفته‌ام تا قرار فردا را تأیید کنم.'], ['Please leave your name and number after the beep.', 'لطفاً بعد از صدای بوق نام و شماره‌تان را بگویید.']],
    a2weather: [['The temperature may fall below zero tonight.', 'ممکن است دما امشب به زیر صفر برسد.'], ['The sky is clearing, so we can go for a walk.', 'آسمان در حال صاف‌شدن است، پس می‌توانیم پیاده‌روی کنیم.']],
    a2hobbies: [['Photography helps me notice small details.', 'عکاسی کمک می‌کند به جزئیات کوچک توجه کنم.'], ['I have not had much time for my hobbies recently.', 'اخیراً وقت زیادی برای سرگرمی‌هایم نداشته‌ام.']],
    a2repair: [['The technician said the battery needs replacing.', 'تعمیرکار گفت باتری باید تعویض شود.'], ['Please give me a written estimate before you begin.', 'لطفاً پیش از شروع یک برآورد کتبی به من بدهید.']],
    a2opinions: [['I understand your point, but I see it differently.', 'منظورت را درک می‌کنم، اما دیدگاه متفاوتی دارم.'], ['We should consider both advantages and disadvantages.', 'باید هم مزایا و هم معایب را در نظر بگیریم.']],
    a2stories: [['Suddenly, we heard a loud noise outside.', 'ناگهان صدای بلندی از بیرون شنیدیم.'], ['In the end, everything turned out well.', 'در پایان، همه‌چیز به‌خوبی پیش رفت.']],
  };
  lessonGroups.a2.forEach((lesson) => {
    (expandedA2Sentences[lesson.id] || []).forEach(([en, fa], index) => {
      if (!lesson.sentences.some((sentence) => sentence.en === en)) {
        lesson.sentences.push({ id: `${lesson.id}-extra-${index + 1}`, en, fa });
      }
    });
  });

  // Keep A2 numbering, list order and lesson pages permanently aligned.
  const a2LessonOrder = ['a2routine', 'a2past', 'a2future', 'a2preferences', 'a2comparison', 'a2home', 'a2shopping', 'a2restaurant', 'a2health', 'a2work', 'a2studies', 'a2travel', 'a2hotel', 'a2directions', 'a2messages', 'a2weather', 'a2hobbies', 'a2repair', 'a2opinions', 'a2stories'];
  lessonGroups.a2.sort((a, b) => a2LessonOrder.indexOf(a.id) - a2LessonOrder.indexOf(b.id));

  // Keep ready A1 lessons in the same order as the published curriculum.
  const a1LessonOrder = ['intro1', 'birthday1', 'a1numbers', 'a1family', 'colors1', 'animals1', 'a1house', 'b3', 'b1', 'b5', 'b4', 'directions1', 'a1transport', 'a1weather', 'a1hobbies', 'school1', 'a1health', 'a1phone', 'a1travel', 'mechanic1'];
  lessonGroups.a1.sort((a, b) => a1LessonOrder.indexOf(a.id) - a1LessonOrder.indexOf(b.id));

  const expandedA1Sentences = {
    a1numbers: [
      ['The meeting is at quarter past three.', 'جلسه ساعت سه و ربع است.'],
      ['My birthday is in September.', 'تولد من در ماه سپتامبر است.'],
      ['There are thirty students in the class.', 'سی دانش‌آموز در کلاس هستند.'],
      ['I get home at six forty-five.', 'من ساعت شش و چهل‌وپنج دقیقه به خانه می‌رسم.'],
    ],
    a1family: [
      ['This is my aunt.', 'این خالهٔ من است.'],
      ['My cousin is ten years old.', 'پسرخالهٔ من ده سال دارد.'],
      ['We have dinner together.', 'ما با هم شام می‌خوریم.'],
      ['My grandparents live in Shiraz.', 'پدربزرگ و مادربزرگم در شیراز زندگی می‌کنند.'],
    ],
    a1weather: [
      ['The sky is cloudy today.', 'امروز آسمان ابری است.'],
      ['It may snow tonight.', 'ممکن است امشب برف ببارد.'],
      ['Summer is hot and dry.', 'تابستان گرم و خشک است.'],
      ['Wear a coat because it is cold.', 'چون هوا سرد است پالتو بپوش.'],
    ],
    a1hobbies: [
      ['I ride my bike after work.', 'من بعد از کار دوچرخه‌سواری می‌کنم.'],
      ['He takes photos on weekends.', 'او آخر هفته‌ها عکس می‌گیرد.'],
      ['We listen to music together.', 'ما با هم به موسیقی گوش می‌دهیم.'],
      ['Do you want to play chess?', 'می‌خواهی شطرنج بازی کنی؟'],
    ],
    a1health: [
      ['I have a sore throat.', 'گلودرد دارم.'],
      ['Take this medicine twice a day.', 'این دارو را روزی دو بار مصرف کن.'],
      ['You should drink more water.', 'باید آب بیشتری بنوشی.'],
      ['Where does it hurt?', 'کجایت درد می‌کند؟'],
    ],
    a1phone: [
      ['Please leave a message.', 'لطفاً پیام بگذارید.'],
      ['My battery is almost empty.', 'شارژ باتری من تقریباً تمام شده است.'],
      ['I will text you the address.', 'آدرس را برایت پیامک می‌کنم.'],
      ['The signal is weak here.', 'اینجا آنتن ضعیف است.'],
    ],
    a1travel: [
      ['I need a single room.', 'من یک اتاق یک‌نفره می‌خواهم.'],
      ['What time is check-out?', 'ساعت تحویل اتاق چه زمانی است؟'],
      ['My flight is delayed.', 'پرواز من تأخیر دارد.'],
      ['Could you call a taxi for me?', 'می‌توانید برای من تاکسی بگیرید؟'],
    ],
    mechanic1: [
      ['The engine makes a strange noise.', 'موتور صدای عجیبی می‌دهد.'],
      ['Please check the brakes.', 'لطفاً ترمزها را بررسی کنید.'],
      ['The car needs an oil change.', 'ماشین به تعویض روغن نیاز دارد.'],
      ['Can you repair it today?', 'می‌توانید امروز آن را تعمیر کنید؟'],
      ['I think the battery is dead.', 'فکر می‌کنم باتری خالی شده است.'],
    ],
  };
  Object.entries(expandedA1Sentences).forEach(([lessonId, sentencePairs]) => {
    const lesson = lessonGroups.a1.find((item) => item.id === lessonId);
    sentencePairs.forEach(([en, fa], index) => {
      const id = `${lessonId}-extra-${index + 1}`;
      if (lesson && !lesson.sentences.some((sentence) => sentence.id === id)) lesson.sentences.push({ id, en, fa });
    });
  });

  const lessonLearningContent = {
    b1: {
      grammar: {
        title: 'Polite requests with “Can I have…?”',
        titleFa: 'درخواست مؤدبانه با «می‌توانم ... داشته باشم؟»',
        formula: 'Can I have + thing + please?',
        explanation: 'Use this structure to order food or drinks politely.',
        explanationFa: 'از این ساختار برای سفارش مؤدبانهٔ غذا یا نوشیدنی استفاده می‌کنیم.',
        examples: ['Can I have a coffee, please?', 'Can I have the menu, please?', 'Can I pay by card?'],
      },
      vocabulary: [
        { word: 'coffee', meaning: 'قهوه', phrase: 'a cup of coffee' },
        { word: 'cappuccino', meaning: 'کاپوچینو', phrase: 'a hot cappuccino' },
        { word: 'please', meaning: 'لطفاً', phrase: 'please and thank you' },
        { word: 'pay', meaning: 'پرداخت کردن', phrase: 'pay by card' },
        { word: 'card', meaning: 'کارت', phrase: 'a bank card' },
      ],
    },
    b2: {
      grammar: {
        title: 'Questions with “Where” and “What time”',
        titleFa: 'سؤال با Where و What time',
        formula: 'Where is + place? / What time is + event?',
        explanation: 'Use these question forms to ask about places and times.',
        explanationFa: 'با این ساختارها دربارهٔ مکان و زمان سؤال می‌پرسیم.',
        examples: ['Where is the check-in desk?', 'What time is boarding?', 'Where is gate twelve?'],
      },
      vocabulary: [
        { word: 'airport', meaning: 'فرودگاه', phrase: 'at the airport' },
        { word: 'check-in', meaning: 'پذیرش پرواز', phrase: 'check-in desk' },
        { word: 'boarding', meaning: 'سوارشدن', phrase: 'boarding time' },
        { word: 'gate', meaning: 'گیت خروجی', phrase: 'departure gate' },
      ],
    },
    b3: {
      grammar: {
        title: 'Present simple for routines',
        titleFa: 'حال ساده برای کارهای روزمره',
        formula: 'I + base verb + time expression',
        explanation: 'Use the present simple for habits and repeated routines.',
        explanationFa: 'برای عادت‌ها و کارهای تکراری از زمان حال ساده استفاده می‌کنیم.',
        examples: ['I wake up at seven.', 'I make breakfast every morning.', 'I go to bed at eleven.'],
      },
      vocabulary: [
        { word: 'wake up', meaning: 'بیدار شدن', phrase: 'wake up early' },
        { word: 'breakfast', meaning: 'صبحانه', phrase: 'make breakfast' },
        { word: 'morning', meaning: 'صبح', phrase: 'every morning' },
        { word: 'bed', meaning: 'تختخواب', phrase: 'go to bed' },
      ],
    },
    b4: {
      grammar: {
        title: 'Shopping questions',
        titleFa: 'سؤال‌های خرید',
        formula: 'How much is…? / Do you have…? / Can I…?',
        explanation: 'Use these patterns to ask about price, availability, and permission.',
        explanationFa: 'با این الگوها دربارهٔ قیمت، موجودی و اجازه سؤال می‌پرسیم.',
        examples: ['How much is this?', 'Do you have this in blue?', 'Can I try this on?'],
      },
      vocabulary: [
        { word: 'much', meaning: 'مقدار / قیمت', phrase: 'How much?' },
        { word: 'blue', meaning: 'آبی', phrase: 'in blue' },
        { word: 'try on', meaning: 'پرو کردن', phrase: 'try this on' },
        { word: 'size', meaning: 'اندازه', phrase: 'my size' },
      ],
    },
    b5: {
      grammar: {
        title: 'Ordering with “would like”',
        titleFa: 'سفارش با would like',
        formula: 'I would like + thing, please.',
        explanation: '“Would like” is a polite way to say what you want.',
        explanationFa: 'Would like روشی مؤدبانه برای گفتن خواسته است.',
        examples: ['I would like the chicken, please.', "I'd like chicken and rice, please.", 'I would like some water, please.'],
      },
      vocabulary: [
        { word: 'table', meaning: 'میز', phrase: 'a table for two' },
        { word: 'menu', meaning: 'منو', phrase: 'see the menu' },
        { word: 'waiter', meaning: 'پیشخدمت', phrase: 'ask the waiter' },
        { word: 'order', meaning: 'سفارش دادن', phrase: 'order food' },
        { word: 'chicken', meaning: 'مرغ', phrase: 'chicken and rice' },
        { word: 'rice', meaning: 'برنج', phrase: 'a bowl of rice' },
        { word: 'salad', meaning: 'سالاد', phrase: 'a fresh salad' },
        { word: 'water', meaning: 'آب', phrase: 'a glass of water' },
        { word: 'drink', meaning: 'نوشیدنی', phrase: 'a cold drink' },
        { word: 'spicy', meaning: 'تند', phrase: 'spicy food' },
        { word: 'meat', meaning: 'گوشت', phrase: 'have meat' },
        { word: 'plate', meaning: 'بشقاب', phrase: 'another plate' },
        { word: 'bill', meaning: 'صورت\u200cحساب', phrase: 'ask for the bill' },
        { word: 'card', meaning: 'کارت', phrase: 'pay by card' },
        { word: 'delicious', meaning: 'خوشمزه', phrase: 'delicious food' },
        { word: 'recommend', meaning: 'پیشنهاد کردن', phrase: 'recommend a dish' },
        { word: 'window', meaning: 'پنجره', phrase: 'by the window' },
        { word: 'please', meaning: 'لطفاً', phrase: 'water, please' }
      ],
    },
    i1: {
      grammar: {
        title: 'Polite workplace requests with “Could”',
        titleFa: 'درخواست مؤدبانه در محیط کار با Could',
        formula: 'Could + subject + base verb…?',
        explanation: 'Use “could” to make professional requests sound polite.',
        explanationFa: 'برای مؤدبانه و حرفه‌ای‌کردن درخواست‌ها از Could استفاده می‌کنیم.',
        examples: ['Could we schedule a meeting?', 'Could you explain that again?', 'I will send you the report.'],
      },
      vocabulary: [
        { word: 'schedule', meaning: 'برنامه‌ریزی کردن', phrase: 'schedule a meeting' },
        { word: 'meeting', meaning: 'جلسه', phrase: 'attend a meeting' },
        { word: 'report', meaning: 'گزارش', phrase: 'send a report' },
        { word: 'explain', meaning: 'توضیح دادن', phrase: 'explain clearly' },
      ],
    },
    i2: {
      grammar: {
        title: 'Making suggestions and plans',
        titleFa: 'پیشنهاد دادن و برنامه‌ریزی',
        formula: 'Why don’t we + verb…? / Are you free…?',
        explanation: 'Use these forms to suggest an activity and arrange a time.',
        explanationFa: 'با این ساختارها فعالیتی پیشنهاد می‌دهیم و زمان آن را هماهنگ می‌کنیم.',
        examples: ['Are you free this weekend?', 'Why don’t we meet around six?', 'Let me check my schedule.'],
      },
      vocabulary: [
        { word: 'free', meaning: 'آزاد / وقت‌داشتن', phrase: 'be free tonight' },
        { word: 'weekend', meaning: 'آخر هفته', phrase: 'this weekend' },
        { word: 'meet', meaning: 'ملاقات کردن', phrase: 'meet around six' },
        { word: 'schedule', meaning: 'برنامه', phrase: 'check my schedule' },
      ],
    },
    i3: {
      grammar: {
        title: 'Present perfect for continuing situations',
        titleFa: 'حال کامل برای وضعیت‌های ادامه‌دار',
        formula: 'have/has + past participle + for/since',
        explanation: 'Use the present perfect for a situation that began before now and is still relevant.',
        explanationFa: 'برای وضعیتی که در گذشته شروع شده و هنوز ادامه یا اهمیت دارد از حال کامل استفاده می‌کنیم.',
        examples: ['I have been feeling tired lately.', 'How long have you had this problem?', 'Do I need to take medicine?'],
      },
      vocabulary: [
        { word: 'tired', meaning: 'خسته', phrase: 'feel tired' },
        { word: 'lately', meaning: 'اخیراً', phrase: 'recently and lately' },
        { word: 'problem', meaning: 'مشکل', phrase: 'have a problem' },
        { word: 'medicine', meaning: 'دارو', phrase: 'take medicine' },
      ],
    },
    a1: {
      grammar: {
        title: 'Hedging and respectful disagreement',
        titleFa: 'بیان محتاطانه و مخالفت محترمانه',
        formula: 'From my perspective… / I understand…, but…',
        explanation: 'Use these structures to express a strong idea without sounding aggressive.',
        explanationFa: 'با این ساختارها نظر قوی را بدون لحن تند بیان می‌کنیم.',
        examples: ['From my perspective, the benefits outweigh the risks.', 'I understand your point, but I see it differently.', 'There are several factors to consider.'],
      },
      vocabulary: [
        { word: 'perspective', meaning: 'دیدگاه', phrase: 'from my perspective' },
        { word: 'outweigh', meaning: 'بیشتر و مهم‌تر بودن', phrase: 'outweigh the risks' },
        { word: 'factor', meaning: 'عامل', phrase: 'a key factor' },
        { word: 'consider', meaning: 'در نظر گرفتن', phrase: 'carefully consider' },
      ],
    },
    a2: {
      grammar: {
        title: 'Formal and professional language',
        titleFa: 'زبان رسمی و حرفه‌ای',
        formula: 'We need to… / I would appreciate… / Let us…',
        explanation: 'These patterns make requests and recommendations precise and professional.',
        explanationFa: 'این الگوها درخواست‌ها و پیشنهادها را دقیق و حرفه‌ای می‌کنند.',
        examples: ['We need to evaluate the impact.', 'I would appreciate your feedback.', 'Let us focus on a practical solution.'],
      },
      vocabulary: [
        { word: 'evaluate', meaning: 'ارزیابی کردن', phrase: 'evaluate the impact' },
        { word: 'impact', meaning: 'تأثیر', phrase: 'long-term impact' },
        { word: 'feedback', meaning: 'بازخورد', phrase: 'provide feedback' },
        { word: 'proposal', meaning: 'پیشنهاد رسمی', phrase: 'review a proposal' },
      ],
    },
    a3: {
      grammar: {
        title: 'Nuance and contrast in arguments',
        titleFa: 'بیان ظرافت و تضاد در استدلال',
        formula: 'although / while / more…than…',
        explanation: 'Use contrast markers to build balanced, sophisticated arguments.',
        explanationFa: 'با نشانه‌های تضاد، استدلالی متعادل و پیشرفته می‌سازیم.',
        examples: ['The issue is more nuanced than it appears.', 'The argument is compelling, although it has limitations.', 'We should distinguish between correlation and causation.'],
      },
      vocabulary: [
        { word: 'nuanced', meaning: 'دارای ظرافت و پیچیدگی', phrase: 'a nuanced issue' },
        { word: 'compelling', meaning: 'قانع‌کننده', phrase: 'a compelling argument' },
        { word: 'limitation', meaning: 'محدودیت', phrase: 'have limitations' },
        { word: 'causation', meaning: 'رابطهٔ علّی', phrase: 'correlation and causation' },
      ],
    },
  };

  const extraLearningContent = {
  "intro1": {
    "grammar": {
      "title": "Introducing yourself with “I am”",
      "titleFa": "معرفی خود با I am",
      "formula": "I am + name / place / role",
      "explanation": "Use I am to give simple information about yourself.",
      "explanationFa": "با I am اطلاعات ساده‌ای دربارهٔ خود می‌گوییم.",
      "examples": [
        "Hello! My name is Sara.",
        "What is your name?",
        "Nice to meet you."
      ]
    },
    "vocabulary": [
      {
        "word": "hello",
        "meaning": "سلام",
        "phrase": "say hello"
      },
      {
        "word": "name",
        "meaning": "نام",
        "phrase": "my name"
      },
      {
        "word": "meet",
        "meaning": "ملاقات کردن",
        "phrase": "nice to meet you"
      },
      {
        "word": "from",
        "meaning": "اهلِ",
        "phrase": "from Iran"
      },
      {
        "word": "live",
        "meaning": "زندگی کردن",
        "phrase": "live in Tehran"
      },
      {
        "word": "student",
        "meaning": "دانشجو",
        "phrase": "a student"
      },
      {
        "word": "fine",
        "meaning": "خوب",
        "phrase": "feel fine"
      },
      {
        "word": "later",
        "meaning": "بعداً",
        "phrase": "see you later"
      }
    ]
  },
  "birthday1": {
    "grammar": {
      "title": "Dates with “on” and birthplaces with “in”",
      "titleFa": "تاریخ با on و محل تولد با in",
      "formula": "on + date / in + city",
      "explanation": "Use on for a specific date and in for a city.",
      "explanationFa": "برای تاریخ مشخص on و برای شهر in به کار می‌رود.",
      "examples": [
        "When is your birthday?",
        "My birthday is on May tenth.",
        "Where were you born?"
      ]
    },
    "vocabulary": [
      {
        "word": "birthday",
        "meaning": "تولد",
        "phrase": "my birthday"
      },
      {
        "word": "born",
        "meaning": "متولد شده",
        "phrase": "born in Tehran"
      },
      {
        "word": "old",
        "meaning": "سالِ سن",
        "phrase": "twenty years old"
      },
      {
        "word": "today",
        "meaning": "امروز",
        "phrase": "today is Monday"
      },
      {
        "word": "month",
        "meaning": "ماه",
        "phrase": "this month"
      },
      {
        "word": "year",
        "meaning": "سال",
        "phrase": "this year"
      },
      {
        "word": "party",
        "meaning": "جشن",
        "phrase": "birthday party"
      }
    ]
  },
  "colors1": {
    "grammar": {
      "title": "Color before the noun",
      "titleFa": "جای رنگ پیش از اسم",
      "formula": "color + noun",
      "explanation": "Put the color before the thing you describe.",
      "explanationFa": "در انگلیسی نام رنگ معمولاً پیش از اسم می‌آید.",
      "examples": [
        "What color is this?",
        "It is blue.",
        "I like the red shirt."
      ]
    },
    "vocabulary": [
      {
        "word": "red",
        "meaning": "قرمز",
        "phrase": "red shirt"
      },
      {
        "word": "blue",
        "meaning": "آبی",
        "phrase": "blue jacket"
      },
      {
        "word": "green",
        "meaning": "سبز",
        "phrase": "green bag"
      },
      {
        "word": "black",
        "meaning": "مشکی",
        "phrase": "black shoes"
      },
      {
        "word": "white",
        "meaning": "سفید",
        "phrase": "white shoes"
      },
      {
        "word": "yellow",
        "meaning": "زرد",
        "phrase": "yellow dress"
      },
      {
        "word": "shirt",
        "meaning": "پیراهن",
        "phrase": "a red shirt"
      },
      {
        "word": "shoes",
        "meaning": "کفش",
        "phrase": "white shoes"
      },
      {
        "word": "size",
        "meaning": "اندازه",
        "phrase": "small size"
      }
    ]
  },
  "directions1": {
    "grammar": {
      "title": "Where is…? and simple directions",
      "titleFa": "پرسیدن مکان و گفتن مسیر",
      "formula": "Where is + place? / Go + direction",
      "explanation": "Ask for a place, then use short instructions for the route.",
      "explanationFa": "برای پرسیدن مکان Where is و برای گفتن مسیر جمله‌های امری کوتاه به کار می‌بریم.",
      "examples": [
        "Excuse me, where is the pharmacy?",
        "What is the address?",
        "Is it near here?"
      ]
    },
    "vocabulary": [
      {
        "word": "address",
        "meaning": "نشانی",
        "phrase": "home address"
      },
      {
        "word": "street",
        "meaning": "خیابان",
        "phrase": "this street"
      },
      {
        "word": "near",
        "meaning": "نزدیک",
        "phrase": "near here"
      },
      {
        "word": "left",
        "meaning": "چپ",
        "phrase": "turn left"
      },
      {
        "word": "right",
        "meaning": "راست",
        "phrase": "turn right"
      },
      {
        "word": "straight",
        "meaning": "مستقیم",
        "phrase": "go straight"
      },
      {
        "word": "bank",
        "meaning": "بانک",
        "phrase": "at the bank"
      },
      {
        "word": "pharmacy",
        "meaning": "داروخانه",
        "phrase": "the pharmacy"
      },
      {
        "word": "hospital",
        "meaning": "بیمارستان",
        "phrase": "next to the hospital"
      }
    ]
  },
  "animals1": {
    "grammar": {
      "title": "Having things with “have”",
      "titleFa": "داشتن با have",
      "formula": "I have + a/an + animal",
      "explanation": "Use have to say what you own.",
      "explanationFa": "برای گفتن اینکه چه چیزی داریم از have استفاده می‌کنیم.",
      "examples": [
        "Do you have a pet?",
        "Yes, I have a cat.",
        "What is its name?"
      ]
    },
    "vocabulary": [
      {
        "word": "pet",
        "meaning": "حیوان خانگی",
        "phrase": "have a pet"
      },
      {
        "word": "cat",
        "meaning": "گربه",
        "phrase": "a cat"
      },
      {
        "word": "dog",
        "meaning": "سگ",
        "phrase": "my dog"
      },
      {
        "word": "bird",
        "meaning": "پرنده",
        "phrase": "a bird"
      },
      {
        "word": "fish",
        "meaning": "ماهی",
        "phrase": "a fish"
      },
      {
        "word": "friendly",
        "meaning": "مهربان",
        "phrase": "a friendly dog"
      },
      {
        "word": "small",
        "meaning": "کوچک",
        "phrase": "a small fish"
      }
    ]
  },
  "school1": {
    "grammar": {
      "title": "Present simple for routines",
      "titleFa": "حال ساده برای کارهای تکراری",
      "formula": "I + verb + time expression",
      "explanation": "Use the present simple for regular study, work, and sports.",
      "explanationFa": "برای کارهای تکراری تحصیل، شغل و ورزش از حال ساده استفاده می‌کنیم.",
      "examples": [
        "I study English every day.",
        "What do you study?",
        "I work in an office."
      ]
    },
    "vocabulary": [
      {
        "word": "study",
        "meaning": "درس خواندن",
        "phrase": "study English"
      },
      {
        "word": "work",
        "meaning": "کار کردن",
        "phrase": "work in an office"
      },
      {
        "word": "job",
        "meaning": "شغل",
        "phrase": "my job"
      },
      {
        "word": "teacher",
        "meaning": "معلم",
        "phrase": "a teacher"
      },
      {
        "word": "student",
        "meaning": "دانش‌آموز / دانشجو",
        "phrase": "a student"
      },
      {
        "word": "football",
        "meaning": "فوتبال",
        "phrase": "play football"
      },
      {
        "word": "gym",
        "meaning": "باشگاه",
        "phrase": "go to the gym"
      },
      {
        "word": "swimming",
        "meaning": "شنا",
        "phrase": "like swimming"
      }
    ]
  },
  "mechanic1": {
    "grammar": {
      "title": "Can you…? for help",
      "titleFa": "درخواست کمک با Can you",
      "formula": "Can you + base verb + object?",
      "explanation": "Ask someone to do something for you.",
      "explanationFa": "برای درخواست انجام یک کار از Can you استفاده می‌کنیم.",
      "examples": [
        "My car will not start.",
        "I have a problem with my car.",
        "The tire is flat."
      ]
    },
    "vocabulary": [
      {
        "word": "car",
        "meaning": "ماشین",
        "phrase": "my car"
      },
      {
        "word": "start",
        "meaning": "روشن شدن",
        "phrase": "the car will not start"
      },
      {
        "word": "tire",
        "meaning": "لاستیک",
        "phrase": "a flat tire"
      },
      {
        "word": "flat",
        "meaning": "پنچر",
        "phrase": "the tire is flat"
      },
      {
        "word": "check",
        "meaning": "بررسی کردن",
        "phrase": "check the car"
      },
      {
        "word": "cost",
        "meaning": "هزینه داشتن",
        "phrase": "how much will it cost"
      },
      {
        "word": "ready",
        "meaning": "آماده",
        "phrase": "be ready"
      }
    ]
  },
  "a2routine": {
    "grammar": {
      "title": "Present continuous for arrangements",
      "titleFa": "حال استمراری برای قرارهای مشخص",
      "formula": "I am + verb-ing + time",
      "explanation": "Use the present continuous for a fixed future arrangement.",
      "explanationFa": "برای قرار مشخص آینده از حال استمراری استفاده می‌کنیم.",
      "examples": [
        "Are you free on Saturday?",
        "I am meeting my friend at six.",
        "Would you like to join us?"
      ]
    },
    "vocabulary": [
      {
        "word": "free",
        "meaning": "وقت داشتن",
        "phrase": "be free"
      },
      {
        "word": "join",
        "meaning": "ملحق شدن",
        "phrase": "join us"
      },
      {
        "word": "class",
        "meaning": "کلاس",
        "phrase": "have class"
      },
      {
        "word": "instead",
        "meaning": "به‌جای آن",
        "phrase": "tomorrow instead"
      },
      {
        "word": "tomorrow",
        "meaning": "فردا",
        "phrase": "meet tomorrow"
      },
      {
        "word": "plan",
        "meaning": "برنامه",
        "phrase": "make a plan"
      }
    ]
  },
  "b1problem": {
    "grammar": {
      "title": "Polite requests with “Could”",
      "titleFa": "درخواست مؤدبانه با Could",
      "formula": "Could you + verb + object?",
      "explanation": "Use Could you to request help politely.",
      "explanationFa": "برای درخواست کمک مؤدبانه از Could you استفاده می‌کنیم.",
      "examples": [
        "My flight has been delayed.",
        "I booked a room for two nights.",
        "The booking confirmation is on my phone."
      ]
    },
    "vocabulary": [
      {
        "word": "delay",
        "meaning": "تأخیر",
        "phrase": "a flight delay"
      },
      {
        "word": "book",
        "meaning": "رزرو کردن",
        "phrase": "book a room"
      },
      {
        "word": "confirmation",
        "meaning": "تأییدیه",
        "phrase": "booking confirmation"
      },
      {
        "word": "reservation",
        "meaning": "رزرو",
        "phrase": "check a reservation"
      },
      {
        "word": "available",
        "meaning": "موجود",
        "phrase": "a room available"
      },
      {
        "word": "option",
        "meaning": "گزینه",
        "phrase": "another option"
      }
    ]
  },
  "b2mechanic": {
    "grammar": {
      "title": "Passive forms for repairs",
      "titleFa": "ساخت مجهول در تعمیرات",
      "formula": "needs to be + past participle",
      "explanation": "Use this form to focus on the part that needs work.",
      "explanationFa": "با این ساختار روی قطعه‌ای که نیاز به تعمیر دارد تمرکز می‌کنیم.",
      "examples": [
        "The engine makes a strange noise when I accelerate.",
        "Could you explain what needs to be replaced?",
        "Is there a cheaper alternative?"
      ]
    },
    "vocabulary": [
      {
        "word": "engine",
        "meaning": "موتور",
        "phrase": "the engine"
      },
      {
        "word": "accelerate",
        "meaning": "گاز دادن",
        "phrase": "when I accelerate"
      },
      {
        "word": "replace",
        "meaning": "تعویض کردن",
        "phrase": "replace the part"
      },
      {
        "word": "alternative",
        "meaning": "گزینهٔ جایگزین",
        "phrase": "a cheaper alternative"
      },
      {
        "word": "estimate",
        "meaning": "برآورد هزینه",
        "phrase": "a repair estimate"
      },
      {
        "word": "warranty",
        "meaning": "ضمانت",
        "phrase": "under warranty"
      }
    ]
  },
  "c1presentation": {
    "grammar": {
      "title": "Careful claims with “suggests”",
      "titleFa": "بیان محتاطانهٔ نتیجه با suggests",
      "formula": "Evidence suggests + claim",
      "explanation": "Present an interpretation without overstating certainty.",
      "explanationFa": "با suggests نتیجه را بدون قطعیت بیش از حد بیان می‌کنیم.",
      "examples": [
        "Our proposal addresses the most urgent customer needs.",
        "The available evidence suggests a steady rise in demand.",
        "We should also acknowledge the limitations of this estimate."
      ]
    },
    "vocabulary": [
      {
        "word": "proposal",
        "meaning": "پیشنهاد رسمی",
        "phrase": "present a proposal"
      },
      {
        "word": "evidence",
        "meaning": "شواهد",
        "phrase": "available evidence"
      },
      {
        "word": "demand",
        "meaning": "تقاضا",
        "phrase": "rise in demand"
      },
      {
        "word": "limitation",
        "meaning": "محدودیت",
        "phrase": "acknowledge limitations"
      },
      {
        "word": "assumption",
        "meaning": "فرض",
        "phrase": "underlying assumption"
      },
      {
        "word": "phased",
        "meaning": "مرحله‌ای",
        "phrase": "a phased approach"
      }
    ]
  },
  "c2debate": {
    "grammar": {
      "title": "Qualified disagreement",
      "titleFa": "مخالفت دقیق و سنجیده",
      "formula": "I agree in principle, though + qualification",
      "explanation": "Acknowledge a valid point before adding a precise limitation.",
      "explanationFa": "نکتهٔ درست طرف مقابل را می‌پذیریم و سپس محدودیت دقیق آن را بیان می‌کنیم.",
      "examples": [
        "That conclusion rests on an assumption we have not tested.",
        "The evidence is persuasive, but it does not settle the question.",
        "We may be conflating a short-term trend with a structural change."
      ]
    },
    "vocabulary": [
      {
        "word": "assumption",
        "meaning": "فرض",
        "phrase": "untested assumption"
      },
      {
        "word": "persuasive",
        "meaning": "قانع‌کننده",
        "phrase": "persuasive evidence"
      },
      {
        "word": "conflate",
        "meaning": "یکی گرفتن دو چیز متفاوت",
        "phrase": "conflate two trends"
      },
      {
        "word": "structural",
        "meaning": "ساختاری",
        "phrase": "structural change"
      },
      {
        "word": "implication",
        "meaning": "پیامد ضمنی یا عملی",
        "phrase": "practical implications"
      },
      {
        "word": "infer",
        "meaning": "استنباط کردن",
        "phrase": "infer from evidence"
      }
    ]
  }
};
  const lessonExtras = {
  "intro1": {
    "notes": [
      "I'm کوتاه‌شدهٔ I am است و در مکالمه بسیار رایج است.",
      "برای پرسیدن نام، What is your name? مؤدبانه و ساده است."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "Hello! What is your name?",
        "fa": "سلام! اسم شما چیست؟"
      },
      {
        "speaker": "B",
        "en": "My name is Sara. Nice to meet you.",
        "fa": "اسم من سارا است. از آشنایی با شما خوشوقتم."
      },
      {
        "speaker": "A",
        "en": "Nice to meet you too.",
        "fa": "من هم خوشوقتم."
      }
    ]
  },
  "birthday1": {
    "notes": [
      "برای گفتن روز تولد از on استفاده می‌کنیم: on May tenth.",
      "برای گفتن شهر تولد می‌گوییم I was born in + city."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "When is your birthday?",
        "fa": "تولدت چه زمانی است؟"
      },
      {
        "speaker": "B",
        "en": "My birthday is on May tenth.",
        "fa": "تولد من دهم مه است."
      },
      {
        "speaker": "A",
        "en": "Where were you born?",
        "fa": "کجا متولد شدی؟"
      },
      {
        "speaker": "B",
        "en": "I was born in Tehran.",
        "fa": "در تهران متولد شدم."
      }
    ]
  },
  "colors1": {
    "notes": [
      "می‌گوییم a red shirt؛ جای رنگ و اسم را جابه‌جا نمی‌کنیم.",
      "برای پرسیدن رنگ از What color…? استفاده می‌کنیم."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "Do you have this shirt in blue?",
        "fa": "این پیراهن را به رنگ آبی دارید؟"
      },
      {
        "speaker": "B",
        "en": "Yes. What size do you need?",
        "fa": "بله. چه سایزی می‌خواهید؟"
      },
      {
        "speaker": "A",
        "en": "Small, please.",
        "fa": "کوچک، لطفاً."
      }
    ]
  },
  "directions1": {
    "notes": [
      "Excuse me شروع مؤدبانه‌ای برای پرسیدن مسیر از یک غریبه است.",
      "Next to یعنی درست کنارِ؛ near یعنی در نزدیکی."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "Excuse me, where is the pharmacy?",
        "fa": "ببخشید، داروخانه کجاست؟"
      },
      {
        "speaker": "B",
        "en": "Go straight. It is next to the bank.",
        "fa": "مستقیم بروید. کنار بانک است."
      },
      {
        "speaker": "A",
        "en": "Thank you!",
        "fa": "ممنون!"
      }
    ]
  },
  "animals1": {
    "notes": [
      "برای یک حیوان می‌گوییم a cat؛ برای جمع می‌گوییم cats.",
      "Its name یعنی «اسم آن»؛ it’s name در این معنی درست نیست."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "Do you have a pet?",
        "fa": "حیوان خانگی داری؟"
      },
      {
        "speaker": "B",
        "en": "Yes, I have a cat. Its name is Luna.",
        "fa": "بله، یک گربه دارم. اسمش لوناست."
      }
    ]
  },
  "school1": {
    "notes": [
      "برای ورزش‌های توپی معمولاً play به کار می‌رود: play football.",
      "برای رفتن به باشگاه می‌گوییم go to the gym."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "What do you do?",
        "fa": "چه کار می‌کنی؟"
      },
      {
        "speaker": "B",
        "en": "I'm a teacher. I play football on Fridays.",
        "fa": "معلم هستم. جمعه‌ها فوتبال بازی می‌کنم."
      }
    ]
  },
  "mechanic1": {
    "notes": [
      "My car won’t start شکل گفتاری My car will not start است.",
      "How much will it cost? دربارهٔ هزینهٔ آیندهٔ تعمیر می‌پرسد."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "My car will not start. Can you check it?",
        "fa": "ماشینم روشن نمی‌شود. می‌توانید بررسی‌اش کنید؟"
      },
      {
        "speaker": "B",
        "en": "Yes. I will take a look.",
        "fa": "بله. نگاهی می‌اندازم."
      }
    ]
  },
  "a2routine": {
    "notes": [
      "Are you free…? راهی طبیعی برای پرسیدن وقت آزاد است.",
      "Instead یعنی «به‌جایش» و برای پیشنهاد زمان جایگزین مفید است."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "Are you free on Saturday?",
        "fa": "شنبه وقت داری؟"
      },
      {
        "speaker": "B",
        "en": "I have class. Can we meet tomorrow instead?",
        "fa": "کلاس دارم. می‌توانیم به‌جایش فردا ببینیم؟"
      }
    ]
  },
  "b1problem": {
    "notes": [
      "Could you…? از Can you…? رسمی‌تر و مؤدبانه‌تر است.",
      "What are my options? وقتی راه‌حل‌های مختلف می‌خواهیم مفید است."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "Could you check my reservation?",
        "fa": "می‌توانید رزروم را بررسی کنید؟"
      },
      {
        "speaker": "B",
        "en": "Of course. May I have your name?",
        "fa": "البته. نامتان را می‌فرمایید؟"
      }
    ]
  },
  "b2mechanic": {
    "notes": [
      "An estimate یعنی برآورد هزینه؛ قیمت نهایی ممکن است فرق کند.",
      "Covered by the warranty یعنی تحت پوشش ضمانت بودن."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "What needs to be replaced?",
        "fa": "چه چیزی باید تعویض شود؟"
      },
      {
        "speaker": "B",
        "en": "The battery needs to be replaced.",
        "fa": "باتری باید تعویض شود."
      }
    ]
  },
  "c1presentation": {
    "notes": [
      "Suggests نشان می‌دهد این نتیجه تفسیر شواهد است، نه یک حقیقت قطعی.",
      "Acknowledge the limitations یعنی محدودیت‌های استدلال خود را شفاف بیان کنیم."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "What evidence supports the forecast?",
        "fa": "چه شواهدی پیش‌بینی را پشتیبانی می‌کند؟"
      },
      {
        "speaker": "B",
        "en": "Recent orders suggest demand is rising, although the sample is limited.",
        "fa": "سفارش‌های اخیر رشد تقاضا را نشان می‌دهند، هرچند نمونه محدود است."
      }
    ]
  },
  "c2debate": {
    "notes": [
      "Conflate یعنی دو مفهوم متفاوت را به‌اشتباه یکی حساب کردن.",
      "In principle موافقت با اصل ایده را نشان می‌دهد، نه همهٔ جزئیات آن."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "Surely the trend proves the policy worked.",
        "fa": "این روند حتماً ثابت می‌کند سیاست موفق بوده."
      },
      {
        "speaker": "B",
        "en": "It is encouraging, though we may be conflating correlation with causation.",
        "fa": "امیدبخش است، هرچند شاید همبستگی را با علیت یکی می‌گیریم."
      }
    ]
  },
  "b5": {
    "notes": [
      "I'd like شکل کوتاه I would like است و در مکالمه زیاد استفاده می‌شود.",
      "Please درخواست را مؤدبانه‌تر می‌کند؛ Water, please هم طبیعی است."
    ],
    "dialogue": [
      {
        "speaker": "Waiter",
        "en": "Hello! A table for two?",
        "fa": "سلام! میز برای دو نفر؟"
      },
      {
        "speaker": "Customer",
        "en": "Yes, please. Can I see the menu?",
        "fa": "بله، لطفاً. می‌توانم منو را ببینم؟"
      },
      {
        "speaker": "Waiter",
        "en": "Of course. What would you like?",
        "fa": "البته. چه میل دارید؟"
      },
      {
        "speaker": "Customer",
        "en": "I'd like chicken and rice, please.",
        "fa": "مرغ و برنج می‌خواهم، لطفاً."
      },
      {
        "speaker": "Waiter",
        "en": "Anything to drink?",
        "fa": "نوشیدنی هم می‌خواهید؟"
      },
      {
        "speaker": "Customer",
        "en": "Water, please.",
        "fa": "آب، لطفاً."
      }
    ]
  },
  "b1": {
    "notes": [
      "Can I have…? راهی مؤدبانه برای سفارش است.",
      "Anything else? یعنی «چیز دیگری؟» و در کافه بسیار رایج است."
    ],
    "dialogue": [
      {
        "speaker": "Customer",
        "en": "Can I have a coffee, please?",
        "fa": "یک قهوه می‌خواهم، لطفاً."
      },
      {
        "speaker": "Barista",
        "en": "Of course. Anything else?",
        "fa": "البته. چیز دیگری می‌خواهید؟"
      },
      {
        "speaker": "Customer",
        "en": "No, thank you. Can I pay by card?",
        "fa": "نه، ممنون. می‌توانم با کارت پرداخت کنم؟"
      }
    ]
  },
  "b3": {
    "notes": [
      "برای عادت‌های روزانه از حال ساده استفاده می‌کنیم.",
      "Every morning یعنی «هر صبح» و زمان تکرار را نشان می‌دهد."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "What time do you wake up?",
        "fa": "چه ساعتی بیدار می‌شوی؟"
      },
      {
        "speaker": "B",
        "en": "I wake up at seven and make breakfast.",
        "fa": "ساعت هفت بیدار می‌شوم و صبحانه درست می‌کنم."
      }
    ]
  },
  "b4": {
    "notes": [
      "How much is this? برای پرسیدن قیمت یک کالا است.",
      "Do you have this in blue? رنگ موجود را می‌پرسد."
    ],
    "dialogue": [
      {
        "speaker": "Customer",
        "en": "How much is this shirt?",
        "fa": "این پیراهن چقدر است؟"
      },
      {
        "speaker": "Staff",
        "en": "It is twenty dollars.",
        "fa": "بیست دلار است."
      },
      {
        "speaker": "Customer",
        "en": "Do you have it in blue?",
        "fa": "آن را به رنگ آبی دارید؟"
      }
    ]
  },
  "b2": {
    "notes": [
      "Where is…? برای پرسیدن مکان به کار می‌رود.",
      "What time…? برای پرسیدن ساعت یک رویداد است."
    ],
    "dialogue": [
      {
        "speaker": "Traveler",
        "en": "Where is the check-in desk?",
        "fa": "کانتر پذیرش پرواز کجاست؟"
      },
      {
        "speaker": "Staff",
        "en": "It is over there, near gate twelve.",
        "fa": "آنجاست، نزدیک گیت دوازده."
      },
      {
        "speaker": "Traveler",
        "en": "Thank you. What time is boarding?",
        "fa": "ممنون. سوار شدن چه ساعتی است؟"
      }
    ]
  },
  "i1": {
    "notes": [
      "Could you…? در محیط کار درخواست را مؤدبانه‌تر می‌کند.",
      "I will… برای قول یا تصمیم دربارهٔ آینده است."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "Could we schedule a meeting for tomorrow?",
        "fa": "می‌توانیم برای فردا جلسه بگذاریم؟"
      },
      {
        "speaker": "B",
        "en": "Yes. I will send you the report this afternoon.",
        "fa": "بله. امروز بعدازظهر گزارش را می‌فرستم."
      }
    ]
  },
  "i2": {
    "notes": [
      "Why don’t we…? برای پیشنهاد دادن به کار می‌رود.",
      "Around six یعنی «حدود ساعت شش»."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "Are you free this weekend?",
        "fa": "این آخر هفته وقت داری؟"
      },
      {
        "speaker": "B",
        "en": "Yes. Why don’t we meet around six?",
        "fa": "بله. چرا حدود ساعت شش همدیگر را نبینیم؟"
      }
    ]
  },
  "i3": {
    "notes": [
      "How long…? دربارهٔ مدت زمان یک مشکل می‌پرسد.",
      "Lately یعنی «اخیراً» و معمولاً با زمان‌های مناسب آن می‌آید."
    ],
    "dialogue": [
      {
        "speaker": "Patient",
        "en": "I have been feeling tired lately.",
        "fa": "اخیراً احساس خستگی می‌کنم."
      },
      {
        "speaker": "Doctor",
        "en": "How long have you had this problem?",
        "fa": "چه مدت است این مشکل را دارید؟"
      }
    ]
  },
  "a1": {
    "notes": [
      "From my perspective نظر شخصی را روشن می‌کند.",
      "I understand your point, but… مخالفت را محترمانه‌تر می‌کند."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "From my perspective, the benefits outweigh the risks.",
        "fa": "از دیدگاه من، مزایا از خطرات بیشتر است."
      },
      {
        "speaker": "B",
        "en": "I understand your point, but we should consider the costs.",
        "fa": "دیدگاهت را درک می‌کنم، اما باید هزینه‌ها را هم در نظر بگیریم."
      }
    ]
  },
  "a2": {
    "notes": [
      "I would appreciate… در درخواست‌های حرفه‌ای مؤدبانه است.",
      "Let us… پیشنهادی برای اقدام مشترک است."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "I would appreciate your feedback on the proposal.",
        "fa": "از بازخورد شما دربارهٔ پیشنهاد استقبال می‌کنم."
      },
      {
        "speaker": "B",
        "en": "Certainly. Let us focus on the most practical solution.",
        "fa": "حتماً. بیایید روی عملی‌ترین راه‌حل تمرکز کنیم."
      }
    ]
  },
  "a3": {
    "notes": [
      "Although تضاد دو نکته را در یک جمله نشان می‌دهد.",
      "Correlation و causation مفاهیم متفاوتی هستند."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "That argument is compelling, although it has limitations.",
        "fa": "استدلال قانع‌کننده است، هرچند محدودیت‌هایی دارد."
      },
      {
        "speaker": "B",
        "en": "Agreed. We should distinguish correlation from causation.",
        "fa": "موافقم. باید همبستگی را از علیت جدا کنیم."
      }
    ]
  }
};
  const pilotLearningContent = {
  "intro1": {
    "grammar": {
      "title": "Introducing yourself with “I am”",
      "titleFa": "معرفی خود با I am",
      "formula": "I am + name / from + place / a + role",
      "explanation": "Use I am to say who you are, where you are from, or what you do.",
      "explanationFa": "با I am نام، زادگاه یا شغل خود را بیان می‌کنیم.",
      "examples": [
        "I'm Sara.",
        "I'm from Iran.",
        "I'm a student."
      ]
    },
    "vocabulary": [
      {
        "word": "hello",
        "meaning": "سلام",
        "phrase": "Hello, Sara!"
      },
      {
        "word": "good morning",
        "meaning": "صبح بخیر",
        "phrase": "Good morning, Ali!"
      },
      {
        "word": "good evening",
        "meaning": "عصر بخیر",
        "phrase": "Good evening, Mina!"
      },
      {
        "word": "name",
        "meaning": "نام",
        "phrase": "My name is Sara."
      },
      {
        "word": "first name",
        "meaning": "نام کوچک",
        "phrase": "My first name is Ali."
      },
      {
        "word": "friend",
        "meaning": "دوست",
        "phrase": "my friend Mina"
      },
      {
        "word": "meet",
        "meaning": "آشنا شدن / ملاقات کردن",
        "phrase": "Nice to meet you."
      },
      {
        "word": "too",
        "meaning": "هم / نیز",
        "phrase": "Nice to meet you too."
      },
      {
        "word": "from",
        "meaning": "اهلِ / از",
        "phrase": "from Iran"
      },
      {
        "word": "live",
        "meaning": "زندگی کردن",
        "phrase": "live in Tehran"
      },
      {
        "word": "student",
        "meaning": "دانشجو",
        "phrase": "I am a student."
      },
      {
        "word": "spell",
        "meaning": "هجی کردن",
        "phrase": "spell your name"
      },
      {
        "word": "fine",
        "meaning": "خوب",
        "phrase": "I am fine."
      },
      {
        "word": "thank you",
        "meaning": "ممنون",
        "phrase": "Fine, thank you."
      },
      {
        "word": "goodbye",
        "meaning": "خداحافظ",
        "phrase": "Goodbye, Sara!"
      },
      {
        "word": "later",
        "meaning": "بعداً",
        "phrase": "See you later!"
      },
      {
        "word": "day",
        "meaning": "روز",
        "phrase": "Have a nice day!"
      }
    ]
  },
  "b3": {
    "grammar": {
      "title": "Present simple for daily routines",
      "titleFa": "حال ساده برای کارهای روزمره",
      "formula": "I + base verb + time / frequency",
      "formulaFa": "من + فعل ساده + زمان یا تعداد دفعات انجام کار؛ مانند: من هر صبح صبحانه درست می‌کنم.",
      "explanation": "Use the present simple to talk about things you do regularly.",
      "explanationFa": "برای عادت‌ها و کارهایی که تکرار می‌شوند از حال ساده استفاده می‌کنیم. بعد از I شکل سادهٔ فعل می‌آید؛ مانند I wake up. برای گفتن ساعت از at و برای تکرار از every morning استفاده می‌کنیم.",
      "examples": [
        "I wake up at seven.",
        "I make breakfast every morning.",
        "I go to bed at eleven."
      ],
      "examplesFa": [
        "من ساعت هفت بیدار می‌شوم.",
        "من هر صبح صبحانه درست می‌کنم.",
        "من ساعت یازده می‌خوابم."
      ]
    },
    "vocabulary": [
      {
        "word": "wake up",
        "meaning": "بیدار شدن",
        "phrase": "wake up at seven"
      },
      {
        "word": "get up",
        "meaning": "از تخت بلند شدن",
        "phrase": "get up at seven thirty"
      },
      {
        "word": "breakfast",
        "meaning": "صبحانه",
        "phrase": "have breakfast"
      },
      {
        "word": "morning",
        "meaning": "صبح",
        "phrase": "every morning"
      },
      {
        "word": "brush",
        "meaning": "مسواک زدن / برس کشیدن",
        "phrase": "brush my teeth"
      },
      {
        "word": "teeth",
        "meaning": "دندان‌ها",
        "phrase": "brush my teeth"
      },
      {
        "word": "shower",
        "meaning": "دوش",
        "phrase": "take a shower"
      },
      {
        "word": "tea",
        "meaning": "چای",
        "phrase": "drink tea"
      },
      {
        "word": "leave",
        "meaning": "ترک کردن / بیرون رفتن",
        "phrase": "leave home"
      },
      {
        "word": "home",
        "meaning": "خانه",
        "phrase": "come home"
      },
      {
        "word": "work",
        "meaning": "محل کار / کار کردن",
        "phrase": "go to work"
      },
      {
        "word": "bus",
        "meaning": "اتوبوس",
        "phrase": "by bus"
      },
      {
        "word": "dinner",
        "meaning": "شام",
        "phrase": "cook dinner"
      },
      {
        "word": "cook",
        "meaning": "آشپزی کردن",
        "phrase": "cook dinner"
      },
      {
        "word": "watch TV",
        "meaning": "تلویزیون تماشا کردن",
        "phrase": "watch TV after dinner"
      },
      {
        "word": "read",
        "meaning": "مطالعه کردن",
        "phrase": "read before bed"
      },
      {
        "word": "bed",
        "meaning": "تخت / زمان خواب",
        "phrase": "go to bed"
      }
    ]
  },
  "b1": {
    "grammar": {
      "title": "Polite orders with “Can I have…?”",
      "titleFa": "سفارش مؤدبانه با Can I have…?",
      "formula": "Can I have + a / some + item + please?",
      "explanation": "Use Can I have to order a drink or ask for an item politely.",
      "explanationFa": "با Can I have می‌توانیم نوشیدنی سفارش بدهیم یا چیزی را مؤدبانه درخواست کنیم.",
      "examples": [
        "Can I have a coffee, please?",
        "Can I have some water, please?",
        "Can I have it with milk?"
      ]
    },
    "vocabulary": [
      {
        "word": "coffee",
        "meaning": "قهوه",
        "phrase": "a cup of coffee"
      },
      {
        "word": "cappuccino",
        "meaning": "کاپوچینو",
        "phrase": "a cappuccino"
      },
      {
        "word": "tea",
        "meaning": "چای",
        "phrase": "a cup of tea"
      },
      {
        "word": "menu",
        "meaning": "منو",
        "phrase": "see the menu"
      },
      {
        "word": "cup",
        "meaning": "فنجان / لیوان",
        "phrase": "a cup of tea"
      },
      {
        "word": "small",
        "meaning": "کوچک",
        "phrase": "a small coffee"
      },
      {
        "word": "iced coffee",
        "meaning": "قهوهٔ سرد",
        "phrase": "have iced coffee"
      },
      {
        "word": "hot",
        "meaning": "داغ",
        "phrase": "hot coffee"
      },
      {
        "word": "milk",
        "meaning": "شیر",
        "phrase": "coffee with milk"
      },
      {
        "word": "sugar",
        "meaning": "شکر",
        "phrase": "no sugar"
      },
      {
        "word": "water",
        "meaning": "آب",
        "phrase": "some water"
      },
      {
        "word": "please",
        "meaning": "لطفاً",
        "phrase": "Water, please."
      },
      {
        "word": "to go",
        "meaning": "بیرون‌بر",
        "phrase": "coffee to go"
      },
      {
        "word": "for here",
        "meaning": "برای همین‌جا",
        "phrase": "coffee for here"
      },
      {
        "word": "pay",
        "meaning": "پرداخت کردن",
        "phrase": "pay by card"
      },
      {
        "word": "card",
        "meaning": "کارت",
        "phrase": "pay by card"
      },
      {
        "word": "price",
        "meaning": "قیمت",
        "phrase": "the price of a coffee"
      }
    ]
  },
  "b4": {
    "grammar": {
      "title": "Asking about prices",
      "titleFa": "پرسیدن قیمت",
      "formula": "How much is + singular item? / How much are + plural items?",
      "explanation": "Use is with one item and are with more than one item.",
      "explanationFa": "برای یک کالا از is و برای چند کالا از are استفاده می‌کنیم.",
      "examples": [
        "How much is this?",
        "How much are these shoes?"
      ]
    },
    "vocabulary": [
      {
        "word": "shop",
        "meaning": "فروشگاه",
        "phrase": "a small shop"
      },
      {
        "word": "shirt",
        "meaning": "پیراهن",
        "phrase": "a blue shirt"
      },
      {
        "word": "shoes",
        "meaning": "کفش",
        "phrase": "these shoes"
      },
      {
        "word": "price",
        "meaning": "قیمت",
        "phrase": "the price"
      },
      {
        "word": "size",
        "meaning": "سایز",
        "phrase": "a small size"
      },
      {
        "word": "small",
        "meaning": "کوچک",
        "phrase": "too small"
      },
      {
        "word": "large",
        "meaning": "بزرگ",
        "phrase": "a large size"
      },
      {
        "word": "color",
        "meaning": "رنگ",
        "phrase": "this color"
      },
      {
        "word": "blue",
        "meaning": "آبی",
        "phrase": "in blue"
      },
      {
        "word": "fitting room",
        "meaning": "اتاق پرو",
        "phrase": "the fitting room"
      },
      {
        "word": "try on",
        "meaning": "پرو کردن",
        "phrase": "try this on"
      },
      {
        "word": "fit",
        "meaning": "اندازه بودن",
        "phrase": "fits well"
      },
      {
        "word": "card",
        "meaning": "کارت",
        "phrase": "pay by card"
      },
      {
        "word": "cash",
        "meaning": "پول نقد",
        "phrase": "pay in cash"
      },
      {
        "word": "bag",
        "meaning": "کیسه",
        "phrase": "a bag, please"
      },
      {
        "word": "receipt",
        "meaning": "رسید",
        "phrase": "a receipt, please"
      },
      {
        "word": "take",
        "meaning": "خریدن / برداشتن",
        "phrase": "I will take it"
      },
      {
        "word": "look for",
        "meaning": "دنبال چیزی گشتن",
        "phrase": "look for a shirt"
      }
    ]
  },
  "directions1": {
    "grammar": {
      "title": "Asking where a place is",
      "titleFa": "پرسیدن جای یک مکان",
      "formula": "Where is + place? / It is + location.",
      "explanation": "Use Where is to ask about a place; answer with It is and a location phrase.",
      "explanationFa": "برای پرسیدن جای یک مکان Where is و برای پاسخ It is را با عبارت مکان به کار ببرید.",
      "examples": [
        "Where is the pharmacy?",
        "It is next to the hospital.",
        "It is across from the bank."
      ]
    },
    "vocabulary": [
      {
        "word": "excuse me",
        "meaning": "ببخشید",
        "phrase": "Excuse me, where is it?"
      },
      {
        "word": "address",
        "meaning": "نشانی",
        "phrase": "the address"
      },
      {
        "word": "street",
        "meaning": "خیابان",
        "phrase": "this street"
      },
      {
        "word": "pharmacy",
        "meaning": "داروخانه",
        "phrase": "the pharmacy"
      },
      {
        "word": "hospital",
        "meaning": "بیمارستان",
        "phrase": "the hospital"
      },
      {
        "word": "bank",
        "meaning": "بانک",
        "phrase": "the bank"
      },
      {
        "word": "cafe",
        "meaning": "کافه",
        "phrase": "the cafe"
      },
      {
        "word": "station",
        "meaning": "ایستگاه",
        "phrase": "the station"
      },
      {
        "word": "bus stop",
        "meaning": "ایستگاه اتوبوس",
        "phrase": "the bus stop"
      },
      {
        "word": "near",
        "meaning": "نزدیک",
        "phrase": "near here"
      },
      {
        "word": "far",
        "meaning": "دور",
        "phrase": "far from here"
      },
      {
        "word": "straight",
        "meaning": "مستقیم",
        "phrase": "go straight"
      },
      {
        "word": "left",
        "meaning": "چپ",
        "phrase": "turn left"
      },
      {
        "word": "right",
        "meaning": "راست",
        "phrase": "turn right"
      },
      {
        "word": "next to",
        "meaning": "کنارِ",
        "phrase": "next to the hospital"
      },
      {
        "word": "across from",
        "meaning": "روبروی",
        "phrase": "across from the bank"
      },
      {
        "word": "between",
        "meaning": "بین",
        "phrase": "between two shops"
      },
      {
        "word": "map",
        "meaning": "نقشه",
        "phrase": "on the map"
      },
      {
        "word": "traffic light",
        "meaning": "چراغ راهنمایی",
        "phrase": "at the traffic light"
      }
    ]
  },
  "birthday1": {
    "grammar": {
      "title": "Dates and birthplaces",
      "titleFa": "تاریخ و محل تولد",
      "formula": "on + specific day or date / in + month or city",
      "explanation": "Use on before a specific day or date and in before a month or city.",
      "explanationFa": "قبل از روز یا تاریخ مشخص on و قبل از ماه یا شهر in می‌آید.",
      "examples": [
        "My birthday is on May tenth.",
        "My birthday is in June.",
        "I was born in Tehran."
      ]
    },
    "vocabulary": [
      {
        "word": "birthday",
        "meaning": "تولد",
        "phrase": "my birthday"
      },
      {
        "word": "birthplace",
        "meaning": "محل تولد",
        "phrase": "my birthplace"
      },
      {
        "word": "born",
        "meaning": "متولد شده",
        "phrase": "born in Tehran"
      },
      {
        "word": "date",
        "meaning": "تاریخ",
        "phrase": "the date"
      },
      {
        "word": "day",
        "meaning": "روز",
        "phrase": "what day"
      },
      {
        "word": "month",
        "meaning": "ماه",
        "phrase": "this month"
      },
      {
        "word": "year",
        "meaning": "سال",
        "phrase": "this year"
      },
      {
        "word": "May",
        "meaning": "مه",
        "phrase": "in May"
      },
      {
        "word": "June",
        "meaning": "ژوئن",
        "phrase": "in June"
      },
      {
        "word": "today",
        "meaning": "امروز",
        "phrase": "today is Friday"
      },
      {
        "word": "Friday",
        "meaning": "جمعه",
        "phrase": "on Friday"
      },
      {
        "word": "old",
        "meaning": "سالِ سن",
        "phrase": "twenty years old"
      },
      {
        "word": "happy",
        "meaning": "خوشحال / شاد",
        "phrase": "happy birthday"
      },
      {
        "word": "party",
        "meaning": "جشن",
        "phrase": "a birthday party"
      },
      {
        "word": "family",
        "meaning": "خانواده",
        "phrase": "my family"
      },
      {
        "word": "from",
        "meaning": "اهلِ / از",
        "phrase": "from Iran"
      },
      {
        "word": "city",
        "meaning": "شهر",
        "phrase": "my city"
      },
      {
        "word": "celebrate",
        "meaning": "جشن گرفتن",
        "phrase": "celebrate my birthday"
      }
    ]
  },
  "colors1": {
    "grammar": {
      "title": "Color before a noun",
      "titleFa": "رنگ پیش از اسم",
      "formula": "a/the + color + singular noun",
      "explanation": "Put a color before a noun when you describe an item.",
      "explanationFa": "برای توصیف یک وسیله، رنگ را قبل از نام آن می‌آوریم.",
      "examples": [
        "I want a white T-shirt.",
        "I like the red shirt.",
        "I need a blue bag."
      ]
    },
    "vocabulary": [
      {
        "word": "color",
        "meaning": "رنگ",
        "phrase": "What color?"
      },
      {
        "word": "red",
        "meaning": "قرمز",
        "phrase": "red shirt"
      },
      {
        "word": "blue",
        "meaning": "آبی",
        "phrase": "blue jacket"
      },
      {
        "word": "green",
        "meaning": "سبز",
        "phrase": "green bag"
      },
      {
        "word": "black",
        "meaning": "مشکی",
        "phrase": "black shoes"
      },
      {
        "word": "white",
        "meaning": "سفید",
        "phrase": "white T-shirt"
      },
      {
        "word": "yellow",
        "meaning": "زرد",
        "phrase": "yellow dress"
      },
      {
        "word": "brown",
        "meaning": "قهوه‌ای",
        "phrase": "brown hat"
      },
      {
        "word": "gray",
        "meaning": "خاکستری",
        "phrase": "gray socks"
      },
      {
        "word": "shirt",
        "meaning": "پیراهن",
        "phrase": "a red shirt"
      },
      {
        "word": "T-shirt",
        "meaning": "تی‌شرت",
        "phrase": "a white T-shirt"
      },
      {
        "word": "pants",
        "meaning": "شلوار",
        "phrase": "long pants"
      },
      {
        "word": "shoes",
        "meaning": "کفش",
        "phrase": "black shoes"
      },
      {
        "word": "size",
        "meaning": "سایز / اندازه",
        "phrase": "a medium size"
      },
      {
        "word": "small",
        "meaning": "کوچک",
        "phrase": "too small"
      },
      {
        "word": "big",
        "meaning": "بزرگ",
        "phrase": "too big"
      },
      {
        "word": "try on",
        "meaning": "پرو کردن",
        "phrase": "try this on"
      },
      {
        "word": "dress",
        "meaning": "پیراهن زنانه",
        "phrase": "a yellow dress"
      }
    ]
  },
  "animals1": {
    "grammar": {
      "title": "Have a pet",
      "titleFa": "داشتن حیوان خانگی",
      "formula": "I have + a/an + singular animal",
      "explanation": "Use have to say that an animal is your pet.",
      "explanationFa": "برای گفتن اینکه حیوان خانگی داریم از have استفاده می‌کنیم.",
      "examples": [
        "Yes, I have a cat.",
        "I have a dog.",
        "I have a bird."
      ]
    },
    "vocabulary": [
      {
        "word": "pet",
        "meaning": "حیوان خانگی",
        "phrase": "have a pet"
      },
      {
        "word": "cat",
        "meaning": "گربه",
        "phrase": "a cat"
      },
      {
        "word": "dog",
        "meaning": "سگ",
        "phrase": "my dog"
      },
      {
        "word": "bird",
        "meaning": "پرنده",
        "phrase": "a bird"
      },
      {
        "word": "fish",
        "meaning": "ماهی",
        "phrase": "a fish"
      },
      {
        "word": "horse",
        "meaning": "اسب",
        "phrase": "a horse"
      },
      {
        "word": "animal",
        "meaning": "حیوان",
        "phrase": "a small animal"
      },
      {
        "word": "friendly",
        "meaning": "دوست‌داشتنی / خوش‌برخورد",
        "phrase": "a friendly dog"
      },
      {
        "word": "small",
        "meaning": "کوچک",
        "phrase": "a small fish"
      },
      {
        "word": "big",
        "meaning": "بزرگ",
        "phrase": "a big horse"
      },
      {
        "word": "hungry",
        "meaning": "گرسنه",
        "phrase": "my cat is hungry"
      },
      {
        "word": "water",
        "meaning": "آب",
        "phrase": "give my dog water"
      },
      {
        "word": "name",
        "meaning": "اسم",
        "phrase": "its name"
      },
      {
        "word": "home",
        "meaning": "خانه",
        "phrase": "at home"
      },
      {
        "word": "tree",
        "meaning": "درخت",
        "phrase": "in the tree"
      },
      {
        "word": "pet (verb)",
        "meaning": "نوازش کردن حیوان",
        "phrase": "pet your dog"
      },
      {
        "word": "two cats",
        "meaning": "دو گربه",
        "phrase": "I see two cats"
      }
    ]
  },
  "school1": {
    "grammar": {
      "title": "Present simple for study and work",
      "titleFa": "حال ساده برای تحصیل و کار",
      "formula": "I + study/work + time or place",
      "explanation": "Use the present simple to talk about your regular studies or work.",
      "explanationFa": "برای گفتن کارهای معمول در درس یا شغل از زمان حال ساده استفاده می‌کنیم.",
      "examples": [
        "I study English every day.",
        "I work in an office.",
        "I work at a school."
      ]
    },
    "vocabulary": [
      {
        "word": "study",
        "meaning": "درس خواندن",
        "phrase": "study English"
      },
      {
        "word": "work",
        "meaning": "کار کردن",
        "phrase": "work in an office"
      },
      {
        "word": "job",
        "meaning": "شغل",
        "phrase": "my job"
      },
      {
        "word": "teacher",
        "meaning": "معلم",
        "phrase": "a teacher"
      },
      {
        "word": "student",
        "meaning": "دانش‌آموز / دانشجو",
        "phrase": "a student"
      },
      {
        "word": "school",
        "meaning": "مدرسه",
        "phrase": "go to school"
      },
      {
        "word": "class",
        "meaning": "کلاس",
        "phrase": "English class"
      },
      {
        "word": "homework",
        "meaning": "تکلیف",
        "phrase": "have homework"
      },
      {
        "word": "nurse",
        "meaning": "پرستار",
        "phrase": "a nurse"
      },
      {
        "word": "office",
        "meaning": "دفتر",
        "phrase": "in an office"
      },
      {
        "word": "shop",
        "meaning": "مغازه",
        "phrase": "at a shop"
      },
      {
        "word": "start",
        "meaning": "شروع کردن",
        "phrase": "start work"
      },
      {
        "word": "every day",
        "meaning": "هر روز",
        "phrase": "study every day"
      },
      {
        "word": "morning",
        "meaning": "صبح",
        "phrase": "in the morning"
      },
      {
        "word": "today",
        "meaning": "امروز",
        "phrase": "class today"
      },
      {
        "word": "football",
        "meaning": "فوتبال",
        "phrase": "play football"
      },
      {
        "word": "gym",
        "meaning": "باشگاه",
        "phrase": "go to the gym"
      },
      {
        "word": "swimming",
        "meaning": "شنا",
        "phrase": "like swimming"
      }
    ]
  }
};
  const pilotExtras = {
  "intro1": {
    "notes": [
      "I'm شکل کوتاه I am است و در مکالمه بسیار رایج است.",
      "Nice to meet you too پاسخ طبیعی به Nice to meet you است."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "Hello! My name is Sara. What is your name?",
        "fa": "سلام! اسم من سارا است. اسم شما چیست؟"
      },
      {
        "speaker": "B",
        "en": "I'm Ali. Nice to meet you.",
        "fa": "من علی هستم. از آشنایی با شما خوشوقتم."
      },
      {
        "speaker": "A",
        "en": "Nice to meet you too. Are you a student?",
        "fa": "من هم خوشوقتم. دانشجو هستی؟"
      },
      {
        "speaker": "B",
        "en": "Yes, I am.",
        "fa": "بله، هستم."
      }
    ]
  },
  "b3": {
    "notes": [
      "در جملهٔ «I wake up at seven»، عبارت «wake up» به معنی «بیدار شدن» و «at seven» به معنی «ساعت هفت» است.",
      "عبارت «⁦Every morning⁩» یعنی «هر صبح» و نشان می‌دهد کاری تکرار می‌شود؛ مانند «⁦I make breakfast every morning⁩» یعنی «من هر صبح صبحانه درست می‌کنم».",
      "برای بیان ساعت دقیق، «at» را قبل از ساعت می‌آوریم؛ «at seven» یعنی «ساعت هفت» و «at eleven» یعنی «ساعت یازده»."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "What time do you wake up?",
        "fa": "چه ساعتی بیدار می‌شوی؟"
      },
      {
        "speaker": "B",
        "en": "I wake up at seven. I make breakfast every morning.",
        "fa": "ساعت هفت بیدار می‌شوم. هر صبح صبحانه درست می‌کنم."
      },
      {
        "speaker": "A",
        "en": "What time do you come home?",
        "fa": "چه ساعتی به خانه برمی‌گردی؟"
      },
      {
        "speaker": "B",
        "en": "I come home at six.",
        "fa": "ساعت شش به خانه برمی‌گردم."
      }
    ]
  },
  "b1": {
    "notes": [
      "I’d like شکل کوتاه I would like است: I’d like a cappuccino.",
      "For here یعنی در کافه می‌خورم؛ To go یعنی بیرون‌بر."
    ],
    "dialogue": [
      {
        "speaker": "Customer",
        "en": "Can I have a small coffee, please?",
        "fa": "یک قهوهٔ کوچک می‌خواهم، لطفاً."
      },
      {
        "speaker": "Barista",
        "en": "Of course. For here or to go?",
        "fa": "البته. برای همین‌جا یا بیرون‌بر؟"
      },
      {
        "speaker": "Customer",
        "en": "To go, please. Can I have it with milk?",
        "fa": "بیرون‌بر، لطفاً. می‌توانم آن را با شیر بگیرم؟"
      },
      {
        "speaker": "Barista",
        "en": "Yes. Anything else?",
        "fa": "بله. چیز دیگری می‌خواهید؟"
      },
      {
        "speaker": "Customer",
        "en": "No, thank you. Can I pay by card?",
        "fa": "نه، ممنون. می‌توانم با کارت پرداخت کنم؟"
      }
    ]
  },
  "b4": {
    "notes": [
      "برای پرسیدن موجودی رنگ می‌گوییم Do you have this in blue?",
      "برای پرو کردن لباس می‌گوییم Can I try this on?"
    ],
    "dialogue": [
      {
        "speaker": "Customer",
        "en": "Excuse me, how much is this shirt?",
        "fa": "ببخشید، این پیراهن چقدر است؟"
      },
      {
        "speaker": "Staff",
        "en": "It is twenty dollars.",
        "fa": "بیست دلار است."
      },
      {
        "speaker": "Customer",
        "en": "Do you have this in blue?",
        "fa": "این را به رنگ آبی دارید؟"
      },
      {
        "speaker": "Staff",
        "en": "Yes. You can try it on.",
        "fa": "بله. می‌توانید آن را پرو کنید."
      },
      {
        "speaker": "Customer",
        "en": "Great! Where is the fitting room?",
        "fa": "عالی! اتاق پرو کجاست؟"
      }
    ]
  },
  "directions1": {
    "notes": [
      "Excuse me برای شروع مؤدبانهٔ پرسیدن مسیر است.",
      "Next to یعنی درست کنار؛ near یعنی نزدیک، ولی نه لزوماً چسبیده."
    ],
    "dialogue": [
      {
        "speaker": "Traveler",
        "en": "Excuse me, where is the pharmacy?",
        "fa": "ببخشید، داروخانه کجاست؟"
      },
      {
        "speaker": "Local",
        "en": "Go straight. It is next to the hospital.",
        "fa": "مستقیم بروید. کنار بیمارستان است."
      },
      {
        "speaker": "Traveler",
        "en": "Is it far from here?",
        "fa": "از اینجا دور است؟"
      },
      {
        "speaker": "Local",
        "en": "No, it is near here.",
        "fa": "نه، نزدیک همین‌جاست."
      },
      {
        "speaker": "Traveler",
        "en": "Thank you for your help.",
        "fa": "از کمکتان ممنونم."
      }
    ]
  },
  "birthday1": {
    "notes": [
      "برای تاریخ دقیق می‌گوییم on May tenth؛ برای ماه می‌گوییم in May.",
      "I was born in Tehran یعنی «در تهران متولد شدم»؛ این عبارت را یک‌جا یاد بگیر."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "When is your birthday?",
        "fa": "تولدت چه زمانی است؟"
      },
      {
        "speaker": "B",
        "en": "My birthday is on May tenth.",
        "fa": "تولد من دهم ماه مه است."
      },
      {
        "speaker": "A",
        "en": "Where were you born?",
        "fa": "کجا متولد شدی؟"
      },
      {
        "speaker": "B",
        "en": "I was born in Tehran.",
        "fa": "در تهران متولد شدم."
      },
      {
        "speaker": "A",
        "en": "Happy birthday!",
        "fa": "تولدت مبارک!"
      },
      {
        "speaker": "B",
        "en": "Thank you!",
        "fa": "ممنون!"
      }
    ]
  },
  "colors1": {
    "notes": [
      "می‌گوییم a red shirt؛ رنگ پیش از اسم می‌آید.",
      "برای پرسیدن رنگ می‌گوییم What color is this?"
    ],
    "dialogue": [
      {
        "speaker": "Customer",
        "en": "Do you have this shirt in blue?",
        "fa": "این پیراهن را به رنگ آبی دارید؟"
      },
      {
        "speaker": "Clerk",
        "en": "Yes. What size do you need?",
        "fa": "بله. چه سایزی می‌خواهید؟"
      },
      {
        "speaker": "Customer",
        "en": "Medium, please. Can I try it on?",
        "fa": "متوسط، لطفاً. می‌توانم آن را پرو کنم؟"
      },
      {
        "speaker": "Clerk",
        "en": "Of course.",
        "fa": "البته."
      }
    ]
  },
  "animals1": {
    "notes": [
      "برای یک حیوان می‌گوییم a cat و برای چند حیوان cats.",
      "Its name یعنی «اسم آن»؛ it’s کوتاه‌شدهٔ it is است."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "Do you have a pet?",
        "fa": "حیوان خانگی داری؟"
      },
      {
        "speaker": "B",
        "en": "Yes, I have a cat.",
        "fa": "بله، یک گربه دارم."
      },
      {
        "speaker": "A",
        "en": "What is its name?",
        "fa": "اسمش چیست؟"
      },
      {
        "speaker": "B",
        "en": "Its name is Luna.",
        "fa": "اسمش لونا است."
      }
    ]
  },
  "school1": {
    "notes": [
      "برای فعالیت معمول می‌گوییم I study English every day؛ هر روز درس می‌خوانم.",
      "برای شغل می‌توانیم بگوییم I’m a teacher یا I work at a shop."
    ],
    "dialogue": [
      {
        "speaker": "A",
        "en": "What do you do?",
        "fa": "شغلت چیست؟"
      },
      {
        "speaker": "B",
        "en": "I’m a teacher. What about you?",
        "fa": "معلم هستم. تو چطور؟"
      },
      {
        "speaker": "A",
        "en": "I’m a student. I study English.",
        "fa": "دانشجو هستم. انگلیسی می‌خوانم."
      },
      {
        "speaker": "B",
        "en": "That’s nice.",
        "fa": "چه خوب."
      }
    ]
  }
};
  // Derive word translations from the vocabulary shipped with the lessons.
  // This keeps the app self-contained in projects without a wordMeanings.js file.
  const normalizeWord = (word) => word.toLowerCase().replace(/’/g, "'").replace(/[^a-z']/g, '');
  const wordMeanings = Object.fromEntries(
    Object.values({ ...lessonLearningContent, ...extraLearningContent, ...pilotLearningContent })
      .flatMap((content) => content.vocabulary || [])
      .filter((item) => /^[a-z]+$/i.test(item.word))
      .map((item) => [normalizeWord(item.word), item.meaning])
  );
  const [screen, setScreen] = useState('home');
  const [lessonLevel, setLessonLevel] = useState('a1');
  const [selectedLessonIndex, setSelectedLessonIndex] = useState(0);
  const [sentenceIndex, setSentenceIndex] = useState(0);
  const [lessonSection, setLessonSection] = useState('grammar');
  const [lessonSectionHistory, setLessonSectionHistory] = useState([]);
  const [lastLessonPosition, setLastLessonPosition] = useState(null);
  const [saved, setSaved] = useState([]);
  const [levels, setLevels] = useState({});
  const [completedLessons, setCompletedLessons] = useState([]);
  const [reviewSchedules, setReviewSchedules] = useState({});
  const [reviewLessonId, setReviewLessonId] = useState(null);
  const [reviewSentenceIndex, setReviewSentenceIndex] = useState(0);
  const [reviewIntervals, setReviewIntervals] = useState([3, 7, 10, 14, 30]);
  const [customReviewDay, setCustomReviewDay] = useState('');
  const [customItems, setCustomItems] = useState([]);
  const [customType, setCustomType] = useState('Word');
  const [customEnglish, setCustomEnglish] = useState('');
  const [customPersian, setCustomPersian] = useState('');
  const [customDifficulty, setCustomDifficulty] = useState('Easy');
  const [selectedWord, setSelectedWord] = useState(null);
  const [wordDifficulty, setWordDifficulty] = useState('Easy');
  const [conversationInput, setConversationInput] = useState('');
  const [conversationMessages, setConversationMessages] = useState([
    {
      id: 'coach-welcome',
      role: 'coach',
      text: 'Hi! I am your LingoLoop speaking coach. How are you today?',
      translation: 'سلام! من مربی مکالمه لینگولوپ هستم. امروز حالت چطور است؟',
    },
  ]);
  const [storageReady, setStorageReady] = useState(false);
  const [remoteContent, setRemoteContent] = useState({});
  useEffect(() => {
    let active = true;
    const contentUrl = appConfig.expo?.extra?.contentApiUrl;
    const validContent = (data) => data && typeof data === 'object' && !Array.isArray(data);
    (async () => {
      try {
        const cached = await AsyncStorage.getItem('lingoloopApprovedContentV1');
        if (active && cached) {
          const parsed = JSON.parse(cached);
          if (validContent(parsed)) setRemoteContent(parsed);
        }
        if (!contentUrl) return;
        const response = await fetch(`${contentUrl.replace(/\/$/, '')}/content`);
        if (!response.ok) throw new Error(`Content HTTP ${response.status}`);
        const data = await response.json();
        if (!validContent(data)) throw new Error('Invalid content response');
        await AsyncStorage.setItem('lingoloopApprovedContentV1', JSON.stringify(data));
        if (active) setRemoteContent(data);
      } catch (error) {
        console.log('Approved content update unavailable:', error);
      }
    })();
    return () => { active = false; };
  }, []);
  useEffect(() => {
  const loadData = async () => {
    try {
      const savedData = await AsyncStorage.getItem('saved');
      const levelsData = await AsyncStorage.getItem('levels');
      const completedData = await AsyncStorage.getItem('completedLessons');
      const reviewData = await AsyncStorage.getItem('reviewSchedules');
      const reviewIntervalsData = await AsyncStorage.getItem('reviewIntervals');
      const customItemsData = await AsyncStorage.getItem('customItems');
      const lastLessonData = await AsyncStorage.getItem('lastLessonPosition');

      if (savedData) setSaved(JSON.parse(savedData));
      if (levelsData) setLevels(JSON.parse(levelsData));
      if (completedData) {
        const completed = JSON.parse(completedData);
        setCompletedLessons(completed);

        if (!reviewData) {
          const startedAt = new Date().toISOString();
          const firstSchedules = completed.reduce((result, lessonId) => {
            result[lessonId] = { startedAt, completedIntervals: [] };
            return result;
          }, {});
          setReviewSchedules(firstSchedules);
        }
      }
      if (reviewData) setReviewSchedules(JSON.parse(reviewData));
      if (reviewIntervalsData) {
        setReviewIntervals(JSON.parse(reviewIntervalsData));
      }
      if (customItemsData) setCustomItems(JSON.parse(customItemsData));
      if (lastLessonData) setLastLessonPosition(JSON.parse(lastLessonData));
    } catch (error) {
      console.log('Error loading data:', error);
    } finally {
      setStorageReady(true);
    }
  };

  loadData();
}, []);
  useEffect(() => {
  if (!storageReady) return;

  AsyncStorage.setItem('saved', JSON.stringify(saved));
  AsyncStorage.setItem('levels', JSON.stringify(levels));
  AsyncStorage.setItem(
    'completedLessons',
    JSON.stringify(completedLessons)
  );
  AsyncStorage.setItem('reviewSchedules', JSON.stringify(reviewSchedules));
  AsyncStorage.setItem('reviewIntervals', JSON.stringify(reviewIntervals));
  AsyncStorage.setItem('customItems', JSON.stringify(customItems));
}, [saved, levels, completedLessons, reviewSchedules, reviewIntervals, customItems, storageReady]);
  useEffect(() => {
    if (!storageReady) return;
    AsyncStorage.setItem('lastLessonPosition', JSON.stringify(lastLessonPosition));
  }, [lastLessonPosition, storageReady]);
  const lessons = lessonGroups[lessonLevel];
  const currentLesson = lessons[selectedLessonIndex];

  const resumeLevel = lastLessonPosition && lessonGroups[lastLessonPosition.level]
    ? lastLessonPosition.level : 'a1';
  const resumeIndex = lastLessonPosition
    ? lessonGroups[resumeLevel].findIndex((lesson) => lesson.id === lastLessonPosition.lessonId)
    : -1;
  const resumeLesson = lessonGroups[resumeLevel][resumeIndex < 0 ? 0 : resumeIndex];
  useEffect(() => {
    if (!storageReady || screen !== 'lesson' || !currentLesson) return;
    setLastLessonPosition({
      level: lessonLevel,
      lessonId: currentLesson.id,
      section: lessonSection,
      sentenceIndex,
    });
  }, [storageReady, screen, lessonLevel, selectedLessonIndex, lessonSection, sentenceIndex]);

  const continueLesson = () => {
    const section = lastLessonPosition?.section;
    const sectionOrder = ['grammar', 'vocabulary', 'dialogue', 'examples'];
    const validSection = sectionOrder.includes(section) ? section : 'grammar';
    setLessonLevel(resumeLevel);
    setSelectedLessonIndex(resumeIndex < 0 ? 0 : resumeIndex);
    setSentenceIndex(Math.min(
      Math.max(0, Number(lastLessonPosition?.sentenceIndex) || 0),
      resumeLesson.sentences.length - 1
    ));
    setLessonSection(validSection);
    setLessonSectionHistory(sectionOrder.slice(0, sectionOrder.indexOf(validSection)));
    setSelectedWord(null);
    setScreen('lesson');
  };
  const currentSentence = currentLesson?.sentences[sentenceIndex];
  const completedLearningContent = {"a1numbers": {"grammar": {"title": "Birthdays, Numbers & Time: useful patterns", "titleFa": "ساختارهای کاربردی: تاریخ تولد، اعداد و ساعت", "formula": "It is + time / My birthday is on + date", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «تاریخ تولد، اعداد و ساعت» صحبت کنید.", "examples": ["What time is it?", "It is nine o’clock.", "My birthday is on June fifth."], "examplesFa": ["ساعت چند است؟", "ساعت نه است.", "تولدم پنجم ژوئن است."]}, "vocabulary": [{"word": "birthday", "meaning": "تولد", "phrase": "my birthday"}, {"word": "clock", "meaning": "ساعت", "phrase": "nine o’clock"}, {"word": "appointment", "meaning": "قرار ملاقات", "phrase": "my appointment"}, {"word": "Monday", "meaning": "دوشنبه", "phrase": "on Monday"}]}, "a1family": {"grammar": {"title": "Family & Friends: useful patterns", "titleFa": "ساختارهای کاربردی: خانواده و دوستان", "formula": "This is my + family member", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «خانواده و دوستان» صحبت کنید.", "examples": ["This is my mother.", "I have one brother and two sisters.", "My father is a teacher."], "examplesFa": ["این مادر من است.", "من یک برادر و دو خواهر دارم.", "پدرم معلم است."]}, "vocabulary": [{"word": "mother", "meaning": "مادر", "phrase": "my mother"}, {"word": "brother", "meaning": "برادر", "phrase": "one brother"}, {"word": "sister", "meaning": "خواهر", "phrase": "two sisters"}, {"word": "friend", "meaning": "دوست", "phrase": "my friend"}]}, "a1house": {"grammar": {"title": "Home & Household Items: useful patterns", "titleFa": "ساختارهای کاربردی: خانه و وسایل", "formula": "There is / There are + item + place", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «خانه و وسایل» صحبت کنید.", "examples": ["There is a table in the kitchen.", "The sofa is in the living room.", "Where is my phone?"], "examplesFa": ["یک میز در آشپزخانه هست.", "مبل در اتاق نشیمن است.", "گوشی من کجاست؟"]}, "vocabulary": [{"word": "kitchen", "meaning": "آشپزخانه", "phrase": "in the kitchen"}, {"word": "sofa", "meaning": "مبل", "phrase": "the sofa"}, {"word": "bedroom", "meaning": "اتاق خواب", "phrase": "next to the bedroom"}, {"word": "towel", "meaning": "حوله", "phrase": "a clean towel"}]}, "a1transport": {"grammar": {"title": "Transportation: useful patterns", "titleFa": "ساختارهای کاربردی: حمل‌ونقل", "formula": "How do I get to + place?", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «حمل‌ونقل» صحبت کنید.", "examples": ["Where is the bus stop?", "I go to work by bus.", "How much is a ticket?"], "examplesFa": ["ایستگاه اتوبوس کجاست؟", "من با اتوبوس به محل کار می‌روم.", "قیمت بلیت چقدر است؟"]}, "vocabulary": [{"word": "bus", "meaning": "اتوبوس", "phrase": "by bus"}, {"word": "ticket", "meaning": "بلیت", "phrase": "one ticket"}, {"word": "train", "meaning": "قطار", "phrase": "the next train"}, {"word": "taxi", "meaning": "تاکسی", "phrase": "a taxi"}]}, "a1weather": {"grammar": {"title": "Weather: useful patterns", "titleFa": "ساختارهای کاربردی: آب‌وهوا", "formula": "It is + weather adjective", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «آب‌وهوا» صحبت کنید.", "examples": ["What is the weather like today?", "It is sunny and warm.", "It is raining now."], "examplesFa": ["امروز هوا چطور است؟", "هوا آفتابی و گرم است.", "الان باران می‌بارد."]}, "vocabulary": [{"word": "sunny", "meaning": "آفتابی", "phrase": "sunny and warm"}, {"word": "rain", "meaning": "باران", "phrase": "it is raining"}, {"word": "umbrella", "meaning": "چتر", "phrase": "your umbrella"}, {"word": "windy", "meaning": "بادخیز", "phrase": "windy outside"}]}, "a1hobbies": {"grammar": {"title": "Sports & Hobbies: useful patterns", "titleFa": "ساختارهای کاربردی: ورزش و سرگرمی", "formula": "I like + activity / I play + sport", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «ورزش و سرگرمی» صحبت کنید.", "examples": ["What do you do for fun?", "I like reading books.", "I play football on Fridays."], "examplesFa": ["برای تفریح چه کار می‌کنی؟", "من کتاب خواندن را دوست دارم.", "جمعه‌ها فوتبال بازی می‌کنم."]}, "vocabulary": [{"word": "hobby", "meaning": "سرگرمی", "phrase": "my hobby"}, {"word": "reading", "meaning": "کتاب‌خوانی", "phrase": "reading books"}, {"word": "swimming", "meaning": "شنا", "phrase": "go swimming"}, {"word": "drawing", "meaning": "نقاشی کشیدن", "phrase": "drawing at home"}]}, "a1health": {"grammar": {"title": "Health & Asking for Help: useful patterns", "titleFa": "ساختارهای کاربردی: سلامت و درخواست کمک", "formula": "I have + symptom / Can you help me?", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «سلامت و درخواست کمک» صحبت کنید.", "examples": ["I do not feel well.", "I have a headache.", "Can you help me, please?"], "examplesFa": ["حالم خوب نیست.", "سردرد دارم.", "می‌توانید لطفاً به من کمک کنید؟"]}, "vocabulary": [{"word": "headache", "meaning": "سردرد", "phrase": "have a headache"}, {"word": "pharmacy", "meaning": "داروخانه", "phrase": "the pharmacy"}, {"word": "doctor", "meaning": "پزشک", "phrase": "a doctor"}, {"word": "ambulance", "meaning": "آمبولانس", "phrase": "call an ambulance"}]}, "a1phone": {"grammar": {"title": "Phone & Messages: useful patterns", "titleFa": "ساختارهای کاربردی: تلفن و پیام", "formula": "Can I speak to + person?", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «تلفن و پیام» صحبت کنید.", "examples": ["Can I call you later?", "What is your phone number?", "I will send you a message."], "examplesFa": ["می‌توانم بعداً به تو زنگ بزنم؟", "شمارهٔ تلفنت چیست؟", "برایت پیام می‌فرستم."]}, "vocabulary": [{"word": "message", "meaning": "پیام", "phrase": "send a message"}, {"word": "call", "meaning": "تماس گرفتن", "phrase": "call me later"}, {"word": "number", "meaning": "شماره", "phrase": "phone number"}, {"word": "hear", "meaning": "شنیدن", "phrase": "hear you"}]}, "a1travel": {"grammar": {"title": "Airport & Hotel: useful patterns", "titleFa": "ساختارهای کاربردی: فرودگاه و هتل", "formula": "Where is + place? / I have + reservation", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «فرودگاه و هتل» صحبت کنید.", "examples": ["Where is the check-in desk?", "Here is my passport.", "What time does the flight leave?"], "examplesFa": ["کانتر پذیرش پرواز کجاست؟", "این هم گذرنامهٔ من.", "پرواز چه ساعتی حرکت می‌کند؟"]}, "vocabulary": [{"word": "passport", "meaning": "گذرنامه", "phrase": "my passport"}, {"word": "flight", "meaning": "پرواز", "phrase": "the flight"}, {"word": "reservation", "meaning": "رزرو", "phrase": "hotel reservation"}, {"word": "breakfast", "meaning": "صبحانه", "phrase": "breakfast included"}]}, "a2past": {"grammar": {"title": "Last Weekend & Past Events: useful patterns", "titleFa": "ساختارهای کاربردی: آخر هفتهٔ گذشته و رویدادها", "formula": "I + past verb + time", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «آخر هفتهٔ گذشته و رویدادها» صحبت کنید.", "examples": ["What did you do last weekend?", "I visited my aunt on Saturday.", "We watched a movie together."], "examplesFa": ["آخر هفتهٔ گذشته چه کار کردی؟", "شنبه به دیدن خاله‌ام رفتم.", "با هم فیلم تماشا کردیم."]}, "vocabulary": [{"word": "visited", "meaning": "دیدار کردم", "phrase": "visited my aunt"}, {"word": "stayed", "meaning": "ماندم", "phrase": "stayed at home"}, {"word": "arrived", "meaning": "رسید", "phrase": "arrived late"}, {"word": "enjoy", "meaning": "لذت بردن", "phrase": "enjoy the trip"}]}, "a2future": {"grammar": {"title": "Future Plans & Goals: useful patterns", "titleFa": "ساختارهای کاربردی: برنامه‌ها و هدف‌های آینده", "formula": "I am going to + base verb", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «برنامه‌ها و هدف‌های آینده» صحبت کنید.", "examples": ["What are you going to do tomorrow?", "I am going to study English.", "We are visiting my cousin next week."], "examplesFa": ["فردا قرار است چه کار کنی؟", "قرار است انگلیسی بخوانم.", "هفتهٔ آینده به دیدن پسرعمویم می‌رویم."]}, "vocabulary": [{"word": "plan", "meaning": "برنامه", "phrase": "future plan"}, {"word": "tomorrow", "meaning": "فردا", "phrase": "tomorrow morning"}, {"word": "hope", "meaning": "امیدوار بودن", "phrase": "I hope"}, {"word": "goal", "meaning": "هدف", "phrase": "my goal"}]}, "a2preferences": {"grammar": {"title": "Likes, Dislikes & Preferences: useful patterns", "titleFa": "ساختارهای کاربردی: علاقه‌ها و ترجیح‌ها", "formula": "I prefer + noun + to + noun", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «علاقه‌ها و ترجیح‌ها» صحبت کنید.", "examples": ["Do you prefer tea or coffee?", "I prefer tea to coffee.", "I enjoy cooking at home."], "examplesFa": ["چای را ترجیح می‌دهی یا قهوه؟", "چای را به قهوه ترجیح می‌دهم.", "از آشپزی در خانه لذت می‌برم."]}, "vocabulary": [{"word": "prefer", "meaning": "ترجیح دادن", "phrase": "prefer tea"}, {"word": "crowded", "meaning": "شلوغ", "phrase": "crowded places"}, {"word": "because", "meaning": "چون", "phrase": "because it is interesting"}, {"word": "rather", "meaning": "ترجیحاً", "phrase": "would rather walk"}]}, "a2comparison": {"grammar": {"title": "Comparing People & Places: useful patterns", "titleFa": "ساختارهای کاربردی: مقایسهٔ افراد و مکان‌ها", "formula": "A is + comparative + than B", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «مقایسهٔ افراد و مکان‌ها» صحبت کنید.", "examples": ["This room is bigger than mine.", "The bus is cheaper than a taxi.", "Which city is more crowded?"], "examplesFa": ["این اتاق از اتاق من بزرگ‌تر است.", "اتوبوس از تاکسی ارزان‌تر است.", "کدام شهر شلوغ‌تر است؟"]}, "vocabulary": [{"word": "bigger", "meaning": "بزرگ‌تر", "phrase": "bigger than mine"}, {"word": "cheaper", "meaning": "ارزان‌تر", "phrase": "cheaper than a taxi"}, {"word": "crowded", "meaning": "شلوغ", "phrase": "more crowded"}, {"word": "expensive", "meaning": "گران", "phrase": "the most expensive"}]}, "a2home": {"grammar": {"title": "Renting a Room: useful patterns", "titleFa": "ساختارهای کاربردی: اجارهٔ اتاق", "formula": "Does the room have + item?", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «اجارهٔ اتاق» صحبت کنید.", "examples": ["Is this room still available?", "How much is the rent each month?", "Are bills included?"], "examplesFa": ["این اتاق هنوز خالی است؟", "اجارهٔ ماهانه چقدر است؟", "هزینهٔ قبض‌ها شامل اجاره می‌شود؟"]}, "vocabulary": [{"word": "rent", "meaning": "اجاره", "phrase": "monthly rent"}, {"word": "bills", "meaning": "قبض‌ها", "phrase": "bills included"}, {"word": "available", "meaning": "خالی / موجود", "phrase": "room available"}, {"word": "move in", "meaning": "ساکن شدن", "phrase": "move in tomorrow"}]}, "a2shopping": {"grammar": {"title": "Returns & Exchanges: useful patterns", "titleFa": "ساختارهای کاربردی: مرجوع‌کردن و تعویض کالا", "formula": "I would like to return / exchange + item", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «مرجوع‌کردن و تعویض کالا» صحبت کنید.", "examples": ["I bought this yesterday.", "I would like to return it.", "Do you have the receipt?"], "examplesFa": ["این را دیروز خریدم.", "می‌خواهم آن را پس بدهم.", "رسید را دارید؟"]}, "vocabulary": [{"word": "return", "meaning": "پس دادن کالا", "phrase": "return it"}, {"word": "receipt", "meaning": "رسید", "phrase": "the receipt"}, {"word": "exchange", "meaning": "تعویض کردن", "phrase": "exchange it"}, {"word": "refund", "meaning": "بازپرداخت", "phrase": "a refund"}]}, "a2restaurant": {"grammar": {"title": "Restaurant Requests & Problems: useful patterns", "titleFa": "ساختارهای کاربردی: درخواست‌ها و مشکلات رستوران", "formula": "Could you + base verb + please?", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «درخواست‌ها و مشکلات رستوران» صحبت کنید.", "examples": ["Could we have a table for three?", "I have a reservation under Azizi.", "Does this dish contain nuts?"], "examplesFa": ["می‌شود یک میز برای سه نفر داشته باشیم؟", "به نام عزیزی رزرو دارم.", "این غذا آجیل دارد؟"]}, "vocabulary": [{"word": "contain", "meaning": "داشتن / شامل بودن", "phrase": "contain nuts"}, {"word": "reservation", "meaning": "رزرو", "phrase": "a reservation"}, {"word": "separately", "meaning": "جداگانه", "phrase": "pay separately"}, {"word": "spicy", "meaning": "تند", "phrase": "less spicy"}]}, "a2health": {"grammar": {"title": "Symptoms & Doctor Appointments: useful patterns", "titleFa": "ساختارهای کاربردی: نشانه‌های بیماری و نوبت پزشک", "formula": "I have had + symptom + for + duration", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «نشانه‌های بیماری و نوبت پزشک» صحبت کنید.", "examples": ["I would like to make an appointment.", "I have had a cough for three days.", "Do you have a fever?"], "examplesFa": ["می‌خواهم وقت پزشک بگیرم.", "سه روز است سرفه دارم.", "تب دارید؟"]}, "vocabulary": [{"word": "appointment", "meaning": "نوبت", "phrase": "make an appointment"}, {"word": "cough", "meaning": "سرفه", "phrase": "have a cough"}, {"word": "fever", "meaning": "تب", "phrase": "have a fever"}, {"word": "medicine", "meaning": "دارو", "phrase": "take this medicine"}]}, "a2work": {"grammar": {"title": "Job Interviews & Experience: useful patterns", "titleFa": "ساختارهای کاربردی: مصاحبهٔ شغلی و سابقهٔ کار", "formula": "I have worked + place + for + duration", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «مصاحبهٔ شغلی و سابقهٔ کار» صحبت کنید.", "examples": ["Tell me about your work experience.", "I worked in a shop for two years.", "What are your main skills?"], "examplesFa": ["دربارهٔ سابقهٔ کارت بگو.", "دو سال در مغازه کار کردم.", "مهارت‌های اصلی‌ات چیست؟"]}, "vocabulary": [{"word": "experience", "meaning": "تجربه", "phrase": "work experience"}, {"word": "skills", "meaning": "مهارت‌ها", "phrase": "main skills"}, {"word": "customers", "meaning": "مشتریان", "phrase": "help customers"}, {"word": "working hours", "meaning": "ساعت‌های کاری", "phrase": "explain the working hours"}]}, "a2studies": {"grammar": {"title": "Classes & Learning Goals: useful patterns", "titleFa": "ساختارهای کاربردی: کلاس‌ها و هدف‌های یادگیری", "formula": "I am learning + subject + because + reason", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «کلاس‌ها و هدف‌های یادگیری» صحبت کنید.", "examples": ["What are you studying now?", "I am taking an English course.", "The lessons are getting harder."], "examplesFa": ["الان چه چیزی می‌خوانی؟", "در یک دورهٔ انگلیسی شرکت می‌کنم.", "درس‌ها دارند سخت‌تر می‌شوند."]}, "vocabulary": [{"word": "course", "meaning": "دوره", "phrase": "an English course"}, {"word": "practice", "meaning": "تمرین کردن", "phrase": "practice speaking"}, {"word": "homework", "meaning": "تکلیف", "phrase": "finish homework"}, {"word": "confidently", "meaning": "با اعتمادبه‌نفس", "phrase": "speak confidently"}]}, "a2travel": {"grammar": {"title": "Travel Arrangements & Delays: useful patterns", "titleFa": "ساختارهای کاربردی: برنامهٔ سفر و تأخیرها", "formula": "My + transport + has been delayed", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «برنامهٔ سفر و تأخیرها» صحبت کنید.", "examples": ["I booked a ticket for Tuesday.", "Can I change my travel date?", "My flight has been delayed."], "examplesFa": ["برای سه‌شنبه بلیت رزرو کردم.", "می‌توانم تاریخ سفرم را عوض کنم؟", "پروازم تأخیر داشته است."]}, "vocabulary": [{"word": "delay", "meaning": "تأخیر", "phrase": "flight delay"}, {"word": "refund", "meaning": "بازپرداخت", "phrase": "get a refund"}, {"word": "traffic", "meaning": "ترافیک", "phrase": "because of traffic"}, {"word": "ticket", "meaning": "بلیت", "phrase": "book a ticket"}]}, "a2hotel": {"grammar": {"title": "Hotel Check-in & Requests: useful patterns", "titleFa": "ساختارهای کاربردی: پذیرش هتل و درخواست‌ها", "formula": "Could I have + item + please?", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «پذیرش هتل و درخواست‌ها» صحبت کنید.", "examples": ["I have a reservation for two nights.", "May I see your passport?", "Could I have a quiet room?"], "examplesFa": ["برای دو شب اتاق رزرو کرده‌ام.", "ممکن است گذرنامه‌تان را ببینم؟", "می‌توانم یک اتاق ساکت داشته باشم؟"]}, "vocabulary": [{"word": "check-out", "meaning": "تحویل اتاق", "phrase": "check-out time"}, {"word": "quiet", "meaning": "ساکت", "phrase": "a quiet room"}, {"word": "air conditioner", "meaning": "دستگاه تهویه", "phrase": "the air conditioner"}, {"word": "served", "meaning": "سرو می‌شود", "phrase": "breakfast is served"}]}, "a2directions": {"grammar": {"title": "Giving Detailed Directions: useful patterns", "titleFa": "ساختارهای کاربردی: مسیر دادن با جزئیات", "formula": "Go past + place, then turn + direction", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «مسیر دادن با جزئیات» صحبت کنید.", "examples": ["Go straight until you reach the square.", "Turn left after the pharmacy.", "The museum is across from the park."], "examplesFa": ["مستقیم برو تا به میدان برسی.", "بعد از داروخانه به چپ بپیچ.", "موزه روبه‌روی پارک است."]}, "vocabulary": [{"word": "square", "meaning": "میدان", "phrase": "reach the square"}, {"word": "corner", "meaning": "نبش", "phrase": "on the corner"}, {"word": "across from", "meaning": "روبه‌روی", "phrase": "across from the park"}, {"word": "on foot", "meaning": "پیاده", "phrase": "ten minutes on foot"}]}, "a2messages": {"grammar": {"title": "Emails & Phone Conversations: useful patterns", "titleFa": "ساختارهای کاربردی: ایمیل و گفت‌وگوی تلفنی", "formula": "Could you please + base verb?", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «ایمیل و گفت‌وگوی تلفنی» صحبت کنید.", "examples": ["I am writing to ask about the course.", "Could you send me the details?", "I will reply by tomorrow."], "examplesFa": ["برای پرسیدن دربارهٔ دوره ایمیل می‌نویسم.", "می‌توانید جزئیات را برایم بفرستید؟", "تا فردا پاسخ می‌دهم."]}, "vocabulary": [{"word": "details", "meaning": "جزئیات", "phrase": "send the details"}, {"word": "reply", "meaning": "پاسخ دادن", "phrase": "reply tomorrow"}, {"word": "voicemail", "meaning": "پیام صوتی", "phrase": "leave a voicemail"}, {"word": "confirm", "meaning": "تأیید کردن", "phrase": "confirm receipt"}]}, "a2weather": {"grammar": {"title": "Weather & Changing Plans: useful patterns", "titleFa": "ساختارهای کاربردی: آب‌وهوا و تغییر برنامه", "formula": "If + weather, we will + action", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «آب‌وهوا و تغییر برنامه» صحبت کنید.", "examples": ["It looks like it will rain.", "If it rains, we will stay inside.", "The forecast says it will be windy."], "examplesFa": ["به نظر می‌رسد باران می‌بارد.", "اگر باران ببارد، داخل می‌مانیم.", "پیش‌بینی هوا می‌گوید باد می‌آید."]}, "vocabulary": [{"word": "forecast", "meaning": "پیش‌بینی هوا", "phrase": "the forecast"}, {"word": "windy", "meaning": "بادی", "phrase": "be windy"}, {"word": "picnic", "meaning": "پیک‌نیک", "phrase": "go on a picnic"}, {"word": "instead", "meaning": "به‌جای آن", "phrase": "tomorrow instead"}]}, "a2hobbies": {"grammar": {"title": "Hobbies & Recent Experiences: useful patterns", "titleFa": "ساختارهای کاربردی: سرگرمی‌ها و تجربه‌های اخیر", "formula": "I have recently + past participle", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «سرگرمی‌ها و تجربه‌های اخیر» صحبت کنید.", "examples": ["Have you tried painting before?", "I started learning the guitar last month.", "I have recently joined a sports club."], "examplesFa": ["قبلاً نقاشی را امتحان کرده‌ای؟", "ماه گذشته یادگیری گیتار را شروع کردم.", "اخیراً عضو یک باشگاه ورزشی شده‌ام."]}, "vocabulary": [{"word": "recently", "meaning": "اخیراً", "phrase": "recently joined"}, {"word": "practice", "meaning": "تمرین کردن", "phrase": "practice twice a week"}, {"word": "recommend", "meaning": "پیشنهاد کردن", "phrase": "recommend a hobby"}, {"word": "guitar", "meaning": "گیتار", "phrase": "learn the guitar"}]}, "a2repair": {"grammar": {"title": "Repairs & Services: useful patterns", "titleFa": "ساختارهای کاربردی: تعمیرات و خدمات", "formula": "The + item + is not working", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «تعمیرات و خدمات» صحبت کنید.", "examples": ["My phone is not working properly.", "The screen stopped working yesterday.", "Could you take a look at it?"], "examplesFa": ["گوشی‌ام درست کار نمی‌کند.", "صفحه‌نمایش دیروز از کار افتاد.", "می‌توانید نگاهی به آن بیندازید؟"]}, "vocabulary": [{"word": "repair", "meaning": "تعمیر", "phrase": "the repair"}, {"word": "screen", "meaning": "صفحه‌نمایش", "phrase": "the screen"}, {"word": "warranty", "meaning": "ضمانت", "phrase": "under warranty"}, {"word": "estimate", "meaning": "برآورد هزینه", "phrase": "an estimate"}]}, "a2opinions": {"grammar": {"title": "Opinions & Reasons: useful patterns", "titleFa": "ساختارهای کاربردی: نظرها و دلیل‌ها", "formula": "I think + idea + because + reason", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «نظرها و دلیل‌ها» صحبت کنید.", "examples": ["What do you think about this idea?", "I think it is useful because it saves time.", "I agree with you."], "examplesFa": ["دربارهٔ این ایده چه فکر می‌کنی؟", "فکر می‌کنم مفید است چون در وقت صرفه‌جویی می‌کند.", "با تو موافقم."]}, "vocabulary": [{"word": "opinion", "meaning": "نظر", "phrase": "in my opinion"}, {"word": "agree", "meaning": "موافق بودن", "phrase": "agree with you"}, {"word": "option", "meaning": "گزینه", "phrase": "the second option"}, {"word": "decide", "meaning": "تصمیم گرفتن", "phrase": "decide together"}]}, "a2stories": {"grammar": {"title": "Telling a Short Story: useful patterns", "titleFa": "ساختارهای کاربردی: تعریف یک داستان کوتاه", "formula": "First…, then…, finally…", "explanation": "Practice this useful pattern with the examples below.", "explanationFa": "با الگوی بالا دربارهٔ «تعریف یک داستان کوتاه» صحبت کنید.", "examples": ["Yesterday I went to the market.", "First, I bought some fruit.", "Then I met an old friend."], "examplesFa": ["دیروز به بازار رفتم.", "اول کمی میوه خریدم.", "بعد یکی از دوستان قدیمی‌ام را دیدم."]}, "vocabulary": [{"word": "first", "meaning": "اول", "phrase": "first I bought fruit"}, {"word": "then", "meaning": "سپس", "phrase": "then I met a friend"}, {"word": "while", "meaning": "وقتی که", "phrase": "while we were talking"}, {"word": "finally", "meaning": "سرانجام", "phrase": "finally I took a taxi"}]}};
  const upperVocabulary = {
    b1: [
      ['issue', 'موضوع / مشکل'], ['option', 'گزینه'], ['advantage', 'مزیت'], ['difficulty', 'دشواری'],
      ['experience', 'تجربه'], ['solution', 'راه‌حل'], ['recommend', 'پیشنهاد کردن'], ['reasonable', 'منطقی'],
      ['consider', 'بررسی کردن'], ['improve', 'بهبود یافتن'],
    ],
    b2: [
      ['evidence', 'شواهد'], ['approach', 'رویکرد'], ['benefit', 'مزیت'], ['risk', 'خطر'],
      ['outcome', 'نتیجه'], ['balanced', 'متعادل'], ['consequence', 'پیامد'], ['factor', 'عامل'],
      ['perspective', 'دیدگاه'], ['conclusion', 'نتیجه‌گیری'],
    ],
    c1: [
      ['framework', 'چارچوب'], ['premise', 'مقدمه / پیش‌فرض'], ['inference', 'استنباط'], ['constraint', 'محدودیت'],
      ['implication', 'پیامد ضمنی'], ['consensus', 'اجماع'], ['scrutiny', 'بررسی موشکافانه'], ['correlation', 'همبستگی'],
      ['causation', 'رابطهٔ علّی'], ['interpretation', 'تفسیر'], ['assumption', 'فرض'], ['dimension', 'بُعد'],
      ['principle', 'اصل'], ['finding', 'یافته'], ['methodology', 'روش‌شناسی'], ['priority', 'اولویت'],
      ['coherence', 'انسجام'], ['validity', 'اعتبار'], ['ambiguity', 'ابهام'], ['synthesis', 'تلفیق'],
    ],
    c2: [
      ['ontology', 'هستی‌شناسی'], ['epistemic', 'معرفت‌شناختی'], ['dialectic', 'دیالکتیک'], ['genealogy', 'تبارشناسی'],
      ['normativity', 'هنجارمندی'], ['contingency', 'امکان‌مندی / وابستگی به شرایط'], ['recursive', 'بازگشتی'], ['underdetermination', 'نامتعینی'],
      ['legitimacy', 'مشروعیت'], ['universality', 'جهان‌شمولی'], ['hierarchy', 'سلسله‌مراتب'], ['counterfactual', 'خلاف‌واقع'],
      ['proposition', 'گزاره'], ['mechanism', 'سازوکار'], ['classification', 'طبقه‌بندی'], ['reformulation', 'بازصورت‌بندی'],
      ['plurality', 'کثرت'], ['paradigm', 'پارادایم'], ['discourse', 'گفتمان'], ['reflexivity', 'بازاندیشی'],
    ],
  };
  const isUpperAdvanced = ['c1', 'c2'].includes(lessonLevel);
  const upperLearningContent = currentLesson && ['b1', 'b2', 'c1', 'c2'].includes(lessonLevel) ? {
    grammar: {
      title: lessonLevel === 'b1' ? 'Developing ideas with reasons and contrasts' : lessonLevel === 'b2' ? 'Building nuanced arguments and conclusions' : lessonLevel === 'c1' ? 'Softening disagreement and managing tone' : 'Nuance, subtext and diplomatic emphasis',
      titleFa: lessonLevel === 'b1' ? 'گسترش نظر با دلیل و تضاد' : lessonLevel === 'b2' ? 'ساخت استدلال دقیق و نتیجه‌گیری' : lessonLevel === 'c1' ? 'ملایم‌کردن مخالفت و مدیریت لحن' : 'ظرافت معنایی، منظور پنهان و تأکید دیپلماتیک',
      formula: lessonLevel === 'b1' ? 'opinion + because / however / if + present, will + verb' : lessonLevel === 'b2' ? 'claim + evidence / although + contrast / is likely to + verb' : lessonLevel === 'c1' ? 'I can see your point, but... / I’d rather... / If I were..., I’d...' : 'What I mean is... / It’s not that..., it’s just that... / I wouldn’t go so far as to say...',
      explanation: lessonLevel === 'c1' ? 'Use softeners, conditionals and respectful contrast to be clear without sounding rude.' : lessonLevel === 'c2' ? 'Use reframing, hedging and emphasis to express subtle meaning and manage sensitive conversations.' : lessonLevel === 'b1' ? 'Connect an opinion to a reason, contrast or likely result.' : 'Qualify claims, compare viewpoints and support conclusions with evidence.',
      explanationFa: lessonLevel === 'b1'
        ? `در موضوع «${currentLesson.titleFa}» نظر را با because دلیل‌دار کنید، با however تضاد بسازید و برای نتیجهٔ محتمل از If + حال ساده، will + فعل استفاده کنید.`
        : lessonLevel === 'b2'
          ? `در موضوع «${currentLesson.titleFa}» ادعا را با شواهد پشتیبانی کنید؛ although برای تضاد، is likely to برای احتمال و taking all factors into account برای نتیجه‌گیری سنجیده به کار می‌رود.`
          : lessonLevel === 'c1'
            ? `در موضوع «${currentLesson.titleFa}» مخالفت را مستقیم اما مؤدبانه بیان می‌کنیم. I can see your point, but… ابتدا دیدگاه طرف مقابل را می‌پذیرد و سپس مخالفت را می‌آورد. I’d rather… ترجیح را بدون دستور دادن بیان می‌کند و If I were…, I’d… برای پیشنهاد محتاطانه و همدلانه است. لحن صدا و عبارت‌های نرم‌کننده‌ای مانند perhaps و a little نیز از تندشدن گفت‌وگو جلوگیری می‌کنند.`
            : `در موضوع «${currentLesson.titleFa}» هدف فقط استفاده از واژه‌های سخت نیست؛ باید منظور پنهان، میزان اطمینان و حساسیت موقعیت را منتقل کنیم. What I mean is… برای بازگویی روشن‌تر، It’s not that…, it’s just that… برای اصلاح برداشت، و I wouldn’t go so far as to say… برای مخالفت سنجیده به کار می‌روند. در C2 انتخاب لحن و مکث به‌اندازهٔ ساختار جمله مهم است.`,
      examples: currentLesson.sentences.map((sentence) => sentence.en),
      examplesFa: currentLesson.sentences.map((sentence) => sentence.fa),
    },
    vocabulary: isUpperAdvanced
      ? naturalAdvancedVocabulary[lessonLevel].map(([makeWord, makeMeaning], index) => ({
          word: makeWord(currentLesson.keyword),
          meaning: makeMeaning(currentLesson.keywordFa),
          phrase: currentLesson.sentences[index].en,
        }))
      : [
          { word: currentLesson.keyword, meaning: currentLesson.keywordFa, phrase: currentLesson.sentences[0].en },
          ...upperVocabulary[lessonLevel].slice(0, 9).map(([word, meaning], index) => ({ word, meaning, phrase: currentLesson.sentences[Math.min(index + 1, 9)].en })),
        ],
  } : null;
  const rawLearningContent = remoteContent[currentLesson?.id] || researchedContent[currentLesson?.id] || upperLearningContent || pilotLearningContent[currentLesson?.id] || extraLearningContent[currentLesson?.id] || completedLearningContent[currentLesson?.id] || lessonLearningContent[currentLesson?.id];
  const a1CoreMeanings = {
    hello: 'سلام', name: 'نام', friend: 'دوست', morning: 'صبح', evening: 'عصر', student: 'دانش‌آموز / دانشجو',
    birthday: 'تولد', month: 'ماه', year: 'سال', party: 'جشن', family: 'خانواده', mother: 'مادر', father: 'پدر',
    brother: 'برادر', sister: 'خواهر', grandparents: 'پدربزرگ و مادربزرگ', teacher: 'معلم',
    time: 'زمان / ساعت', today: 'امروز', tomorrow: 'فردا', Monday: 'دوشنبه', appointment: 'قرار ملاقات',
    color: 'رنگ', shirt: 'پیراهن', jacket: 'ژاکت', shoes: 'کفش', dress: 'پیراهن زنانه', pants: 'شلوار', size: 'اندازه',
    animal: 'حیوان', pet: 'حیوان خانگی', cat: 'گربه', dog: 'سگ', bird: 'پرنده', fish: 'ماهی', friendly: 'مهربان',
    home: 'خانه', kitchen: 'آشپزخانه', table: 'میز', sofa: 'مبل', bedroom: 'اتاق خواب', bathroom: 'حمام', towel: 'حوله', door: 'در',
    breakfast: 'صبحانه', dinner: 'شام', shower: 'دوش', work: 'کار', routine: 'برنامهٔ روزانه',
    coffee: 'قهوه', tea: 'چای', water: 'آب', milk: 'شیر', sugar: 'شکر', menu: 'منو', card: 'کارت', cup: 'فنجان',
    restaurant: 'رستوران', food: 'غذا', chicken: 'مرغ', rice: 'برنج', plate: 'بشقاب', bill: 'صورت‌حساب', spicy: 'تند', delicious: 'خوشمزه',
    shopping: 'خرید', price: 'قیمت', cash: 'پول نقد', receipt: 'رسید', bag: 'کیسه / کیف', fitting: 'پرو',
    address: 'آدرس', street: 'خیابان', bank: 'بانک', map: 'نقشه', left: 'چپ', right: 'راست', straight: 'مستقیم', station: 'ایستگاه',
    bus: 'اتوبوس', train: 'قطار', taxi: 'تاکسی', ticket: 'بلیت', stop: 'ایستگاه / توقف', transportation: 'حمل‌ونقل',
    weather: 'آب‌وهوا', sunny: 'آفتابی', warm: 'گرم', rain: 'باران', umbrella: 'چتر', winter: 'زمستان', spring: 'بهار', windy: 'بادی', cold: 'سرد',
    sport: 'ورزش', hobby: 'سرگرمی', reading: 'کتاب‌خوانی', football: 'فوتبال', music: 'موسیقی', drawing: 'نقاشی', swimming: 'شنا', tennis: 'تنیس',
    school: 'مدرسه', class: 'کلاس', office: 'دفتر', job: 'شغل', homework: 'تکلیف', gym: 'باشگاه', nurse: 'پرستار',
    health: 'سلامت', headache: 'سردرد', pharmacy: 'داروخانه', doctor: 'پزشک', stomach: 'شکم', ambulance: 'آمبولانس', help: 'کمک',
    bike: 'دوچرخه', photos: 'عکس‌ها', chess: 'شطرنج', books: 'کتاب‌ها', movies: 'فیلم‌ها',
    medicine: 'دارو', throat: 'گلو', hurt: 'درد داشتن', twice: 'دو بار',
    phone: 'تلفن', number: 'شماره', message: 'پیام', call: 'تماس', hear: 'شنیدن', later: 'بعداً', battery: 'باتری', signal: 'آنتن', text: 'پیامک فرستادن',
    airport: 'فرودگاه', passport: 'گذرنامه', flight: 'پرواز', gate: 'گیت', hotel: 'هتل', reservation: 'رزرو', room: 'اتاق', included: 'شامل', delayed: 'با تأخیر', checkout: 'تحویل اتاق',
    car: 'ماشین', engine: 'موتور', tire: 'لاستیک', repair: 'تعمیر', mechanic: 'مکانیک', noise: 'صدا', brake: 'ترمز', oil: 'روغن',
  };
  const a2GrammarExplanations = {
    a2routine: 'برای دعوت و هماهنگ‌کردن برنامه از Are you free…?، Would you like…? و زمان حال استمراری برای قرار قطعی آینده استفاده می‌کنیم.',
    a2past: 'برای رویدادهای تمام‌شدهٔ گذشته از گذشتهٔ ساده استفاده می‌کنیم. در سؤال‌ها Did می‌آید و فعل اصلی به شکل ساده برمی‌گردد.',
    a2future: 'برای تصمیم لحظه‌ای از will، برای قصد و برنامه از be going to و برای قرار قطعی از حال استمراری استفاده می‌کنیم.',
    a2preferences: 'برای بیان ترجیح از prefer A to B یا would rather + فعل ساده استفاده می‌کنیم و دلیل را با because می‌آوریم.',
    a2comparison: 'برای مقایسه به صفت‌های کوتاه ‎-er + than اضافه می‌کنیم؛ برای صفت‌های بلند از more + adjective + than استفاده می‌کنیم.',
    a2home: 'برای پرسیدن دربارهٔ امکانات خانه از Does…have…? و برای شرایط اجاره از Is/Are…included? استفاده می‌کنیم.',
    a2shopping: 'برای مرجوع‌کردن یا تعویض کالا، I’d like to return/exchange… مؤدبانه است و سپس دلیل مشکل را توضیح می‌دهیم.',
    a2restaurant: 'برای درخواست مؤدبانه در رستوران از Could we have…? و Could you…please? استفاده می‌کنیم.',
    a2health: 'برای مشکلی که در گذشته شروع شده و هنوز ادامه دارد از have/has had + symptom + for/since استفاده می‌کنیم.',
    a2work: 'برای سابقهٔ کاری تمام‌شده از گذشتهٔ ساده و برای تجربه‌ای که تا امروز اهمیت دارد از حال کامل استفاده می‌کنیم.',
    a2studies: 'برای فعالیت در حال انجام از حال استمراری و برای کاری که تا اکنون کامل شده از حال کامل استفاده می‌کنیم.',
    a2travel: 'برای تأخیر یا تغییری که نتیجه‌اش اکنون مهم است از حال کامل، مانند has been delayed، استفاده می‌کنیم.',
    a2hotel: 'برای درخواست مؤدبانه در هتل از Could I have…? یا Could you…? استفاده می‌کنیم.',
    a2directions: 'برای مسیر دادن از فعل امری مانند Go، Turn و Take و از نشانه‌های مسیر با after، across from و on the corner استفاده می‌کنیم.',
    a2messages: 'در تماس و ایمیل رسمی، Could you please…? برای درخواست و I am writing/calling to… برای بیان هدف پیام استفاده می‌شود.',
    a2weather: 'برای نتیجهٔ احتمالی آینده از شرطی نوع اول استفاده می‌کنیم: If + حال ساده، will + فعل ساده.',
    a2hobbies: 'برای تجربه‌های زندگی از Have you ever…? و برای فعالیت تازه از have/has recently + قسمت سوم فعل استفاده می‌کنیم.',
    a2repair: 'برای توضیح خرابی از is not working یا stopped working و برای درخواست بررسی از Could you take a look…? استفاده می‌کنیم.',
    a2opinions: 'برای نظر از I think/In my opinion، برای دلیل از because و برای مخالفت مؤدبانه از I’m not sure I agree استفاده می‌کنیم.',
    a2stories: 'برای تعریف داستان، رویدادها را با گذشتهٔ ساده و واژه‌های First، Then، Suddenly و Finally منظم می‌کنیم.',
  };
  const a2CoreMeanings = {
    invitation: 'دعوت', available: 'آزاد / در دسترس', arrange: 'هماهنگ کردن', instead: 'به‌جای آن', busy: 'مشغول', plans: 'برنامه‌ها',
    weekend: 'آخر هفته', visited: 'دیدار کرد', arrived: 'رسید', wonderful: 'فوق‌العاده', forgot: 'فراموش کرد', camera: 'دوربین',
    future: 'آینده', goal: 'هدف', save: 'پس‌انداز کردن', course: 'دوره', hope: 'امیدوار بودن', drive: 'رانندگی کردن',
    prefer: 'ترجیح دادن', dislike: 'دوست نداشتن', rather: 'ترجیحاً', crowded: 'شلوغ', interested: 'علاقه‌مند', quiet: 'آرام',
    safer: 'امن‌تر', cheaper: 'ارزان‌تر', convenient: 'مناسب', expensive: 'گران', faster: 'سریع‌تر', longer: 'طولانی‌تر',
    rent: 'اجاره', deposit: 'ودیعه', landlord: 'صاحب‌خانه', neighborhood: 'محله', bills: 'قبض‌ها', apartment: 'آپارتمان',
    return: 'پس دادن', exchange: 'تعویض کردن', refund: 'بازپرداخت پول', damaged: 'آسیب‌دیده', receipt: 'رسید', sleeve: 'آستین',
    reservation: 'رزرو', contain: 'شامل بودن', spicy: 'تند', separately: 'جداگانه', ordered: 'سفارش داد', bill: 'صورت‌حساب',
    appointment: 'نوبت', symptom: 'نشانهٔ بیماری', dizzy: 'دچار سرگیجه', medicine: 'دارو', cough: 'سرفه', throat: 'گلو',
    experience: 'سابقه / تجربه', skill: 'مهارت', responsible: 'مسئول', customer: 'مشتری', interview: 'مصاحبه', team: 'تیم',
    practice: 'تمرین کردن', improve: 'بهبود دادن', confidently: 'با اعتمادبه‌نفس', pronunciation: 'تلفظ', notes: 'یادداشت‌ها', homework: 'تکلیف',
    departure: 'حرکت / خروج', delay: 'تأخیر', traffic: 'ترافیک', airline: 'شرکت هواپیمایی', gate: 'گیت', ticket: 'بلیت',
    receptionist: 'مسئول پذیرش', checkout: 'تحویل اتاق', towel: 'حوله', passport: 'گذرنامه', served: 'سرو شد', conditioner: 'تهویه',
    landmark: 'نشانهٔ مسیر', corner: 'نبش', bridge: 'پل', square: 'میدان', pharmacy: 'داروخانه', museum: 'موزه',
    details: 'جزئیات', reply: 'پاسخ دادن', voicemail: 'پیام صوتی', confirm: 'تأیید کردن', received: 'دریافت کرد', email: 'ایمیل',
    forecast: 'پیش‌بینی هوا', temperature: 'دما', windy: 'بادی', clearing: 'در حال صاف‌شدن', picnic: 'پیک‌نیک', jacket: 'ژاکت',
    recently: 'اخیراً', photography: 'عکاسی', recommend: 'پیشنهاد کردن', club: 'باشگاه', guitar: 'گیتار', hobby: 'سرگرمی',
    technician: 'تعمیرکار / تکنسین', warranty: 'ضمانت', replace: 'تعویض کردن', estimate: 'برآورد هزینه', screen: 'صفحه‌نمایش', repair: 'تعمیر',
    opinion: 'نظر', agree: 'موافق بودن', advantage: 'مزیت', disadvantage: 'عیب', decide: 'تصمیم گرفتن', useful: 'مفید',
    suddenly: 'ناگهان', finally: 'سرانجام', while: 'درحالی‌که', market: 'بازار', noise: 'صدا', lovely: 'دل‌نشین',
  };

  const currentLearningContent = (() => {
    if (!rawLearningContent || !currentLesson) return rawLearningContent;
    if (lessonLevel === 'a2') {
      const originalExamples = rawLearningContent.grammar.examples || [];
      const originalTranslations = rawLearningContent.grammar.examplesFa || [];
      const grammarPairs = originalExamples.map((example, index) => ({
        en: example,
        fa: currentLesson.sentences.find((sentence) => sentence.en === example)?.fa || originalTranslations[index],
      })).filter((pair) => pair.en && pair.fa);
      currentLesson.sentences.forEach((sentence) => {
        if (grammarPairs.length < 10 && !grammarPairs.some((pair) => pair.en === sentence.en)) {
          grammarPairs.push({ en: sentence.en, fa: sentence.fa });
        }
      });
      const vocabulary = [...(rawLearningContent.vocabulary || [])];
      const knownWords = new Set(vocabulary.map((item) => normalizeWord(item.word)));
      currentLesson.sentences.forEach((sentence) => {
        sentence.en.match(/[A-Za-z]+(?:['’][A-Za-z]+)?/g)?.forEach((word) => {
          const normalized = normalizeWord(word);
          const meaning = wordMeanings[normalized] || a2CoreMeanings[normalized];
          if (vocabulary.length < 10 && meaning && !knownWords.has(normalized)) {
            vocabulary.push({ word, meaning, phrase: sentence.en });
            knownWords.add(normalized);
          }
        });
      });
      return {
        ...rawLearningContent,
        grammar: {
          ...rawLearningContent.grammar,
          explanationFa: a2GrammarExplanations[currentLesson.id] || rawLearningContent.grammar.explanationFa,
          examples: grammarPairs.map((pair) => pair.en),
          examplesFa: grammarPairs.map((pair) => pair.fa),
        },
        vocabulary,
      };
    }
    if (lessonLevel !== 'a1') return rawLearningContent;

    const originalExamples = rawLearningContent.grammar.examples || [];
    const originalTranslations = rawLearningContent.grammar.examplesFa || [];
    const grammarPairs = originalExamples.map((example, index) => ({
      en: example,
      fa: currentLesson.sentences.find((sentence) => sentence.en === example)?.fa || originalTranslations[index],
    })).filter((pair) => pair.fa);
    const targetExampleCount = expandedA1Sentences[currentLesson.id] ? 10 : 8;
    currentLesson.sentences.forEach((sentence) => {
      if (grammarPairs.length < targetExampleCount && !grammarPairs.some((pair) => pair.en === sentence.en)) {
        grammarPairs.push({ en: sentence.en, fa: sentence.fa });
      }
    });
    const grammarExamples = grammarPairs.map((pair) => pair.en);
    const grammarTranslations = grammarPairs.map((pair) => pair.fa);

    const vocabulary = [...(rawLearningContent.vocabulary || [])];
    const knownWords = new Set(vocabulary.map((item) => normalizeWord(item.word)));
    currentLesson.sentences.forEach((sentence) => {
      sentence.en.match(/[A-Za-z]+(?:['’][A-Za-z]+)?/g)?.forEach((word) => {
        const normalized = normalizeWord(word);
        const meaning = wordMeanings[normalized] || a1CoreMeanings[normalized] || a1CoreMeanings[word];
        const targetVocabularyCount = expandedA1Sentences[currentLesson.id] ? 10 : 8;
        if (vocabulary.length < targetVocabularyCount && meaning && !knownWords.has(normalized)) {
          vocabulary.push({ word, meaning, phrase: sentence.en });
          knownWords.add(normalized);
        }
      });
    });

    return {
      ...rawLearningContent,
      grammar: { ...rawLearningContent.grammar, examples: grammarExamples, examplesFa: grammarTranslations },
      vocabulary,
    };
  })();
  const generatedA2Extras = lessonLevel === 'a2' && currentLesson ? {
    notes: [
      a2GrammarExplanations[currentLesson.id],
      'به ترجمهٔ فارسی هر جمله توجه کنید، سپس با دکمهٔ صدا جملهٔ انگلیسی را گوش دهید و تکرار کنید.',
    ].filter(Boolean),
    dialogue: currentLesson.sentences.slice(0, 6).map((sentence, index) => ({
      speaker: index % 2 === 0 ? 'A' : 'B',
      en: sentence.en,
      fa: sentence.fa,
    })),
  } : null;
  const generatedUpperExtras = ['b1', 'b2', 'c1', 'c2'].includes(lessonLevel) && currentLesson ? {
    notes: [
      upperLearningContent.grammar.explanationFa,
      'ابتدا ترجمه را بخوانید، سپس صدای جملهٔ انگلیسی را گوش دهید و همان جمله را با صدای بلند تکرار کنید.',
    ],
    dialogue: currentLesson.sentences.slice(0, isUpperAdvanced ? 10 : 6).map((sentence, index) => ({
      speaker: index % 2 === 0 ? 'A' : 'B', en: sentence.en, fa: sentence.fa,
    })),
  } : null;
  const currentExtras = generatedA2Extras || generatedUpperExtras || pilotExtras[currentLesson?.id] || lessonExtras[currentLesson?.id];

  const selectedDifficulty = levels[currentSentence?.id];
  const isSaved = saved.includes(currentSentence?.id);

  const allLessons = [
    ...Object.values(lessonGroups).flat(),
  ];

  const allSentences = allLessons.flatMap((lesson) => lesson.sentences);

  const reviewLesson = allLessons.find((lesson) => lesson.id === reviewLessonId);
  const reviewSentence = reviewLesson?.sentences[reviewSentenceIndex];

  const savedSentences = allSentences.filter((sentence) =>
    saved.includes(sentence.id)
  );

const easySaved = savedSentences.filter(
  (sentence) => levels[sentence.id] === 'Easy'
);

const mediumSaved = savedSentences.filter(
  (sentence) => levels[sentence.id] === 'Medium'
);

const hardSaved = savedSentences.filter(
  (sentence) => levels[sentence.id] === 'Hard'
);

  const chooseDifficulty = (difficulty) => {
    setLevels({
      ...levels,
      [currentSentence.id]: difficulty,
    });
  };

  const saveSentence = () => {
    if (!isSaved) {
      setSaved([...saved, currentSentence.id]);
    }
  };

const removeSavedSentence = (id) => {
  setSaved(saved.filter((savedId) => savedId !== id));
};

  const speakEnglish = async (text) => {
    try {
      await Speech.stop();
      Speech.speak(text, { language: 'en-US', rate: 0.85 });
    } catch (error) {
      Alert.alert('Audio unavailable', 'Please check that your device has an English voice installed.');
    }
  };

  const saveSelectedWord = () => {
    if (!selectedWord) return;
    const wordId = `word-${currentSentence.id}-${normalizeWord(selectedWord)}`;
    if (customItems.some((item) => item.id === wordId)) {
      setCustomItems((items) => items.map((item) => item.id === wordId
        ? { ...item, difficulty: wordDifficulty }
        : item));
      return;
    }
    setCustomItems((items) => [{
      id: wordId,
      type: 'Word',
      en: selectedWord,
      fa: wordMeanings[normalizeWord(selectedWord)],
      difficulty: wordDifficulty,
      createdAt: new Date().toISOString(),
    }, ...items]);
  };

  const saveVocabularyWord = (item, difficulty) => {
    const wordId = `vocab-${currentLesson.id}-${normalizeWord(item.word)}`;
    const savedWord = {
      id: wordId,
      type: 'Word',
      en: item.word,
      fa: item.meaning,
      phrase: item.phrase,
      difficulty,
      lessonId: currentLesson.id,
      createdAt: new Date().toISOString(),
    };
    setCustomItems((items) => items.some((savedItem) => savedItem.id === wordId)
      ? items.map((savedItem) => savedItem.id === wordId ? { ...savedItem, ...savedWord } : savedItem)
      : [savedWord, ...items]);
  };

  const sendConversationMessage = () => {
    const message = conversationInput.trim();
    if (!message) return;

    const learnedItems = [
      ...customItems,
      ...savedSentences,
    ].filter((item) => item?.en || item?.english);
    const practicePhrase = learnedItems[0]?.en || learnedItems[0]?.english;
    const lowerMessage = message.toLowerCase();

    let reply = 'That is a good answer! Can you tell me a little more?';
    let translation = 'پاسخ خوبی بود! می‌توانی کمی بیشتر توضیح بدهی؟';

    if (/hello|hi|hey/.test(lowerMessage)) {
      reply = 'Hello! Nice to meet you. What did you do today?';
      translation = 'سلام! از آشنایی با تو خوشحالم. امروز چه کار کردی؟';
    } else if (/fine|good|great|happy/.test(lowerMessage)) {
      reply = 'I am glad to hear that! What made your day good?';
      translation = 'خوشحالم که این را می‌شنوم! چه چیزی روزت را خوب کرد؟';
    } else if (/coffee|cappuccino|tea/.test(lowerMessage)) {
      reply = 'Great! How would you order it politely in a coffee shop?';
      translation = 'عالی! چطور آن را مؤدبانه در کافی‌شاپ سفارش می‌دهی؟';
    } else if (/because/.test(lowerMessage)) {
      reply = 'Excellent use of “because”! Now ask me one question.';
      translation = 'استفاده‌ات از «because» عالی بود! حالا یک سؤال از من بپرس.';
    } else if (practicePhrase) {
      reply = `Nice! Try to use this saved English in your next answer: “${practicePhrase}”`;
      translation = 'عالی! سعی کن عبارت ذخیره‌شده بالا را در پاسخ بعدی استفاده کنی.';
    }

    setConversationMessages((messages) => [
      ...messages,
      { id: `user-${Date.now()}`, role: 'user', text: message },
      {
        id: `coach-${Date.now() + 1}`,
        role: 'coach',
        text: reply,
        translation,
      },
    ]);
    setConversationInput('');
  };

  const addCustomItem = () => {
    const english = customEnglish.trim();
    const persian = customPersian.trim();

    if (!english || !persian) {
      Alert.alert('Missing information', 'Please enter both English and Persian.');
      return;
    }

    setCustomItems([
      {
        id: `custom-${Date.now()}`,
        type: customType,
        en: english,
        fa: persian,
        difficulty: customDifficulty,
        createdAt: new Date().toISOString(),
      },
      ...customItems,
    ]);
    setCustomEnglish('');
    setCustomPersian('');
    setCustomDifficulty('Easy');
  };

  const removeCustomItem = (id) => {
    setCustomItems(customItems.filter((item) => item.id !== id));
  };

  const openLesson = (level, lessonIndex) => {
    setLessonLevel(level);
    setSelectedLessonIndex(lessonIndex);
    setSentenceIndex(0);
    setLessonSection('grammar');
    setLessonSectionHistory([]);
    setSelectedWord(null);
    setScreen('lesson');
  };

  const goToLessonSection = (nextSection) => {
    if (nextSection === lessonSection) return;
    setLessonSectionHistory((history) => [...history, lessonSection]);
    setLessonSection(nextSection);
    setSelectedWord(null);
  };

  const goBackInLesson = () => {
    if (lessonSection === 'examples' && sentenceIndex > 0) {
      setSentenceIndex((index) => index - 1);
      setSelectedWord(null);
      return;
    }
    if (lessonSectionHistory.length) {
      setLessonSection(lessonSectionHistory[lessonSectionHistory.length - 1]);
      setLessonSectionHistory((history) => history.slice(0, -1));
      setSelectedWord(null);
    } else {
      setScreen('lessons');
    }
  };

  const nextSentence = () => {
    setSelectedWord(null);
    if (sentenceIndex < currentLesson.sentences.length - 1) {
      setSentenceIndex(sentenceIndex + 1);
    } else {
      if (!completedLessons.includes(currentLesson.id)) {
        setCompletedLessons([...completedLessons, currentLesson.id]);
      }
      setReviewSchedules((currentSchedules) => {
        if (currentSchedules[currentLesson.id]) return currentSchedules;

        return {
          ...currentSchedules,
          [currentLesson.id]: {
            startedAt: new Date().toISOString(),
            completedIntervals: [],
          },
        };
      });
      setScreen('lessons');
      setSentenceIndex(0);
      const nextLesson = lessons[selectedLessonIndex + 1];
      setLastLessonPosition(nextLesson
        ? { level: lessonLevel, lessonId: nextLesson.id, section: 'grammar', sentenceIndex: 0 }
        : null);
    }
  };

  const addDays = (dateValue, days) => {
    const date = new Date(dateValue);
    date.setDate(date.getDate() + days);
    return date;
  };

  const formatReviewDate = (date) =>
    date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });

  const getReviewInfo = (lessonId) => {
    const schedule = reviewSchedules[lessonId];
    const completedIntervals = schedule?.completedIntervals || [];
    const interval = reviewIntervals.find(
      (days) => !completedIntervals.includes(days)
    );

    if (!schedule || interval === undefined) {
      return { finished: true, isDue: false, interval: null, dueDate: null };
    }

    const dueDate = addDays(schedule.startedAt, interval);

    return {
      finished: false,
      isDue: new Date() >= dueDate,
      interval,
      dueDate,
    };
  };

  const reviewItems = Object.keys(reviewSchedules)
    .map((lessonId) => ({
      lesson: allLessons.find((lesson) => lesson.id === lessonId),
      info: getReviewInfo(lessonId),
    }))
    .filter((item) => item.lesson)
    .sort((a, b) => {
      if (a.info.finished) return 1;
      if (b.info.finished) return -1;
      return a.info.dueDate - b.info.dueDate;
    });

  const startReview = (lessonId) => {
    setReviewLessonId(lessonId);
    setReviewSentenceIndex(0);
    setScreen('review');
  };

  const addCustomReviewDay = () => {
    const day = Number.parseInt(customReviewDay, 10);

    if (!Number.isInteger(day) || day < 1) {
      Alert.alert(
        'Invalid day',
        'Please enter a whole number greater than zero.'
      );
      return;
    }

    if (reviewIntervals.includes(day)) {
      Alert.alert('Already added', `${day} days is already in your schedule.`);
      return;
    }

    setReviewIntervals([...reviewIntervals, day].sort((a, b) => a - b));
    setCustomReviewDay('');
  };

  const removeReviewDay = (day) => {
    const wasCompleted = Object.values(reviewSchedules).some((schedule) =>
      schedule.completedIntervals?.includes(day)
    );

    if (wasCompleted) {
      Alert.alert(
        'Completed review',
        'This day is locked because a review was already completed.'
      );
      return;
    }

    setReviewIntervals(reviewIntervals.filter((item) => item !== day));
  };

  const nextReviewSentence = () => {
    if (reviewSentenceIndex < reviewLesson.sentences.length - 1) {
      setReviewSentenceIndex(reviewSentenceIndex + 1);
      return;
    }

    const info = getReviewInfo(reviewLessonId);
    if (info.isDue && !info.finished) {
      setReviewSchedules((currentSchedules) => ({
        ...currentSchedules,
        [reviewLessonId]: {
          ...currentSchedules[reviewLessonId],
          completedIntervals: [
            ...currentSchedules[reviewLessonId].completedIntervals,
            info.interval,
          ],
        },
      }));
    }

    setReviewSentenceIndex(0);
    setScreen('progress');
  };

  const practicedCount = Object.keys(levels).length;

  const getProgressCount = (lesson) =>
    lesson.sentences.filter((sentence) => levels[sentence.id]).length;

  const levelNames = { a1: 'A1 · Beginner', a2: 'A2 · Beginner', b1: 'B1 · Intermediate', b2: 'B2 · Intermediate', c1: 'C1 · Advanced', c2: 'C2 · Advanced' };
  // Every curriculum position is visible; a topic without a lesson stays disabled.
  const a1Curriculum = [
    ['Greetings, How Are You? & Introductions 👋', 'سلام، احوال‌پرسی و معرفی خود', 'intro1'],
    ['Name, Age & Where You Live', 'نام، سن، محل تولد و زندگی', 'birthday1'],
    ['Birthdays, Numbers & Time', 'تاریخ تولد، اعداد و ساعت', 'a1numbers'],
    ['Family & Friends', 'خانواده و دوستان', 'a1family'],
    ['Colors, Clothes & Sizes 🎨', 'رنگ‌ها، لباس و اندازه', 'colors1'],
    ['Animals & Pets 🐾', 'حیوانات و حیوان خانگی', 'animals1'],
    ['Home & Household Items', 'خانه و وسایل', 'a1house'],
    ['Daily Routines 🏠', 'کارهای روزانه', 'b3'],
    ['Food & Drinks ☕', 'غذا و نوشیدنی', 'b1'],
    ['Restaurants & Cafés 🍴', 'رستوران و کافه', 'b5'],
    ['Shopping & Prices 🛍️', 'خرید و قیمت', 'b4'],
    ['Asking for Directions 📍', 'آدرس پرسیدن و مسیر دادن', 'directions1'],
    ['Transportation', 'حمل‌ونقل', 'a1transport'],
    ['Weather', 'آب‌وهوا', 'a1weather'],
    ['Sports & Hobbies', 'ورزش و سرگرمی', 'a1hobbies'],
    ['School & Work 🏫', 'تحصیلات و شغل', 'school1'],
    ['Health & Asking for Help', 'سلامت و درخواست کمک', 'a1health'],
    ['Phone & Messages', 'تلفن و پیام', 'a1phone'],
    ['Airport & Hotel', 'فرودگاه و هتل', 'a1travel'],
    ['Cars & Repairs 🚗', 'ماشین و تعمیرگاه', 'mechanic1'],
  ];
  const lessonTranslations = {
    "Last Weekend & Past Events": "آخر هفتهٔ گذشته و رویدادها",
    "Future Plans & Goals": "برنامه‌ها و هدف‌های آینده",
    "Likes, Dislikes & Preferences": "علاقه‌ها و ترجیح‌ها",
    "Comparing People & Places": "مقایسهٔ افراد و مکان‌ها",
    "Renting a Room": "اجارهٔ اتاق",
    "Returns & Exchanges": "مرجوع‌کردن و تعویض کالا",
    "Restaurant Requests & Problems": "درخواست‌ها و مشکلات رستوران",
    "Symptoms & Doctor Appointments": "نشانه‌های بیماری و نوبت پزشک",
    "Job Interviews & Experience": "مصاحبهٔ شغلی و سابقهٔ کار",
    "Classes & Learning Goals": "کلاس‌ها و هدف‌های یادگیری",
    "Travel Arrangements & Delays": "برنامهٔ سفر و تأخیرها",
    "Hotel Check-in & Requests": "پذیرش هتل و درخواست‌ها",
    "Giving Detailed Directions": "مسیر دادن با جزئیات",
    "Emails & Phone Conversations": "ایمیل و گفت‌وگوی تلفنی",
    "Weather & Changing Plans": "آب‌وهوا و تغییر برنامه",
    "Hobbies & Recent Experiences": "سرگرمی‌ها و تجربه‌های اخیر",
    "Repairs & Services": "تعمیرات و خدمات",
    "Opinions & Reasons": "نظرها و دلیل‌ها",
    "Telling a Short Story": "تعریف یک داستان کوتاه",

    'Daily Plans & Invitations 📅': 'برنامه‌های روزانه و دعوت',
    'At the Airport ✈️': 'در فرودگاه',
    'Solving a Travel Problem 🧳': 'حل مشکل سفر',
    'At Work 💼': 'در محل کار',
    'Making Plans 📅': 'برنامه‌ریزی',
    'Comparing Repair Options 🔧': 'مقایسهٔ راه‌های تعمیر',
    'Doctor Visit 🩺': 'مراجعه به پزشک',
    'Presenting a Proposal 📊': 'ارائهٔ پیشنهاد',
    'Giving Opinions 💬': 'بیان نظر',
    'Professional English 🎯': 'انگلیسی حرفه‌ای',
    'Nuanced Debate 🧠': 'مناظرهٔ دقیق',
    'Discussion & Debate 🧠': 'گفت‌وگو و مناظره',
  };
  const lessonSlots = lessonLevel === 'a1'
    ? a1Curriculum.map(([english, persian, id]) => ({
        english,
        persian,
        lesson: lessonGroups.a1.find((item) => item.id === id),
      }))
    : lessonGroups[lessonLevel].map((lesson) => ({
        english: lesson.title,
        persian: lesson.titleFa || lessonTranslations[lesson.title] || '',
        lesson,
      }));

  const LevelTabs = () => (
    <View style={styles.cefrGrid}>
      {Object.keys(levelNames).map((level) => (
        <TouchableOpacity key={level} style={[styles.cefrTile, lessonLevel === level && styles.cefrTileActive]}
          onPress={() => { setLessonLevel(level); setScreen('lessons'); }}>
          <Text style={styles.cefrCode}>{level.toUpperCase()}</Text>
          <Text style={styles.cefrLabel}>{levelNames[level].split(' · ')[1]}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );

  const BottomNav = () => (
    <View style={styles.bottomNav}>
      <TouchableOpacity onPress={() => setScreen('home')}>
        <Text style={screen === 'home' ? styles.navActive : styles.navText}>
          🏠
        </Text>
        <Text style={screen === 'home' ? styles.navActiveLabel : styles.navLabel}>
          Home
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => setScreen('lessons')}>
        <Text style={screen === 'lessons' ? styles.navActive : styles.navText}>
          📖
        </Text>
        <Text
          style={screen === 'lessons' ? styles.navActiveLabel : styles.navLabel}
        >
          Lessons
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => setScreen('saved')}>
        <Text style={screen === 'saved' ? styles.navActive : styles.navText}>
          ♡
        </Text>
        <Text style={screen === 'saved' ? styles.navActiveLabel : styles.navLabel}>
          Saved
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => setScreen('progress')}>
        <Text style={screen === 'progress' ? styles.navActive : styles.navText}>
          ▥
        </Text>
        <Text
          style={screen === 'progress' ? styles.navActiveLabel : styles.navLabel}
        >
          Progress
        </Text>
      </TouchableOpacity>
    </View>
  );

  if (screen === 'lesson') {
    return (
      <SafeAreaView style={styles.page}>
        <ScrollView contentContainerStyle={styles.container}>
          <TouchableOpacity onPress={() => setScreen('lessons')}>
            <Text style={styles.backText}>← Lessons</Text>
          </TouchableOpacity>

          <Text style={styles.lessonNumber}>
            LESSON {selectedLessonIndex + 1}
          </Text>

          <Text style={styles.lessonTitle}>{currentLesson.title}</Text>

          <View style={styles.lessonSectionTabs}>
            {[
              { id: 'grammar', label: '1. Grammar', icon: '📘' },
              { id: 'vocabulary', label: '2. Vocabulary', icon: '🔤' },
              { id: 'examples', label: '3. Examples', icon: '💬' },
              { id: 'dialogue', label: '4. Dialogue', icon: '🗣️' },
            ].map((section) => (
              <TouchableOpacity
                key={section.id}
                style={[
                  styles.lessonSectionTab,
                  lessonSection === section.id && styles.lessonSectionTabActive,
                ]}
                onPress={() => goToLessonSection(section.id)}
              >
                <Text style={styles.lessonSectionIcon}>{section.icon}</Text>
                <Text
                  style={[
                    styles.lessonSectionTabText,
                    lessonSection === section.id && styles.lessonSectionTabTextActive,
                  ]}
                >
                  {section.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {lessonSection === 'grammar' && currentLearningContent && (
            <View style={styles.learningCard}>
              <Text style={styles.learningEyebrow}>GRAMMAR</Text>
              <Text style={styles.learningTitle}>{currentLearningContent.grammar.title}</Text>
              <Text style={styles.learningPersian}>{currentLearningContent.grammar.titleFa}</Text>

              <View style={styles.formulaBox}>
                <Text style={styles.formulaLabel}>FORMULA</Text>
                <Text style={styles.formulaText}>{currentLearningContent.grammar.formula}</Text>
                {currentLearningContent.grammar.formulaFa && (
                  <Text style={styles.formulaPersian}>{currentLearningContent.grammar.formulaFa}</Text>
                )}
              </View>

              <Text style={styles.learningExplanation}>{currentLearningContent.grammar.explanation}</Text>
              <Text style={styles.learningExplanationFa}>{currentLearningContent.grammar.explanationFa}</Text>

              <Text style={styles.miniSectionTitle}>Examples</Text>
              {currentLearningContent.grammar.examples.map((example, index) => (
                <View key={`${currentLesson.id}-grammar-${index}`} style={styles.grammarExampleRow}>
                  <View style={styles.grammarExampleContent}>
                    <Text style={styles.grammarExampleText}>{example}</Text>
                    {currentLearningContent.grammar.examplesFa?.[index] && (
                      <Text style={styles.grammarExamplePersian}>{currentLearningContent.grammar.examplesFa[index]}</Text>
                    )}
                  </View>
                  <TouchableOpacity onPress={() => speakEnglish(example)} style={styles.smallSpeechButton}>
                    <Text style={styles.smallSpeechButtonText}>🔊</Text>
                  </TouchableOpacity>
                </View>
              ))}

              {currentExtras?.notes?.length > 0 && (
                <View style={styles.tipsBox}>
                  <Text style={styles.miniSectionTitle}>نکته‌های ساده برای زبان‌آموز</Text>
                  {currentExtras.notes.map((note, index) => (
                    <Text key={`${currentLesson.id}-tip-${index}`} style={styles.tipText}>• {note}</Text>
                  ))}
                </View>
              )}
              <View style={styles.lessonNavigationRow}>
                <TouchableOpacity style={[styles.nextButton, styles.lessonBackButton]} onPress={goBackInLesson}>
                  <Text style={styles.lessonBackText}>← Back</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.nextButton, styles.lessonForwardButton]} onPress={() => goToLessonSection('vocabulary')}>
                  <Text style={styles.nextText}>Next: Vocabulary →</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {lessonSection === 'vocabulary' && currentLearningContent && (
            <View style={styles.learningCard}>
              <Text style={styles.learningEyebrow}>VOCABULARY</Text>
              <Text style={styles.learningTitle}>Words & useful phrases</Text>
              <Text style={styles.learningPersian}>لغات و عبارت‌های کاربردی این درس</Text>

              {currentLearningContent.vocabulary.map((item, index) => (
                <View key={`${currentLesson.id}-vocab-${index}`} style={styles.vocabularyCard}>
                  <View style={styles.vocabularyHeader}>
                    <View style={styles.vocabularyTextArea}>
                      <Text style={styles.vocabularyWord}>{item.word}</Text>
                      <Text style={styles.vocabularyMeaning}>{item.meaning}</Text>
                    </View>
                    <TouchableOpacity onPress={() => speakEnglish(item.word)} style={styles.smallSpeechButton}>
                      <Text style={styles.smallSpeechButtonText}>🔊</Text>
                    </TouchableOpacity>
                  </View>
                  <TouchableOpacity onPress={() => speakEnglish(item.phrase)}>
                    <Text style={styles.vocabularyPhrase}>🔊 {item.phrase}</Text>
                  </TouchableOpacity>
                  <Text style={styles.vocabularySaveLabel}>Save this word:</Text>
                  <View style={styles.difficultyRow}>
                    {['Easy', 'Medium', 'Hard'].map((difficulty) => {
                      const wordId = `vocab-${currentLesson.id}-${normalizeWord(item.word)}`;
                      const savedDifficulty = customItems.find((savedItem) => savedItem.id === wordId)?.difficulty;
                      return (
                        <TouchableOpacity
                          key={`${wordId}-${difficulty}`}
                          style={[
                            styles.wordDifficultyButton,
                            savedDifficulty === difficulty && styles.wordDifficultySelected,
                          ]}
                          onPress={() => saveVocabularyWord(item, difficulty)}
                        >
                          <Text style={styles.difficultyText}>
                            {savedDifficulty === difficulty ? '♥ ' : '♡ '}{difficulty}
                          </Text>
                        </TouchableOpacity>
                      );
                    })}
                  </View>
                </View>
              ))}

              <View style={styles.lessonNavigationRow}>
                <TouchableOpacity style={[styles.nextButton, styles.lessonBackButton]} onPress={goBackInLesson}>
                  <Text style={styles.lessonBackText}>← Back</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.nextButton, styles.lessonForwardButton]} onPress={() => goToLessonSection(currentExtras ? 'dialogue' : 'examples')}>
                  <Text style={styles.nextText}>{currentExtras ? 'Next: Short Dialogue →' : 'Next: Examples & Sentence Building →'}</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {lessonSection === 'dialogue' && currentExtras && (
            <View style={styles.learningCard}>
              <Text style={styles.learningEyebrow}>SHORT DIALOGUE</Text>
              <Text style={styles.learningTitle}>گفت‌وگوی کوتاه</Text>
              {currentExtras.dialogue.map((turn, index) => (
                <View key={`${currentLesson.id}-turn-${index}`} style={styles.dialogueTurn}>
                  <Text style={styles.dialogueSpeaker}>{turn.speaker}</Text>
                  <Text style={styles.grammarExampleText}>{turn.en}</Text>
                  <Text style={styles.learningPersian}>{turn.fa}</Text>
                  <TouchableOpacity onPress={() => speakEnglish(turn.en)} style={styles.smallSpeechButton}>
                    <Text style={styles.smallSpeechButtonText}>🔊</Text>
                  </TouchableOpacity>
                </View>
              ))}
              <View style={styles.lessonNavigationRow}>
                <TouchableOpacity style={[styles.nextButton, styles.lessonBackButton]} onPress={goBackInLesson}>
                  <Text style={styles.lessonBackText}>← Back</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.nextButton, styles.lessonForwardButton]} onPress={() => goToLessonSection('examples')}>
                  <Text style={styles.nextText}>Next: Practice Sentences →</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
          {lessonSection === 'examples' && (
          <>
          <Text style={styles.counter}>
            {sentenceIndex + 1} / {currentLesson.sentences.length}
          </Text>

          <View style={styles.sentenceCard}>
            <Text style={styles.english}>
              {currentSentence.en.split(/([A-Za-z]+(?:['’][A-Za-z]+)?)/g).map((part, index) =>
                /^[A-Za-z]+(?:['’][A-Za-z]+)?$/.test(part) && wordMeanings[normalizeWord(part)]
                  ? <Text
                      key={`${currentSentence.id}-${index}`}
                      onPress={() => {
                        setSelectedWord(part);
                        const wordId = `word-${currentSentence.id}-${normalizeWord(part)}`;
                        setWordDifficulty(customItems.find((item) => item.id === wordId)?.difficulty || 'Easy');
                      }}
                      style={selectedWord === part ? styles.selectedWordText : styles.tappableWordText}
                    >{part}</Text>
                  : part
              )}
            </Text>
            <Text style={styles.persian}>{currentSentence.fa}</Text>
            <TouchableOpacity onPress={() => speakEnglish(currentSentence.en)} style={styles.speechButton}>
              <Text style={styles.speechButtonText}>🔊 Listen to the sentence</Text>
            </TouchableOpacity>
          </View>

          {selectedWord && (
            <View style={styles.wordSelectionCard}>
              <Text style={styles.wordSelectionTitle}>{selectedWord} — {wordMeanings[normalizeWord(selectedWord)]}</Text>
              <TouchableOpacity onPress={() => speakEnglish(selectedWord)} style={styles.speechButton}>
                <Text style={styles.speechButtonText}>🔊 Listen to the word</Text>
              </TouchableOpacity>
              <View style={styles.difficultyRow}>
                {['Easy', 'Medium', 'Hard'].map((difficulty) => (
                  <TouchableOpacity key={difficulty}
                    style={[styles.wordDifficultyButton, wordDifficulty === difficulty && styles.wordDifficultySelected]}
                    onPress={() => setWordDifficulty(difficulty)}>
                    <Text style={styles.difficultyText}>{difficulty}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              <TouchableOpacity onPress={saveSelectedWord} style={styles.speechButton}>
                <Text style={styles.speechButtonText}>
                  {customItems.some((item) => item.id === `word-${currentSentence.id}-${normalizeWord(selectedWord)}`)
                    ? '♥ Saved — update difficulty' : '♡ Save this word'}
                </Text>
              </TouchableOpacity>
            </View>
          )}

          <Text style={styles.question}>How difficult was it?</Text>

          <View style={styles.difficultyRow}>
            <TouchableOpacity
              style={[
                styles.difficultyButton,
                styles.easyButton,
                selectedDifficulty === 'Easy' && styles.easySelected,
              ]}
              onPress={() => chooseDifficulty('Easy')}
            >
              <Text style={styles.difficultyText}>Easy</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.difficultyButton,
                styles.mediumButton,
                selectedDifficulty === 'Medium' && styles.mediumSelected,
              ]}
              onPress={() => chooseDifficulty('Medium')}
            >
              <Text style={styles.difficultyText}>Medium</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.difficultyButton,
                styles.hardButton,
                selectedDifficulty === 'Hard' && styles.hardSelected,
              ]}
              onPress={() => chooseDifficulty('Hard')}
            >
              <Text style={styles.difficultyText}>Hard</Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            style={styles.saveButton}
            onPress={saveSentence}
          >
            <Text style={styles.saveText}>
              {isSaved ? '♥ Saved' : '♡ Save Sentence'}
            </Text>
          </TouchableOpacity>

          <View style={styles.lessonNavigationRow}>
            <TouchableOpacity style={[styles.nextButton, styles.lessonBackButton]} onPress={goBackInLesson}>
              <Text style={styles.lessonBackText}>← Back</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.nextButton, styles.lessonForwardButton]} onPress={nextSentence}>
              <Text style={styles.nextText}>
                {sentenceIndex === currentLesson.sentences.length - 1 ? 'Finish Lesson ✓' : 'Next →'}
              </Text>
            </TouchableOpacity>
          </View>
          </>
          )}
        </ScrollView>
      </SafeAreaView>
    );
  }

  if (screen === 'lessons') {
    return (
      <SafeAreaView style={styles.page}>
        <ScrollView contentContainerStyle={styles.container}>
          <View style={styles.logoRow}>
            <Text style={styles.logoLingo}>Lingo</Text>
            <Text style={styles.logoLoop}>Loop.</Text>
          </View>

          <Text style={styles.tagline}>Learn. Practice. Repeat.</Text>

          <Text style={styles.pageTitle}>Lessons</Text>
          <Text style={styles.pageSubtitle}>
            Choose a level and start learning.
          </Text>

          <LevelTabs />

          <Text style={styles.sectionTitle}>
            {levelNames[lessonLevel]} · Lessons
          </Text>

          {lessonSlots.map(({ english, persian, lesson }, index) => {
            const progress = lesson ? getProgressCount(lesson) : 0;
            const lessonIndex = lesson
              ? lessonGroups[lessonLevel].findIndex((item) => item.id === lesson.id)
              : -1;

            return (
              <TouchableOpacity
                key={`${lessonLevel}-slot-${index}`}
                style={[styles.lessonListCard, !lesson && { opacity: 0.6 }]}
                disabled={!lesson}
                onPress={() => openLesson(lessonLevel, lessonIndex)}
              >
                <View style={styles.lessonListContent}>
                  <Text style={styles.lessonListNumber}>Lesson {index + 1}</Text>
                  <Text style={styles.lessonListTitle}>{english}</Text>
                  <Text style={styles.lessonListDescription}>{persian}</Text>
                  <Text style={styles.lessonListDescription}>
                    {lesson ? lesson.description : 'در دست ساخت'}
                  </Text>
                </View>
                {lesson ? (
                  <View style={styles.progressCircle}>
                    <Text style={styles.progressCircleText}>
                      {progress}/{lesson.sentences.length}
                    </Text>
                  </View>
                ) : null}
                {lesson ? <Text style={styles.arrow}>›</Text> : null}
              </TouchableOpacity>
            );
          })}

          <Text style={styles.sectionTitle}>فهرست درس‌های این سطح</Text>
          {lessonSlots.map(({ english, persian, lesson }, index) => {
            const lessonIndex = lesson
              ? lessonGroups[lessonLevel].findIndex((item) => item.id === lesson.id)
              : -1;
            return (
              <TouchableOpacity
                key={`${lessonLevel}-topic-${index}`}
                style={[styles.topicRow, !lesson && { opacity: 0.6 }]}
                disabled={!lesson}
                onPress={() => openLesson(lessonLevel, lessonIndex)}
                accessibilityRole="button"
                accessibilityLabel={`${english}, ${persian}${lesson ? '' : ', در دست ساخت'}`}
              >
                <Text style={styles.topicText}>{index + 1}. {english}</Text>
                <Text style={styles.topicText}>{persian}{lesson ? ' ›' : ' · در دست ساخت'}</Text>
              </TouchableOpacity>
            );
          })}
          <BottomNav />
        </ScrollView>
      </SafeAreaView>
    );
  }
 if (screen === 'practiceStory') {
const currentLessonPosition = allLessons.findIndex(
  (lesson) => lesson.id === currentLesson?.id
);
const futureLesson = allLessons.slice(currentLessonPosition + 1).find(
  (lesson) => !completedLessons.includes(lesson.id)
);

const futureItem = futureLesson?.sentences?.[0]
  ? {
      ...futureLesson.sentences[0],
      type: 'Sentence',
      isPreview: true,
    }
  : null;
const currentItem = currentLesson?.sentences?.[0]
  ? {
      ...currentLesson.sentences[0],
      type: 'Sentence',
      isCurrent: true,
    }
  : null;
const personalStoryItems = [...customItems, ...savedSentences]
  .filter((item) => (item?.en || item?.english) && item.id !== currentItem?.id && item.id !== futureItem?.id)
  .slice(0, 4);

const storyItems = [
  ...personalStoryItems,
  ...(currentItem ? [currentItem] : []),
  ...(futureItem ? [futureItem] : []),
];
const wordItems = storyItems.filter((item) => {
  const text = item.en || item.english || '';
  return item.type === 'Word' || !text.trim().includes(' ');
});

const sentenceItems = storyItems.filter(
  (item) => !wordItems.includes(item)
);

const wordEnglish = wordItems.map(
  (item) => item.en || item.english
);

const wordPersian = wordItems
  .map((item) => item.fa || item.persian)
  .filter(Boolean);

const sentenceEnglish = sentenceItems.map(
  (item) => item.en || item.english
);

const sentencePersian = sentenceItems
  .map((item) => item.fa || item.persian)
  .filter(Boolean);

const storyEnglish = [
  'Today I decided to practice English.',
  wordEnglish.length
    ? `I learned ${wordEnglish.length > 1 ? 'the words' : 'the word'} ${wordEnglish
        .map((text) => `"${text}"`)
        .join(', ')}.`
    : '',
  sentenceEnglish.length
    ? `Then I practiced ${sentenceEnglish.length > 1 ? 'the sentences' : 'the sentence'} ${sentenceEnglish
        .map((text) => `"${text}"`)
        .join(', ')}.`
    : '',
  'At the end, I felt more confident.',
]
  .filter(Boolean)
  .join(' ');

const storyPersian = [
  'امروز تصمیم گرفتم انگلیسی تمرین کنم.',
  wordPersian.length
    ? `کلمه‌های «${wordPersian.join('»، «')}» را یاد گرفتم.`
    : '',
  sentencePersian.length
    ? `سپس جمله‌های «${sentencePersian.join('»، «')}» را تمرین کردم.`
    : '',
  'در پایان احساس اعتمادبه‌نفس بیشتری داشتم.',
]
  .filter(Boolean)
  .join(' ');

  return (
    <SafeAreaView style={styles.page}>
      <ScrollView contentContainerStyle={styles.container}>
        <TouchableOpacity onPress={() => setScreen('home')}>
          <Text style={styles.backText}>← Home</Text>
        </TouchableOpacity>

        <Text style={styles.customEyebrow}>PERSONAL PRACTICE</Text>
        <Text style={styles.pageTitle}>My Practice Story 📖</Text>
        <Text style={styles.pageSubtitle}>
          A short practice made from your saved English.
        </Text>

  {storyItems.length === 0 ? (
  <View style={styles.customFormCard}>
    <Text style={styles.customLabel}>
      Save some words or sentences first.
    </Text>
  </View>
) : (
 <View style={styles.customFormCard}>
  <Text style={{ fontSize: 13, fontWeight: '800', marginBottom: 18 }}>
    <Text style={{ color: '#16A36A' }}>● Learned</Text>
    {'   '}
    <Text style={{ color: '#FF7417' }}>● Current</Text>
    {'   '}
    <Text style={{ color: '#1769E0' }}>● Future</Text>
  </Text>

  <Text style={styles.customLabel}>
    Today I practiced English.
    {personalStoryItems.length > 0 && (
      <Text style={{ color: '#16A36A' }}>
        {` I reviewed ${personalStoryItems
          .map((item) => `"${item.en || item.english}"`)
          .join(', ')}.`}
      </Text>
    )}
    {currentItem && (
      <Text style={{ color: '#FF7417' }}>
        {` In my current lesson, I practiced "${currentItem.en}".`}
      </Text>
    )}
    {futureItem && (
      <Text style={{ color: '#1769E0' }}>
        {` For the future, I previewed "${futureItem.en}".`}
      </Text>
    )}
    {' At the end, I felt more confident.'}
  </Text>

  <Text style={styles.pageSubtitle}>
    امروز انگلیسی تمرین کردم.
    {personalStoryItems.length > 0 && (
      <Text style={{ color: '#16A36A' }}>
        {` موارد قبلی «${personalStoryItems
          .map((item) => item.fa || item.persian || item.en || item.english)
          .join('»، «')}» را مرور کردم.`}
      </Text>
    )}
    {currentItem && (
      <Text style={{ color: '#FF7417' }}>
        {` در درس فعلی «${currentItem.fa}» را تمرین کردم.`}
      </Text>
    )}
    {futureItem && (
      <Text style={{ color: '#1769E0' }}>
        {` برای آینده با «${futureItem.fa}» آشنا شدم.`}
      </Text>
    )}
    {' در پایان اعتمادبه‌نفس بیشتری داشتم.'}
  </Text>
</View>

)}
      
      </ScrollView>
    </SafeAreaView>
  );
}
  if (screen === 'conversation') {
    return (
      <SafeAreaView style={styles.page}>
        <ScrollView
          contentContainerStyle={styles.container}
          keyboardShouldPersistTaps="handled"
        >
          <TouchableOpacity onPress={() => setScreen('home')}>
            <Text style={styles.backText}>← Home</Text>
          </TouchableOpacity>

          <Text style={styles.conversationEyebrow}>SPEAKING PRACTICE</Text>
          <Text style={styles.pageTitle}>Conversation Coach 💬</Text>
          <Text style={styles.pageSubtitle}>
            Practice freely. Your coach will guide you with simple questions.
          </Text>

          <View style={styles.conversationTip}>
            <Text style={styles.conversationTipTitle}>Today’s goal</Text>
            <Text style={styles.conversationTipText}>
              Write short English answers. Mistakes are welcome here.
            </Text>
          </View>

          {conversationMessages.map((message) => (
            <View
              key={message.id}
              style={[
                styles.chatBubble,
                message.role === 'user'
                  ? styles.userBubble
                  : styles.coachBubble,
              ]}
            >
              <Text style={styles.chatRole}>
                {message.role === 'user' ? 'YOU' : 'LINGOLOOP COACH'}
              </Text>
              <Text
                style={[
                  styles.chatText,
                  message.role === 'user' && styles.userChatText,
                ]}
              >
                {message.text}
              </Text>
              {!!message.translation && (
                <Text style={styles.chatTranslation}>
                  {message.translation}
                </Text>
              )}
            </View>
          ))}

          <View style={styles.conversationComposer}>
            <TextInput
              style={styles.conversationInput}
              value={conversationInput}
              onChangeText={setConversationInput}
              placeholder="Write your answer in English..."
              placeholderTextColor="#8A949E"
              multiline
            />
            <TouchableOpacity
              style={styles.conversationSendButton}
              onPress={sendConversationMessage}
            >
              <Text style={styles.conversationSendText}>Send →</Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity
            style={styles.restartConversationButton}
            onPress={() => {
              setConversationMessages([
                {
                  id: `coach-welcome-${Date.now()}`,
                  role: 'coach',
                  text: 'Hi! I am your LingoLoop speaking coach. How are you today?',
                  translation: 'سلام! من مربی مکالمه لینگولوپ هستم. امروز حالت چطور است؟',
                },
              ]);
              setConversationInput('');
            }}
          >
            <Text style={styles.restartConversationText}>↻ Start again</Text>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    );
  }
  if (screen === 'myWords') {
    return (
      <SafeAreaView style={styles.page}>
        <ScrollView
          contentContainerStyle={styles.container}
          keyboardShouldPersistTaps="handled"
        >
          <TouchableOpacity onPress={() => setScreen('home')}>
            <Text style={styles.backText}>← Home</Text>
          </TouchableOpacity>

          <Text style={styles.customEyebrow}>YOUR OWN ENGLISH</Text>
          <Text style={styles.pageTitle}>My Words & Sentences</Text>
          <Text style={styles.pageSubtitle}>
            Add anything you want to learn. It will be used in your future personal stories and exercises.
          </Text>

          <View style={styles.customFormCard}>
            <Text style={styles.customLabel}>What are you adding?</Text>
            <View style={styles.customChoiceRow}>
              {['Word', 'Sentence'].map((type) => (
                <TouchableOpacity
                  key={type}
                  style={[
                    styles.customChoice,
                    customType === type && styles.customChoiceSelected,
                  ]}
                  onPress={() => setCustomType(type)}
                >
                  <Text
                    style={[
                      styles.customChoiceText,
                      customType === type && styles.customChoiceTextSelected,
                    ]}
                  >
                    {type === 'Word' ? 'Word' : 'Sentence'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <Text style={styles.customLabel}>English</Text>
            <TextInput
              style={styles.customInput}
              value={customEnglish}
              onChangeText={setCustomEnglish}
              placeholder={customType === 'Word' ? 'e.g. confident' : 'e.g. I feel confident today.'}
              placeholderTextColor="#8A949E"
            />

            <Text style={styles.customLabel}>Persian meaning</Text>
            <TextInput
              style={[styles.customInput, styles.customPersianInput]}
              value={customPersian}
              onChangeText={setCustomPersian}
              placeholder="معنی فارسی را بنویسید"
              placeholderTextColor="#8A949E"
            />

            <Text style={styles.customLabel}>Difficulty</Text>
            <View style={styles.customDifficultyRow}>
              {['Easy', 'Medium', 'Hard'].map((difficulty) => (
                <TouchableOpacity
                  key={difficulty}
                  style={[
                    styles.customDifficultyButton,
                    difficulty === 'Easy' && styles.customEasy,
                    difficulty === 'Medium' && styles.customMedium,
                    difficulty === 'Hard' && styles.customHard,
                    customDifficulty === difficulty && styles.customDifficultySelected,
                  ]}
                  onPress={() => setCustomDifficulty(difficulty)}
                >
                  <Text style={styles.customDifficultyText}>{difficulty}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <TouchableOpacity style={styles.customAddButton} onPress={addCustomItem}>
              <Text style={styles.customAddButtonText}>+ Add to My List</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.customListHeader}>
            <Text style={styles.savedSectionTitle}>My List</Text>
            <Text style={styles.customCount}>{customItems.length} items</Text>
          </View>

          {customItems.length === 0 ? (
            <View style={styles.customEmptyCard}>
              <Text style={styles.customEmptyIcon}>✍️</Text>
              <Text style={styles.customEmptyTitle}>Your list is ready</Text>
              <Text style={styles.customEmptyText}>
                Add your first word or sentence above.
              </Text>
            </View>
          ) : (
            customItems.map((item) => (
              <View key={item.id} style={styles.customItemCard}>
                <View style={styles.customItemTopRow}>
                  <Text style={styles.customTypeBadge}>{item.type}</Text>
                  <Text
                    style={[
                      styles.customDifficultyBadge,
                      item.difficulty === 'Easy' && styles.customEasyText,
                      item.difficulty === 'Medium' && styles.customMediumText,
                      item.difficulty === 'Hard' && styles.customHardText,
                    ]}
                  >
                    {item.difficulty}
                  </Text>
                </View>
                <Text style={styles.english}>{item.en}</Text>
                <Text style={styles.persian}>{item.fa}</Text>
                <TouchableOpacity onPress={() => removeCustomItem(item.id)}>
                  <Text style={styles.customRemove}>🗑 Remove</Text>
                </TouchableOpacity>
              </View>
            ))
          )}

          <BottomNav />
        </ScrollView>
      </SafeAreaView>
    );
  }

  if (screen === 'saved') {
    return (
      <SafeAreaView style={styles.page}>
        <ScrollView contentContainerStyle={styles.container}>
          <Text style={styles.pageTitle}>Saved English</Text>

          {customItems.filter((item) => item.type === 'Word').length > 0 && (
            <>
              <Text style={styles.savedSectionTitle}>Saved Words</Text>
              {customItems.filter((item) => item.type === 'Word').map((item) => (
                <View key={item.id} style={styles.savedCard}>
                  <Text style={styles.english}>{item.en}</Text>
                  <Text style={styles.persian}>{item.fa}</Text>
                  <Text style={styles.savedDifficulty}>{item.difficulty}</Text>
                  <TouchableOpacity onPress={() => speakEnglish(item.en)} style={styles.speechButton}>
                    <Text style={styles.speechButtonText}>🔊 Listen</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => removeCustomItem(item.id)}>
                    <Text>🗑 Remove</Text>
                  </TouchableOpacity>
                </View>
              ))}
            </>
          )}

          {savedSentences.length === 0 ? (
            <Text style={styles.empty}>No saved sentences yet.</Text>
          ) : (
          <>
      
      {easySaved.length > 0 && (
      <>
   <Text style={styles.savedSectionTitle}>Easy</Text>  
          
           {easySaved.map((sentence) => (
            
              <View key={sentence.id} style={styles.savedCard}>
                <Text style={styles.english}>{sentence.en}</Text>
                <Text style={styles.persian}>{sentence.fa}</Text>

                <Text style={[styles.savedDifficulty, { color: '#165DDB' }]}>
                  {levels[sentence.id] || 'Not rated'}
                </Text>
            <TouchableOpacity
  onPress={() => removeSavedSentence(sentence.id)}
>
  <Text>🗑 Remove</Text>
</TouchableOpacity>    
              </View>
            ))}
            </>
)}
{mediumSaved.length > 0 && (
  <>
      <Text style={styles.savedSectionTitle}>Medium</Text>
        {mediumSaved.map((sentence) => (
            <View key={sentence.id} style={styles.savedCard}>
            
            <Text style={styles.english}>{sentence.en}</Text>
            <Text style={styles.persian}>{sentence.fa}</Text>
     <Text style={[styles.savedDifficulty, { color: '#B8860B' }]}>
  {levels[sentence.id] || 'Not rated'}
</Text> 
<TouchableOpacity
  onPress={() => removeSavedSentence(sentence.id)}
>
  <Text>🗑 Remove</Text>
</TouchableOpacity>
</View>     
          ))}
          </>
)}

{hardSaved.length > 0 && (
  <>
    <Text style={styles.savedSectionTitle}>Hard</Text>

    {hardSaved.map((sentence) => (
      <View key={sentence.id} style={styles.savedCard}>
        <Text style={styles.english}>{sentence.en}</Text>

        <Text style={styles.persian}>{sentence.fa}</Text>

        <Text style={styles.savedDifficulty}>
          {levels[sentence.id] || 'Not rated'}
        </Text>

        <TouchableOpacity
          onPress={() => removeSavedSentence(sentence.id)}
        >
          <Text>🗑 Remove</Text>
        </TouchableOpacity>
      </View>
     ) )}
</>
)}
</>
)}
<BottomNav/>
</ScrollView>
</SafeAreaView>
);
}

  if (screen === 'review' && reviewLesson && reviewSentence) {
    const reviewInfo = getReviewInfo(reviewLessonId);

    return (
      <SafeAreaView style={styles.page}>
        <ScrollView contentContainerStyle={styles.container}>
          <TouchableOpacity onPress={() => setScreen('progress')}>
            <Text style={styles.backText}>← Review Schedule</Text>
          </TouchableOpacity>

          <Text style={styles.reviewEyebrow}>
            {reviewInfo.finished
              ? 'EXTRA PRACTICE'
              : `${reviewInfo.interval}-DAY REVIEW`}
          </Text>
          <Text style={styles.pageTitle}>{reviewLesson.title}</Text>
          <Text style={styles.pageSubtitle}>
            Read the sentence, remember its meaning, then continue.
          </Text>

          <Text style={styles.counter}>
            {reviewSentenceIndex + 1} / {reviewLesson.sentences.length}
          </Text>

          <View style={styles.sentenceCard}>
            <Text style={styles.english}>{reviewSentence.en}</Text>
            <Text style={styles.persian}>{reviewSentence.fa}</Text>
            <Text style={styles.reviewDifficulty}>
              Difficulty: {levels[reviewSentence.id] || 'Not rated'}
            </Text>
          </View>

          {!reviewInfo.isDue && !reviewInfo.finished && (
            <Text style={styles.earlyPracticeNote}>
              Early practice does not change your next review date.
            </Text>
          )}

          <TouchableOpacity
            style={styles.nextButton}
            onPress={nextReviewSentence}
          >
            <Text style={styles.nextText}>
              {reviewSentenceIndex === reviewLesson.sentences.length - 1
                ? 'Finish Review ✓'
                : 'Next →'}
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    );
  }

  if (screen === 'progress') {
    return (
      <SafeAreaView style={styles.page}>
        <ScrollView contentContainerStyle={styles.container}>
          <Text style={styles.pageTitle}>Your Progress</Text>

          <View style={styles.bigStatCard}>
            <Text style={styles.bigStatNumber}>{practicedCount}</Text>
            <Text style={styles.bigStatLabel}>Sentences Practiced</Text>
          </View>

          <View style={styles.bigStatCard}>
            <Text style={styles.bigStatNumber}>{saved.length}</Text>
            <Text style={styles.bigStatLabel}>Saved Sentences</Text>
          </View>

          <View style={styles.bigStatCard}>
            <Text style={styles.bigStatNumber}>
              {completedLessons.length}
            </Text>
            <Text style={styles.bigStatLabel}>Completed Lessons</Text>
          </View>

          <Text style={styles.reviewSectionTitle}>Review Schedule</Text>
          <Text style={styles.reviewSectionSubtitle}>
            Default reviews are after 3, 7, 10, 14, and 30 days. Add more days whenever you want.
          </Text>

          <View style={styles.addReviewCard}>
            <Text style={styles.addReviewTitle}>Add another review day</Text>
            <Text style={styles.addReviewHint}>
              Choose any day you want. Your schedule sorts automatically.
            </Text>
            <View style={styles.customDaysRow}>
              {reviewIntervals.map((day) => (
                <TouchableOpacity
                  key={day}
                  style={styles.customDayChip}
                  onPress={() => removeReviewDay(day)}
                >
                  <Text style={styles.customDayText}>{day}d  ×</Text>
                </TouchableOpacity>
              ))}
            </View>
            <View style={styles.addReviewRow}>
              <TextInput
                style={styles.reviewDayInput}
                value={customReviewDay}
                onChangeText={setCustomReviewDay}
                placeholder="Example: 60"
                keyboardType="number-pad"
                maxLength={4}
              />
              <TouchableOpacity
                style={styles.addReviewButton}
                onPress={addCustomReviewDay}
              >
                <Text style={styles.addReviewButtonText}>Add Day +</Text>
              </TouchableOpacity>
            </View>
          </View>

          {reviewItems.length === 0 ? (
            <View style={styles.reviewEmptyCard}>
              <Text style={styles.reviewEmptyIcon}>🗓️</Text>
              <Text style={styles.reviewEmptyTitle}>No reviews scheduled yet</Text>
              <Text style={styles.reviewEmptyText}>
                Finish a lesson and its first review will be scheduled in 3 days.
              </Text>
            </View>
          ) : (
            reviewItems.map(({ lesson, info }) => (
              <View key={lesson.id} style={styles.reviewCard}>
                <View style={styles.reviewCardHeader}>
                  <View style={styles.reviewCardText}>
                    <Text style={styles.reviewLessonTitle}>{lesson.title}</Text>
                    <Text style={styles.reviewDateText}>
                      {info.finished
                        ? 'All scheduled reviews completed'
                        : `${info.interval}-day review • ${formatReviewDate(
                            info.dueDate
                          )}`}
                    </Text>
                  </View>
                  <Text
                    style={[
                      styles.reviewStatus,
                      info.isDue && styles.reviewStatusDue,
                      info.finished && styles.reviewStatusDone,
                    ]}
                  >
                    {info.finished ? 'Done' : info.isDue ? 'Due' : 'Upcoming'}
                  </Text>
                </View>

                <View style={styles.reviewSteps}>
                  {reviewIntervals.map((days) => (
                    <View
                      key={days}
                      style={[
                        styles.reviewStep,
                        reviewSchedules[lesson.id].completedIntervals.includes(
                          days
                        ) && styles.reviewStepDone,
                      ]}
                    >
                      <Text style={styles.reviewStepText}>{days}d</Text>
                    </View>
                  ))}
                </View>

                <TouchableOpacity
                  style={styles.reviewButton}
                  onPress={() => startReview(lesson.id)}
                >
                  <Text style={styles.reviewButtonText}>
                    {info.finished
                      ? 'Practice Again'
                      : info.isDue
                      ? 'Review Now →'
                      : 'Practice Early →'}
                  </Text>
                </TouchableOpacity>
              </View>
            ))
          )}

          <BottomNav />
        </ScrollView>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.page}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.logoRow}>
          <Text style={styles.logoLingo}>Lingo</Text>
          <Text style={styles.logoLoop}>Loop.</Text>
        </View>

        <Text style={styles.tagline}>Learn. Practice. Repeat.</Text>

        <View style={styles.hero}>
          <Text style={styles.hello}>Good evening 👋</Text>
          <Text style={styles.subtitle}>
            Ready for your English today?
          </Text>
        </View>

        <View style={styles.currentCard}>
          <Text style={styles.currentLabel}>CONTINUE LESSON</Text>

          <Text style={styles.currentTitle}>
            {resumeLesson.title}
          </Text>

          <Text style={styles.currentDescription}>
            {resumeLesson.description}
          </Text>

          <TouchableOpacity
            style={styles.continueButton}
            onPress={continueLesson}
          >
            <Text style={styles.continueText}>
              Continue Lesson →
            </Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.sectionTitle}>Choose Your Level</Text>

        <LevelTabs />

        <Text style={styles.sectionTitle}>Your progress</Text>

        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>📘 {practicedCount}</Text>
            <Text style={styles.statLabel}>Practiced</Text>
          </View>

          <TouchableOpacity
            style={styles.statCard}
            onPress={() => setScreen('saved')}
          >
            <Text style={styles.statNumber}>♥ {saved.length}</Text>
            <Text style={styles.statLabel}>Saved</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.statCard}
            onPress={() => setScreen('progress')}
          >
            <Text style={styles.statNumber}>
              🏆 {completedLessons.length}
            </Text>
            <Text style={styles.statLabel}>Completed</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          style={styles.savedShortcut}
          onPress={() => setScreen('saved')}
        >
          <Text style={styles.savedShortcutText}>
            ♥ Saved Sentences
          </Text>
          <Text style={styles.arrow}>›</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.customHomeShortcut}
          onPress={() => setScreen('myWords')}
        >
          <View style={styles.customHomeIconWrap}>
            <Text style={styles.customHomeIcon}>✍️</Text>
          </View>
          <View style={styles.customHomeTextWrap}>
            <Text style={styles.customHomeTitle}>My Words & Sentences</Text>
            <Text style={styles.customHomeSubtitle}>
              Add your own English • {customItems.length} saved
            </Text>
          </View>
          <Text style={styles.arrow}>›</Text>
        </TouchableOpacity>

<TouchableOpacity
  style={styles.customHomeShortcut}
  onPress={() => setScreen('practiceStory')}
>
  <View style={styles.customHomeIconWrap}>
    <Text style={styles.customHomeIcon}>📖</Text>
  </View>

  <View style={styles.customHomeTextWrap}>
    <Text style={styles.customHomeTitle}>Practice Story</Text>
    <Text style={styles.customHomeSubtitle}>
      Practice with your saved English
    </Text>
  </View>

  <Text style={styles.arrow}>›</Text>
</TouchableOpacity>

<TouchableOpacity
  style={styles.customHomeShortcut}
  onPress={() => setScreen('conversation')}
>
  <View style={[styles.customHomeIconWrap, styles.conversationHomeIconWrap]}>
    <Text style={styles.customHomeIcon}>💬</Text>
  </View>
  <View style={styles.customHomeTextWrap}>
    <Text style={styles.customHomeTitle}>Conversation Coach</Text>
    <Text style={styles.customHomeSubtitle}>
      Practice a guided English conversation
    </Text>
  </View>
  <Text style={styles.arrow}>›</Text>
</TouchableOpacity>
        <BottomNav />


      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: '#D9EEFF',
  },
  savedSectionTitle: {
  fontSize: 22,
  fontWeight: '800',
  color: '#2F63D8',
  marginTop: 12,
  marginBottom: 8,
},

  container: {
    paddingHorizontal: 20,
    paddingTop: 28,
    paddingBottom: 40,
  },

  logoRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  logoLingo: {
    fontSize: 42,
    fontWeight: '800',
    color: '#FF7A1A',
    letterSpacing: -2,
  },

  logoLoop: {
    fontSize: 42,
    fontWeight: '800',
    color: '#165DDB',
    letterSpacing: -2,
  },

  tagline: {
    marginTop: 2,
    color: '#68717B',
    fontSize: 16,
  },

  hero: {
    marginTop: 35,
  },

  hello: {
    fontSize: 30,
    fontWeight: '800',
    color: '#141414',
  },

  subtitle: {
    marginTop: 8,
    fontSize: 17,
    color: '#68717B',
  },

  currentCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 28,
    padding: 22,
    marginTop: 28,
  },

  currentLabel: {
    color: '#68717B',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 1.5,
  },

  currentTitle: {
    fontSize: 27,
    fontWeight: '800',
    marginTop: 8,
    color: '#111111',
  },

  currentDescription: {
    fontSize: 16,
    lineHeight: 24,
    color: '#68717B',
    marginTop: 10,
  },

  continueButton: {
    backgroundColor: '#FF7A1A',
    borderRadius: 18,
    paddingVertical: 16,
    marginTop: 20,
    alignItems: 'center',
  },

  continueText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
  },

  sectionTitle: {
    fontSize: 24,
    fontWeight: '800',
    marginTop: 30,
    marginBottom: 15,
    color: '#111111',
  },

  cefrGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  cefrTile: { width: '31%', backgroundColor: '#EAF5FF', borderRadius: 14, padding: 12, alignItems: 'center' },
  cefrTileActive: { borderWidth: 2, borderColor: '#2588FF' },
  cefrCode: { color: '#173D73', fontWeight: '800', fontSize: 20 },
  cefrLabel: { color: '#536879', fontSize: 11 },
  topicRow: { paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#E7EDF2', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 10 },
  topicText: { color: '#233445', fontSize: 14, flexShrink: 1 },
  tipsBox: { backgroundColor: '#F0F7FF', borderRadius: 12, padding: 14, marginTop: 15 },
  tipText: { color: '#263B50', fontSize: 14, lineHeight: 24, marginTop: 7, textAlign: 'right', writingDirection: 'rtl' },
  dialogueTurn: { borderBottomWidth: 1, borderBottomColor: '#E7EDF2', paddingVertical: 12 },
  dialogueSpeaker: { color: '#246CB5', fontWeight: '800', marginBottom: 4 },
  levelTabs: {
    flexDirection: 'row',
    gap: 10,
  },

  levelTab: {
    flex: 1,
    borderRadius: 22,
    paddingVertical: 18,
    paddingHorizontal: 10,
    alignItems: 'center',
  },

  beginnerTab: {
    backgroundColor: '#EAF5FF',
  },

  intermediateTab: {
    backgroundColor: '#FFF5C9',
  },

  advancedTab: {
    backgroundColor: '#FFE4D3',
  },

  beginnerSelected: {
    borderWidth: 2,
    borderColor: '#2588FF',
  },

  intermediateSelected: {
    borderWidth: 2,
    borderColor: '#E6B800',
  },

  advancedSelected: {
    borderWidth: 2,
    borderColor: '#FF7A1A',
  },

  levelIcon: {
    fontSize: 28,
  },

  levelTabTitle: {
    fontSize: 16,
    fontWeight: '800',
    marginTop: 8,
    color: '#111111',
  },

  levelTabSub: {
    fontSize: 12,
    marginTop: 4,
    textAlign: 'center',
    color: '#68717B',
  },

  statsRow: {
    flexDirection: 'row',
    gap: 10,
  },

  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 16,
  },

  statNumber: {
    fontSize: 20,
    fontWeight: '800',
    color: '#111111',
  },

  statLabel: {
    fontSize: 13,
    color: '#68717B',
    marginTop: 5,
  },

  savedShortcut: {
    marginTop: 18,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 18,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  savedShortcutText: {
    fontSize: 17,
    fontWeight: '800',
  },

  bottomNav: {
    marginTop: 24,
    backgroundColor: '#FFFFFF',
    borderRadius: 28,
    paddingVertical: 14,
    paddingHorizontal: 18,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  navText: {
    textAlign: 'center',
    fontSize: 22,
    color: '#68717B',
  },

  navActive: {
    textAlign: 'center',
    fontSize: 22,
    color: '#165DDB',
  },

  navLabel: {
    textAlign: 'center',
    fontSize: 12,
    color: '#68717B',
  },

  navActiveLabel: {
    textAlign: 'center',
    fontSize: 12,
    color: '#165DDB',
    fontWeight: '800',
  },

  pageTitle: {
    marginTop: 28,
    fontSize: 32,
    fontWeight: '800',
    color: '#111111',
  },

  pageSubtitle: {
    fontSize: 17,
    color: '#68717B',
    marginTop: 6,
    marginBottom: 20,
  },

  lessonListCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 22,
    padding: 16,
    marginBottom: 14,
    flexDirection: 'row',
    alignItems: 'center',
  },

  lessonListContent: {
    flex: 1,
  },

  lessonListNumber: {
    color: '#165DDB',
    fontSize: 14,
    fontWeight: '700',
  },

  lessonListTitle: {
    fontSize: 20,
    fontWeight: '800',
    marginTop: 4,
  },

  lessonListDescription: {
    fontSize: 14,
    color: '#68717B',
    marginTop: 4,
  },

  progressCircle: {
    width: 58,
    height: 58,
    borderRadius: 29,
    borderWidth: 5,
    borderColor: '#DCE7F8',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
  },

  progressCircleText: {
    color: '#165DDB',
    fontWeight: '800',
  },

  arrow: {
    fontSize: 28,
    marginLeft: 10,
    color: '#111111',
  },

  backText: {
    fontSize: 17,
    color: '#111111',
    marginBottom: 20,
  },

  lessonNumber: {
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 1.5,
    color: '#808080',
  },

  lessonTitle: {
    fontSize: 29,
    fontWeight: '800',
    marginTop: 8,
  },

  lessonSectionTabs: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 22,
  },

  lessonSectionTab: {
    flex: 1,
    minHeight: 76,
    backgroundColor: '#EDF3FB',
    borderRadius: 16,
    paddingVertical: 10,
    paddingHorizontal: 6,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },

  lessonSectionTabActive: {
    backgroundColor: '#FFFFFF',
    borderColor: '#165DDB',
  },

  lessonSectionIcon: {
    fontSize: 21,
    marginBottom: 4,
  },

  lessonSectionTabText: {
    fontSize: 12,
    fontWeight: '800',
    color: '#68717B',
    textAlign: 'center',
  },

  lessonSectionTabTextActive: {
    color: '#165DDB',
  },

  learningCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 26,
    padding: 22,
    marginTop: 18,
  },

  learningEyebrow: {
    color: '#165DDB',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.6,
  },

  learningTitle: {
    fontSize: 23,
    lineHeight: 31,
    fontWeight: '800',
    color: '#111111',
    marginTop: 8,
  },

  learningPersian: {
    fontSize: 17,
    lineHeight: 28,
    color: '#68717B',
    textAlign: 'right',
    marginTop: 8,
  },

  formulaBox: {
    backgroundColor: '#EAF3FF',
    borderRadius: 18,
    padding: 16,
    marginTop: 18,
  },

  formulaLabel: {
    color: '#68717B',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.3,
  },

  formulaText: {
    color: '#165DDB',
    fontSize: 19,
    lineHeight: 27,
    fontWeight: '800',
    marginTop: 6,
  },

  formulaPersian: {
    color: '#263B50',
    fontSize: 15,
    lineHeight: 25,
    textAlign: 'right',
    writingDirection: 'rtl',
    marginTop: 9,
  },

  learningExplanation: {
    color: '#111111',
    fontSize: 16,
    lineHeight: 25,
    marginTop: 18,
  },

  learningExplanationFa: {
    color: '#68717B',
    fontSize: 16,
    lineHeight: 27,
    textAlign: 'right',
    marginTop: 8,
  },

  miniSectionTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: '#111111',
    marginTop: 22,
    marginBottom: 8,
  },

  grammarExampleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F7FAFE',
    borderRadius: 15,
    padding: 14,
    marginTop: 8,
  },

  grammarExampleText: {
    fontSize: 16,
    lineHeight: 23,
    fontWeight: '700',
    color: '#111111',
  },

  grammarExampleContent: { flex: 1 },
  grammarExamplePersian: {
    color: '#526478',
    fontSize: 15,
    lineHeight: 24,
    textAlign: 'right',
    writingDirection: 'rtl',
    marginTop: 6,
  },

  smallSpeechButton: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: '#EAF3FF',
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 10,
  },

  smallSpeechButtonText: {
    fontSize: 19,
  },

  vocabularyCard: {
    backgroundColor: '#F7FAFE',
    borderRadius: 18,
    padding: 16,
    marginTop: 12,
  },

  vocabularyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  vocabularyTextArea: {
    flex: 1,
  },

  vocabularyWord: {
    fontSize: 21,
    fontWeight: '800',
    color: '#111111',
  },

  vocabularyMeaning: {
    fontSize: 16,
    color: '#68717B',
    textAlign: 'right',
    marginTop: 3,
  },

  vocabularyPhrase: {
    color: '#165DDB',
    fontSize: 15,
    fontWeight: '700',
    marginTop: 12,
  },

  vocabularySaveLabel: {
    color: '#526478',
    fontSize: 13,
    fontWeight: '700',
    marginTop: 16,
    marginBottom: 8,
  },

  counter: {
    marginTop: 8,
    fontSize: 17,
    color: '#68717B',
  },

  sentenceCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 26,
    padding: 24,
    marginTop: 22,
  },

  tappableWordText: {
    textDecorationLine: 'underline',
    textDecorationColor: '#8DB9ED',
  },
  selectedWordText: {
    color: '#165DDB',
    textDecorationLine: 'underline',
  },
  wordSelectionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 22,
    padding: 20,
    marginTop: 14,
    gap: 12,
  },
  wordSelectionTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: '#111111',
  },
  speechButton: {
    backgroundColor: '#EAF3FF',
    borderRadius: 14,
    paddingVertical: 12,
    paddingHorizontal: 16,
    marginTop: 12,
    alignItems: 'center',
  },
  speechButtonText: {
    color: '#165DDB',
    fontWeight: '800',
    fontSize: 15,
  },
  wordDifficultyButton: {
    flex: 1,
    backgroundColor: '#EDF3FB',
    borderRadius: 12,
    alignItems: 'center',
    paddingVertical: 12,
  },
  wordDifficultySelected: {
    borderColor: '#165DDB',
    borderWidth: 2,
  },

  english: {
    fontSize: 22,
    fontWeight: '800',
    lineHeight: 31,
    color: '#111111',
  },

  persian: {
    fontSize: 18,
    lineHeight: 30,
    textAlign: 'right',
    color: '#68717B',
    marginTop: 16,
  },

  question: {
    fontSize: 19,
    fontWeight: '800',
    textAlign: 'center',
    marginTop: 28,
    marginBottom: 16,
  },

  difficultyRow: {
    flexDirection: 'row',
    gap: 10,
  },

  difficultyButton: {
    flex: 1,
    paddingVertical: 15,
    borderRadius: 16,
    alignItems: 'center',
  },

  easyButton: {
    backgroundColor: '#60B8FF',
  },

  mediumButton: {
    backgroundColor: '#FFD84D',
  },

  hardButton: {
    backgroundColor: '#FF7A1A',
  },

  easySelected: {
    borderWidth: 3,
    borderColor: '#165DDB',
  },

  mediumSelected: {
    borderWidth: 3,
    borderColor: '#C69B00',
  },

  hardSelected: {
    borderWidth: 3,
    borderColor: '#B94700',
  },

  difficultyText: {
    fontSize: 16,
    fontWeight: '800',
    color: '#111111',
  },

  saveButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    paddingVertical: 17,
    marginTop: 22,
    alignItems: 'center',
  },

  saveText: {
    fontSize: 17,
    fontWeight: '800',
  },

  lessonNavigationRow: { flexDirection: 'row', gap: 10, alignItems: 'stretch' },
  lessonBackButton: { flex: 1, backgroundColor: '#E7F0FF' },
  lessonForwardButton: { flex: 2 },
  lessonBackText: { fontSize: 17, fontWeight: '800', color: '#165DDB' },

  nextButton: {
    backgroundColor: '#165DDB',
    borderRadius: 18,
    paddingVertical: 17,
    marginTop: 12,
    alignItems: 'center',
  },

  nextText: {
    fontSize: 17,
    fontWeight: '800',
    color: '#FFFFFF',
  },

  savedCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 22,
    padding: 20,
    marginTop: 6,
  },

  savedDifficulty: {
    marginTop: 12,
    color: '#FF7A1A',
    fontWeight: '800',
  },

  customEyebrow: {
    marginTop: 28,
    color: '#FF7A1A',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 1,
  },

  customFormCard: {
    marginTop: 20,
    padding: 20,
    borderRadius: 24,
    backgroundColor: '#FFFFFF',
  },

  customLabel: {
    marginTop: 14,
    marginBottom: 8,
    color: '#141414',
    fontSize: 15,
    fontWeight: '800',
  },

  customChoiceRow: {
    flexDirection: 'row',
  },

  customChoice: {
    flex: 1,
    paddingVertical: 12,
    borderWidth: 2,
    borderColor: '#D8DEE5',
    alignItems: 'center',
  },

  customChoiceSelected: {
    borderColor: '#165DDB',
    backgroundColor: '#E8F1FF',
  },

  customChoiceText: {
    color: '#68717B',
    fontSize: 15,
    fontWeight: '800',
  },

  customChoiceTextSelected: {
    color: '#165DDB',
  },

  customInput: {
    minHeight: 50,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderColor: '#D8DEE5',
    borderRadius: 14,
    backgroundColor: '#F8FAFC',
    color: '#141414',
    fontSize: 16,
  },

  customPersianInput: {
    textAlign: 'right',
  },

  customDifficultyRow: {
    flexDirection: 'row',
  },

  customDifficultyButton: {
    flex: 1,
    marginRight: 7,
    paddingVertical: 12,
    borderWidth: 3,
    borderColor: 'transparent',
    borderRadius: 14,
    alignItems: 'center',
  },

  customEasy: { backgroundColor: '#83B7FF' },
  customMedium: { backgroundColor: '#FFD84D' },
  customHard: { backgroundColor: '#FF7A1A' },
  customDifficultySelected: { borderColor: '#141414' },
  customDifficultyText: { color: '#141414', fontWeight: '800' },

  customAddButton: {
    marginTop: 20,
    paddingVertical: 16,
    borderRadius: 17,
    backgroundColor: '#165DDB',
    alignItems: 'center',
  },

  customAddButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },

  customListHeader: {
    marginTop: 18,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  customCount: {
    color: '#68717B',
    fontSize: 14,
    fontWeight: '700',
  },

  customEmptyCard: {
    marginTop: 12,
    padding: 24,
    borderRadius: 22,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
  },

  customEmptyIcon: { fontSize: 32 },
  customEmptyTitle: {
    marginTop: 10,
    color: '#141414',
    fontSize: 18,
    fontWeight: '800',
  },
  customEmptyText: {
    marginTop: 6,
    color: '#68717B',
    fontSize: 14,
  },

  customItemCard: {
    marginTop: 12,
    padding: 20,
    borderRadius: 22,
    backgroundColor: '#FFFFFF',
  },

  customItemTopRow: {
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },

  customTypeBadge: {
    color: '#165DDB',
    fontSize: 13,
    fontWeight: '800',
  },

  customDifficultyBadge: { fontSize: 13, fontWeight: '800' },
  customEasyText: { color: '#165DDB' },
  customMediumText: { color: '#B8860B' },
  customHardText: { color: '#FF7A1A' },
  customRemove: { marginTop: 14, color: '#68717B' },

  customHomeShortcut: {
    marginTop: 14,
    padding: 18,
    borderRadius: 22,
    backgroundColor: '#FFFFFF',
    flexDirection: 'row',
    alignItems: 'center',
  },

  customHomeIconWrap: {
    width: 46,
    height: 46,
    marginRight: 12,
    borderRadius: 15,
    backgroundColor: '#FFF0E5',
    alignItems: 'center',
    justifyContent: 'center',
  },

  customHomeIcon: { fontSize: 23 },
  customHomeTextWrap: { flex: 1 },
  customHomeTitle: {
    color: '#141414',
    fontSize: 17,
    fontWeight: '800',
  },
  customHomeSubtitle: {
    marginTop: 4,
    color: '#68717B',
    fontSize: 13,
  },

  conversationHomeIconWrap: {
    backgroundColor: '#E8F1FF',
  },

  conversationEyebrow: {
    marginTop: 28,
    color: '#165DDB',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 1,
  },

  conversationTip: {
    marginBottom: 18,
    padding: 18,
    borderRadius: 20,
    backgroundColor: '#FFF0E5',
  },

  conversationTipTitle: {
    color: '#FF7A1A',
    fontSize: 14,
    fontWeight: '800',
  },

  conversationTipText: {
    marginTop: 5,
    color: '#39424C',
    fontSize: 14,
    lineHeight: 21,
  },

  chatBubble: {
    maxWidth: '88%',
    marginBottom: 12,
    padding: 16,
    borderRadius: 20,
  },

  coachBubble: {
    alignSelf: 'flex-start',
    backgroundColor: '#FFFFFF',
    borderBottomLeftRadius: 6,
  },

  userBubble: {
    alignSelf: 'flex-end',
    backgroundColor: '#165DDB',
    borderBottomRightRadius: 6,
  },

  chatRole: {
    marginBottom: 7,
    color: '#FF7A1A',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.8,
  },

  chatText: {
    color: '#141414',
    fontSize: 16,
    fontWeight: '700',
    lineHeight: 23,
  },

  userChatText: {
    color: '#FFFFFF',
  },

  chatTranslation: {
    marginTop: 9,
    color: '#68717B',
    fontSize: 14,
    lineHeight: 21,
    textAlign: 'right',
  },

  conversationComposer: {
    marginTop: 8,
    padding: 14,
    borderRadius: 22,
    backgroundColor: '#FFFFFF',
  },

  conversationInput: {
    minHeight: 70,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#D8DEE5',
    borderRadius: 15,
    backgroundColor: '#F8FAFC',
    color: '#141414',
    fontSize: 16,
    textAlignVertical: 'top',
  },

  conversationSendButton: {
    marginTop: 10,
    paddingVertical: 14,
    borderRadius: 15,
    backgroundColor: '#FF7A1A',
    alignItems: 'center',
  },

  conversationSendText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },

  restartConversationButton: {
    marginTop: 12,
    paddingVertical: 13,
    alignItems: 'center',
  },

  restartConversationText: {
    color: '#165DDB',
    fontSize: 14,
    fontWeight: '800',
  },

  empty: {
    fontSize: 17,
    color: '#68717B',
    marginTop: 20,
  },

  bigStatCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 22,
    padding: 24,
    marginTop: 16,
  },

  bigStatNumber: {
    fontSize: 36,
    fontWeight: '800',
    color: '#165DDB',
  },

  bigStatLabel: {
    fontSize: 17,
    color: '#68717B',
    marginTop: 6,
  },

  reviewSectionTitle: {
    marginTop: 34,
    fontSize: 26,
    fontWeight: '800',
    color: '#141414',
  },

  reviewSectionSubtitle: {
    marginTop: 7,
    marginBottom: 4,
    fontSize: 15,
    lineHeight: 22,
    color: '#68717B',
  },

  addReviewCard: {
    marginTop: 16,
    padding: 18,
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
  },

  addReviewTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: '#141414',
  },

  addReviewHint: {
    marginTop: 5,
    fontSize: 13,
    color: '#68717B',
  },

  customDaysRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 12,
  },

  customDayChip: {
    marginRight: 8,
    marginBottom: 8,
    paddingHorizontal: 11,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: '#E8F1FF',
  },

  customDayText: {
    color: '#165DDB',
    fontSize: 13,
    fontWeight: '800',
  },

  addReviewRow: {
    flexDirection: 'column',
    alignItems: 'stretch',
    marginTop: 14,
  },

  reviewDayInput: {
   width: '100%',
    height: 48,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderColor: '#D8DEE5',
    borderRadius: 14,
    backgroundColor: '#F8FAFC',
    fontSize: 16,
    color: '#141414',
  },

  addReviewButton: {
    height: 48,
    marginTop: 10,
    paddingHorizontal: 16,
    borderRadius: 14,
    backgroundColor: '#165DDB',
    alignItems: 'center',
    justifyContent: 'center',
  },

  addReviewButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '800',
  },

  reviewEmptyCard: {
    marginTop: 16,
    padding: 24,
    borderRadius: 24,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
  },

  reviewEmptyIcon: {
    fontSize: 30,
  },

  reviewEmptyTitle: {
    marginTop: 10,
    fontSize: 18,
    fontWeight: '800',
    color: '#141414',
  },

  reviewEmptyText: {
    marginTop: 7,
    fontSize: 14,
    lineHeight: 21,
    color: '#68717B',
    textAlign: 'center',
  },

  reviewCard: {
    marginTop: 16,
    padding: 20,
    borderRadius: 24,
    backgroundColor: '#FFFFFF',
  },

  reviewCardHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
  },

  reviewCardText: {
    flex: 1,
    paddingRight: 10,
  },

  reviewLessonTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: '#141414',
  },

  reviewDateText: {
    marginTop: 5,
    fontSize: 14,
    color: '#68717B',
  },

  reviewStatus: {
    overflow: 'hidden',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: '#E8F1FF',
    color: '#165DDB',
    fontSize: 12,
    fontWeight: '800',
  },

  reviewStatusDue: {
    backgroundColor: '#FFF0E5',
    color: '#B94700',
  },

  reviewStatusDone: {
    backgroundColor: '#E8F7EE',
    color: '#237A45',
  },

  reviewSteps: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 18,
  },

  reviewStep: {
    minWidth: 46,
    marginRight: 8,
    marginBottom: 8,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: '#EEF1F4',
    alignItems: 'center',
  },

  reviewStepDone: {
    backgroundColor: '#BFE9CF',
  },

  reviewStepText: {
    fontSize: 13,
    fontWeight: '800',
    color: '#39424C',
  },

  reviewButton: {
    marginTop: 18,
    paddingVertical: 14,
    borderRadius: 16,
    backgroundColor: '#FF7A1A',
    alignItems: 'center',
  },

  reviewButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
  },

  reviewEyebrow: {
    marginTop: 32,
    color: '#FF7A1A',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 1,
  },

  reviewDifficulty: {
    marginTop: 18,
    color: '#68717B',
    fontSize: 14,
    fontWeight: '700',
  },

  earlyPracticeNote: {
    marginTop: 14,
    paddingHorizontal: 4,
    color: '#68717B',
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'center',
  },
});
