# نخستین بستهٔ پژوهشی LingoLoop — ۶ درس نمونه

تاریخ بررسی: ۲۵ سپتامبر ۲۰۲۶. این بسته در هر یک از سطوح A1 تا C2 یک درس موجود را با واژگان و مثال‌های تازهٔ نوشته‌شده برای LingoLoop تقویت می‌کند. عنوان و جمله‌های اصلی درس‌ها در فایل فعلی اپ باقی مانده‌اند. این مرحله، تکمیل همهٔ درس‌ها یا تأیید قطعی سطح تک‌تک واژه‌ها نیست.

| سطح | شناسه و موضوع | مبنای انتخاب موضوع و سطح |
|---|---|---|
| A1 | intro1، آشنایی و معرفی | [British Council: A1 و معرفی خود](https://learnenglish.britishcouncil.org/level/understand-your-level/a1-elementary)، [Meeting new people](https://learnenglish.britishcouncil.org/free-resources/speaking/a1/meeting-new-people?page=0) |
| A2 | a2routine، برنامه و دعوت | [British Council: A2 writing](https://learnenglish.britishcouncil.org/free-resources/writing/a2)، شامل برنامه‌ریزی و لغو برنامه |
| B1 | b1problem، مشکل سفر | [British Council: B1](https://learnenglish.britishcouncil.org/level/understand-your-level/b1-intermediate)، ترتیبات سفر و حمل‌ونقل |
| B2 | b2mechanic، مقایسهٔ تعمیر | [British Council: B2 speaking](https://learnenglish.britishcouncil.org/free-resources/speaking/b2)، سنجیدن مزایا و معایب؛ [CEFR global scale](https://www.coe.int/en/web/common-european-framework-reference-languages/table-1-cefr-3.3-common-reference-levels-global-scale) |
| C1 | c1presentation، ارائهٔ پیشنهاد | [British Council: C1 proposal](https://learnenglish.britishcouncil.org/free-resources/writing/c1/proposal-digital-newspaper)؛ کاربرد پیشنهاد مستدل |
| C2 | c2debate، بحث سنجیده | [Council of Europe: qualitative spoken language](https://www.coe.int/en/web/common-european-framework-reference-languages/table-3-cefr-3.3-common-reference-levels-qualitative-aspects-of-spoken-language-use)، بیان دقیق تفاوت‌های ظریف معنا |

واژه‌ها، مثال‌ها و ترجمه‌ها متن تازه‌اند. منابع برای انتخاب موضوع و تناسب سطح استفاده شده‌اند، نه برای کپی کردن متن یا فهرست واژگان. بررسی نهایی آموزشی با یک مدرس انگلیسی، به‌خصوص برای C1/C2 و ترجمه‌های فارسی، پیش از انتشار عمومی توصیه می‌شود.
