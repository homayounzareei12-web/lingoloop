import json
import re
from pathlib import Path

root = Path(__file__).parent
source = (root / 'App.js').read_text(encoding='utf-8')
data = json.loads((root / 'researched-content.json').read_text(encoding='utf-8'))
assert isinstance(data, dict), 'Root must be an object'
for lesson_id, lesson in data.items():
    assert re.fullmatch(r'[A-Za-z0-9_-]+', lesson_id), f'Invalid ID: {lesson_id}'
    assert re.search(r'''["']id["']\s*:\s*["']''' + re.escape(lesson_id) + r'''["']|\bid\s*:\s*["']''' + re.escape(lesson_id) + r'''["']''', source), f'Unknown lesson ID: {lesson_id}'
    assert isinstance(lesson, dict), f'{lesson_id}: content must be an object'
    grammar = lesson.get('grammar')
    vocab = lesson.get('vocabulary')
    assert isinstance(grammar, dict) and isinstance(vocab, list) and vocab, f'{lesson_id}: grammar and vocabulary required'
    for key in ('title', 'titleFa', 'formula', 'explanation', 'explanationFa'):
        assert isinstance(grammar.get(key), str) and grammar[key].strip(), f'{lesson_id}: missing {key}'
    examples, translations = grammar.get('examples'), grammar.get('examplesFa')
    assert isinstance(examples, list) and isinstance(translations, list) and len(examples) == len(translations) and examples, f'{lesson_id}: examples/translations mismatch'
    assert all(isinstance(x, str) and x.strip() for x in examples + translations), f'{lesson_id}: empty example'
    words = []
    for item in vocab:
        assert isinstance(item, dict) and all(isinstance(item.get(k), str) and item[k].strip() for k in ('word', 'meaning', 'phrase')), f'{lesson_id}: invalid vocabulary'
        words.append(item['word'].casefold().strip())
    assert len(words) == len(set(words)), f'{lesson_id}: repeated target word'
    if lesson_id.lower().startswith(('c1', 'c2')):
        assert len(words) <= 20 and len(examples) <= 20, f'{lesson_id}: C1/C2 limit exceeded'
print(f'Validated {len(data)} researched lessons.')
